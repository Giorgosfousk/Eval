package EVaLgui;

import java.awt.Color;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ManagerProfileFrame extends javax.swing.JFrame {

    private static String username;
    private static String firm;
    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private DefaultTableModel model_jobs;
    private DefaultTableModel model_applications;
    private DefaultTableModel model_evaluations;
    private DefaultTableModel model_evaluators;
    private DefaultTableModel model_complete_evaluations;
    private static boolean update_job_id_salary_CB_populated;
    private static boolean employee_CB_populated;
    private static boolean degree_institute_CB_populated;
    private static boolean no_report;
    
    public ManagerProfileFrame(String login_username, String login_firm) {
        initComponents();
        this.username = login_username;
        this.firm = login_firm;
        profile_panel.setVisible(true);
        my_firm_panel.setVisible(false);
        employees_panel.setVisible(false);
        evaluation_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        username_field.setText(username);
        this.updateProfile();
        this.updateCompanyInfo();
        this.updateAvailableJobsTable();
        this.populateComboBoxUpdateJobId();
        this.populateComboBoxEmployee(); 
        this.populateComboBoxDegreeInstitute();
        this.updateFinalEvaluationTable();
        this.updateEvaluatorsTable();
    }

    private void sendUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, username);  
        callSetCurrentUser.execute();
    }
   
    private void restoreUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, "local_admin");  
        callSetCurrentUser.execute();
    }
    
    private void updateProfile() {
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectUserInfo = con.prepareStatement("SELECT name, surname, email, password, reg_date, firm FROM user WHERE username LIKE ?");
            selectUserInfo.setString(1, username);
            ResultSet resultUserInfo = selectUserInfo.executeQuery();

            PreparedStatement selectManagerInfo = con.prepareStatement("SELECT exp_years FROM manager WHERE managerUsername=?");
            selectManagerInfo.setString(1, username);
            ResultSet resultManagerInfo = selectManagerInfo.executeQuery();
            
            while (resultUserInfo.next()) {           
                name_field.setText(resultUserInfo.getString("name"));
                surname_field.setText(resultUserInfo.getString("surname"));
                email_field.setText(resultUserInfo.getString("email"));
                password_field.setText(resultUserInfo.getString("password").replaceAll(".", "*"));
                reg_date_field.setText(resultUserInfo.getString("reg_date"));
                firm_field.setText(resultUserInfo.getString("firm"));      
            }   
            while (resultManagerInfo.next()) {
                exp_years_field.setText(resultManagerInfo.getString("exp_years"));
            }          
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateCompanyInfo() {
        afm_field.setText(firm);
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectCompanyInfo = con.prepareStatement("SELECT DOY, name, phone, street, num, city, country FROM company WHERE AFM=?");
            selectCompanyInfo.setString(1, firm);
            ResultSet resultCompanyInfo = selectCompanyInfo.executeQuery();

            while (resultCompanyInfo.next()) {                          
                doy_field.setText(resultCompanyInfo.getString("DOY"));
                brand_name_field.setText(resultCompanyInfo.getString("name"));
                telephone_field.setText(resultCompanyInfo.getString("phone"));
                street_field.setText(resultCompanyInfo.getString("street"));
                street_no_field.setText(resultCompanyInfo.getString("num"));  
                city_field.setText(resultCompanyInfo.getString("city"));
                country_field.setText(resultCompanyInfo.getString("country"));  
            }           
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateAvailableJobsTable() {
        model_jobs = (DefaultTableModel) available_jobs_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectAvailableJobs = con.prepareStatement("SELECT id, salary, position, seat, name, surname, submission_date FROM job INNER JOIN evaluator ON evaluator=username INNER JOIN user ON evaluator.username=user.username WHERE job.firm=?");
            selectAvailableJobs.setString(1, firm);
            ResultSet resultJobs = selectAvailableJobs.executeQuery();
            model_jobs.setRowCount(0);           
            while (resultJobs.next()) {
                model_jobs.insertRow(model_jobs.getRowCount(), new Object[]{resultJobs.getInt("id"),resultJobs.getFloat("salary"),resultJobs.getString("position"),resultJobs.getString("seat"),resultJobs.getString("name"),resultJobs.getString("surname"),resultJobs.getString("submission_date")});
            }              
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    
    private void updateApplicationsTable(String employee) {
        model_applications = (DefaultTableModel) applications_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectJobs = con.prepareStatement("SELECT id, salary, position, name, surname, submission_date FROM requests_evaluation INNER JOIN job ON job_id=id INNER JOIN evaluator ON evaluator=evaluator.username INNER JOIN user ON evaluator.username=user.username WHERE employee=?");
            selectJobs.setString(1, employee);
            ResultSet resultJobs = selectJobs.executeQuery();
            model_applications.setRowCount(0);           
            while (resultJobs.next()) {
                model_applications.insertRow(model_applications.getRowCount(), new Object[]{resultJobs.getInt("id"),resultJobs.getFloat("salary"),resultJobs.getString("position"),resultJobs.getString("name"),resultJobs.getString("surname"),resultJobs.getString("submission_date")});

            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }       
    }
    
    private void updateCompleteEvaluationsTable(String employee) {
        model_complete_evaluations = (DefaultTableModel) complete_evaluations_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectCompleteEvaluations = con.prepareStatement("SELECT id, position, name, surname, grade FROM evaluation_results INNER JOIN job ON job_id=id INNER JOIN evaluator ON evaluator=evaluator.username INNER JOIN user ON evaluator.username=user.username WHERE employee=?");
            selectCompleteEvaluations.setString(1, employee);
            ResultSet resultCompleteEvaluations = selectCompleteEvaluations.executeQuery();
            model_complete_evaluations.setRowCount(0);           
            while (resultCompleteEvaluations.next()) {
                model_complete_evaluations.insertRow(model_complete_evaluations.getRowCount(), new Object[]{resultCompleteEvaluations.getInt("id"),resultCompleteEvaluations.getString("position"),resultCompleteEvaluations.getString("name"),resultCompleteEvaluations.getString("surname"),resultCompleteEvaluations.getInt("grade")});

            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }       
    }
    
    private void updateReportTA(String employee) {       
        try {
            report_TA.setText("");
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectReport = con.prepareStatement("SELECT report FROM reports WHERE employee=?");
            selectReport.setString(1, employee);
            ResultSet resultReport = selectReport.executeQuery();         
            while (resultReport.next()) {
                report_TA.setText(resultReport.getString("report"));
            }  
            if (report_TA.getText().equals("")) {
                no_report = true;
            }
            else {
                no_report = false;
            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }       
    }  
    
    private void updateFinalEvaluationTable() {
        model_evaluations = (DefaultTableModel) final_evaluation_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectEvaluations = con.prepareStatement("SELECT * FROM evaluation_results INNER JOIN employee ON employee=username INNER JOIN user ON employee.username=user.username WHERE user.firm=?");
            selectEvaluations.setString(1, firm);
            ResultSet resultEvaluations = selectEvaluations.executeQuery();
            model_evaluations.setRowCount(0);           
            while (resultEvaluations.next()) {
                model_evaluations.insertRow(model_evaluations.getRowCount(), new Object[]{resultEvaluations.getInt("ev_id"),resultEvaluations.getString("name")+" "+resultEvaluations.getString("surname"),resultEvaluations.getInt("job_id"),resultEvaluations.getInt("grade"),resultEvaluations.getString("comments")});
            }              
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateEvaluatorsTable() {
        model_evaluators = (DefaultTableModel) evaluators_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectEvaluators = con.prepareStatement("SELECT name, surname, AVG(grade) FROM evaluation_results INNER JOIN job ON job_id=id INNER JOIN evaluator ON evaluator=username INNER JOIN user ON evaluator.username=user.username WHERE user.firm=? GROUP BY evaluator");
            selectEvaluators.setString(1, firm);
            ResultSet resultEvaluators = selectEvaluators.executeQuery();
            model_evaluators.setRowCount(0);           
            while (resultEvaluators.next()) {
                model_evaluators.insertRow(model_evaluators.getRowCount(), new Object[]{resultEvaluators.getString("name"),resultEvaluators.getString("surname"),resultEvaluators.getFloat("AVG(grade)")});
            }              
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void populateComboBoxUpdateJobId() {       
        update_job_id_salary_CB_populated = false;
        update_job_id_salary_CB.removeAllItems();
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime current_date =  LocalDateTime.now();
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectJobsId = con.prepareStatement("SELECT id FROM job WHERE firm=? AND submission_date>=?");
            selectJobsId.setString(1, firm);
            selectJobsId.setString(2, dtf.format(current_date));
            ResultSet resultJobsId = selectJobsId.executeQuery();
                       
            while (resultJobsId.next()) {               
                update_job_id_salary_CB.addItem(resultJobsId.getString("id"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        update_job_id_salary_CB_populated = true;
    }
    
    private void populateComboBoxEmployee() {       
        employee_CB_populated = false;
        employee_CB.removeAllItems();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectEmployees = con.prepareStatement("SELECT user.username, name, surname FROM employee INNER JOIN user ON employee.username=user.username WHERE firm=?");
            selectEmployees.setString(1, firm);
            ResultSet resultEmployees = selectEmployees.executeQuery();
                       
            while (resultEmployees.next()) {               
                employee_CB.addItem(resultEmployees.getString("username")+": "+resultEmployees.getString("name")+" "+resultEmployees.getString("surname"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        employee_CB_populated = true;
    }
    
    private void populateComboBoxDegreeInstitute() {      
        degree_institute_CB_populated = false;
        degr_institute_CB.removeAllItems();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectDegrees = con.prepareStatement("SELECT DISTINCT institute FROM degree");
            ResultSet resultDegrees = selectDegrees.executeQuery();
                       
            while (resultDegrees.next()) {               
                degr_institute_CB.addItem(resultDegrees.getString("institute"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        degree_institute_CB_populated = true;
    }   
    
    private void populateComboBoxDegreeTitle(String institute) {      
        degr_title_CB.removeAllItems();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectDegreeTitles = con.prepareStatement("SELECT title FROM degree WHERE institute=?");
            selectDegreeTitles.setString(1, institute);
            ResultSet resultDegreeTitles = selectDegreeTitles.executeQuery();
                       
            while (resultDegreeTitles.next()) {               
                degr_title_CB.addItem(resultDegreeTitles.getString("title"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    } 
    
    private void populateComboBoxLanguages(String employee) {       
        languages_CB.removeAllItems();
        languages_CB.addItem("English");
        languages_CB.addItem("French");
        languages_CB.addItem("Spanish");
        languages_CB.addItem("Greek");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logo_panel = new javax.swing.JPanel();
        logo_L = new javax.swing.JLabel();
        profile_subpanel = new javax.swing.JPanel();
        profile_subL = new javax.swing.JLabel();
        employees_subpanel = new javax.swing.JPanel();
        employees_subL = new javax.swing.JLabel();
        my_firm_subpanel = new javax.swing.JPanel();
        my_firm_subL = new javax.swing.JLabel();
        evaluation_subpanel = new javax.swing.JPanel();
        evaluation_subL = new javax.swing.JLabel();
        exit_subpanel = new javax.swing.JPanel();
        exit_subL = new javax.swing.JLabel();
        main_panel = new javax.swing.JPanel();
        profile_panel = new javax.swing.JPanel();
        username_L = new javax.swing.JLabel();
        name_L = new javax.swing.JLabel();
        surname_L = new javax.swing.JLabel();
        email_L = new javax.swing.JLabel();
        password_L = new javax.swing.JLabel();
        reg_date_L = new javax.swing.JLabel();
        exp_years_L = new javax.swing.JLabel();
        firm_L = new javax.swing.JLabel();
        update_B = new javax.swing.JButton();
        change_B = new javax.swing.JButton();
        username_field = new javax.swing.JLabel();
        name_field = new javax.swing.JLabel();
        surname_field = new javax.swing.JLabel();
        email_field = new javax.swing.JLabel();
        reg_date_field = new javax.swing.JLabel();
        password_field = new javax.swing.JLabel();
        exp_years_field = new javax.swing.JLabel();
        firm_field = new javax.swing.JLabel();
        title_panel = new javax.swing.JPanel();
        profile_L = new javax.swing.JLabel();
        my_firm_panel = new javax.swing.JPanel();
        title_panel1 = new javax.swing.JPanel();
        my_firm_L = new javax.swing.JLabel();
        update_job_id_L1 = new javax.swing.JLabel();
        update_job_id_salary_CB = new javax.swing.JComboBox<>();
        update_salary_TF = new javax.swing.JTextField();
        update_salary_L = new javax.swing.JLabel();
        update_salary_B = new javax.swing.JButton();
        available_jobs_scroll_panel = new javax.swing.JScrollPane();
        available_jobs_table = new javax.swing.JTable();
        country_L = new javax.swing.JLabel();
        country_field = new javax.swing.JLabel();
        street_no_field = new javax.swing.JLabel();
        street_field = new javax.swing.JLabel();
        street_no_L = new javax.swing.JLabel();
        street_L = new javax.swing.JLabel();
        city_L = new javax.swing.JLabel();
        telephone_L = new javax.swing.JLabel();
        brand_name_L = new javax.swing.JLabel();
        doy_L = new javax.swing.JLabel();
        city_field = new javax.swing.JLabel();
        telephone_field = new javax.swing.JLabel();
        brand_name_field = new javax.swing.JLabel();
        doy_field = new javax.swing.JLabel();
        afm_field = new javax.swing.JLabel();
        afm_L = new javax.swing.JLabel();
        change_firm_B = new javax.swing.JButton();
        update_firm_B = new javax.swing.JButton();
        employees_panel = new javax.swing.JPanel();
        title_panel2 = new javax.swing.JPanel();
        employees_L = new javax.swing.JLabel();
        applications_scroll_panel = new javax.swing.JScrollPane();
        applications_table = new javax.swing.JTable();
        edit_recommendations_B = new javax.swing.JButton();
        descr_L = new javax.swing.JLabel();
        update_certificates_TF = new javax.swing.JTextField();
        update_recommendations_TF = new javax.swing.JTextField();
        update_awards_TF = new javax.swing.JTextField();
        employee_CB = new javax.swing.JComboBox<>();
        employee_L = new javax.swing.JLabel();
        complete_evaluations_scroll_panel = new javax.swing.JScrollPane();
        complete_evaluations_table = new javax.swing.JTable();
        recommendations_L = new javax.swing.JLabel();
        certificates_L = new javax.swing.JLabel();
        award_L = new javax.swing.JLabel();
        edit_certificates_B = new javax.swing.JButton();
        edit_awards_B = new javax.swing.JButton();
        languages_L = new javax.swing.JLabel();
        remove_language_B = new javax.swing.JButton();
        url_L = new javax.swing.JLabel();
        add_url_TF = new javax.swing.JTextField();
        report_L = new javax.swing.JLabel();
        report_SP = new javax.swing.JScrollPane();
        report_TA = new javax.swing.JTextArea();
        add_report_B = new javax.swing.JButton();
        degr_title_L = new javax.swing.JLabel();
        degr_institute_L = new javax.swing.JLabel();
        add_year_TF = new javax.swing.JTextField();
        degr_year_L = new javax.swing.JLabel();
        degr_grade_L = new javax.swing.JLabel();
        add_grade_TF = new javax.swing.JTextField();
        descr_SP = new javax.swing.JScrollPane();
        descr_TA = new javax.swing.JTextArea();
        add_degree_B = new javax.swing.JButton();
        add_project_B = new javax.swing.JButton();
        languages_CB = new javax.swing.JComboBox<>();
        add_language_B = new javax.swing.JButton();
        degr_title_CB = new javax.swing.JComboBox<>();
        degr_institute_CB = new javax.swing.JComboBox<>();
        evaluation_panel = new javax.swing.JPanel();
        title_panel3 = new javax.swing.JPanel();
        evaluation_L = new javax.swing.JLabel();
        final_evaluation_scroll_panel = new javax.swing.JScrollPane();
        final_evaluation_table = new javax.swing.JTable();
        evaluators_scroll_panel = new javax.swing.JScrollPane();
        evaluators_table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        logo_panel.setBackground(new java.awt.Color(102, 0, 204));

        logo_L.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        logo_L.setForeground(new java.awt.Color(255, 255, 255));
        logo_L.setText("EVaL");

        profile_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        profile_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        profile_subL.setForeground(new java.awt.Color(255, 255, 255));
        profile_subL.setText("                           Profile");
        profile_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                profile_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout profile_subpanelLayout = new javax.swing.GroupLayout(profile_subpanel);
        profile_subpanel.setLayout(profile_subpanelLayout);
        profile_subpanelLayout.setHorizontalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        profile_subpanelLayout.setVerticalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );

        employees_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        employees_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        employees_subL.setForeground(new java.awt.Color(255, 255, 255));
        employees_subL.setText("                        Employees");
        employees_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                employees_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout employees_subpanelLayout = new javax.swing.GroupLayout(employees_subpanel);
        employees_subpanel.setLayout(employees_subpanelLayout);
        employees_subpanelLayout.setHorizontalGroup(
            employees_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, employees_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(employees_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        employees_subpanelLayout.setVerticalGroup(
            employees_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, employees_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(employees_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        my_firm_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        my_firm_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        my_firm_subL.setForeground(new java.awt.Color(255, 255, 255));
        my_firm_subL.setText("                         My Firm");
        my_firm_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                my_firm_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout my_firm_subpanelLayout = new javax.swing.GroupLayout(my_firm_subpanel);
        my_firm_subpanel.setLayout(my_firm_subpanelLayout);
        my_firm_subpanelLayout.setHorizontalGroup(
            my_firm_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_firm_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_firm_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        my_firm_subpanelLayout.setVerticalGroup(
            my_firm_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_firm_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_firm_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        evaluation_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        evaluation_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        evaluation_subL.setForeground(new java.awt.Color(255, 255, 255));
        evaluation_subL.setText("                        Evaluation");
        evaluation_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                evaluation_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout evaluation_subpanelLayout = new javax.swing.GroupLayout(evaluation_subpanel);
        evaluation_subpanel.setLayout(evaluation_subpanelLayout);
        evaluation_subpanelLayout.setHorizontalGroup(
            evaluation_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, evaluation_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(evaluation_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        evaluation_subpanelLayout.setVerticalGroup(
            evaluation_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, evaluation_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(evaluation_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                .addContainerGap())
        );

        exit_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        exit_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exit_subL.setForeground(new java.awt.Color(255, 255, 255));
        exit_subL.setText("                             Exit");
        exit_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exit_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout exit_subpanelLayout = new javax.swing.GroupLayout(exit_subpanel);
        exit_subpanel.setLayout(exit_subpanelLayout);
        exit_subpanelLayout.setHorizontalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        exit_subpanelLayout.setVerticalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout logo_panelLayout = new javax.swing.GroupLayout(logo_panel);
        logo_panel.setLayout(logo_panelLayout);
        logo_panelLayout.setHorizontalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(logo_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(my_firm_subpanel, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profile_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(logo_panelLayout.createSequentialGroup()
                        .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(employees_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(evaluation_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(exit_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        logo_panelLayout.setVerticalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logo_L)
                .addGap(52, 52, 52)
                .addComponent(profile_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(my_firm_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(employees_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(evaluation_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(exit_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        main_panel.setBackground(new java.awt.Color(255, 255, 255));
        main_panel.setLayout(new javax.swing.OverlayLayout(main_panel));

        profile_panel.setBackground(new java.awt.Color(255, 255, 255));

        username_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_L.setForeground(new java.awt.Color(77, 77, 77));
        username_L.setText("Username:");

        name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_L.setForeground(new java.awt.Color(77, 77, 77));
        name_L.setText("Name:");

        surname_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_L.setForeground(new java.awt.Color(77, 77, 77));
        surname_L.setText("Surname:");

        email_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_L.setForeground(new java.awt.Color(77, 77, 77));
        email_L.setText("Email:");

        password_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_L.setForeground(new java.awt.Color(77, 77, 77));
        password_L.setText("Password:");

        reg_date_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_L.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_L.setText("Date of Registration:");

        exp_years_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_L.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_L.setText("Years of Experience:");

        firm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_L.setForeground(new java.awt.Color(77, 77, 77));
        firm_L.setText("Firm:");

        update_B.setBackground(new java.awt.Color(102, 0, 204));
        update_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_B.setForeground(new java.awt.Color(255, 255, 255));
        update_B.setText("Update");
        update_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_BActionPerformed(evt);
            }
        });

        change_B.setBackground(new java.awt.Color(102, 0, 204));
        change_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        change_B.setForeground(new java.awt.Color(255, 255, 255));
        change_B.setText("Change");
        change_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                change_BActionPerformed(evt);
            }
        });

        username_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_field.setForeground(new java.awt.Color(77, 77, 77));
        username_field.setText("test");

        name_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_field.setForeground(new java.awt.Color(77, 77, 77));
        name_field.setText("test");

        surname_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_field.setForeground(new java.awt.Color(77, 77, 77));
        surname_field.setText("test");

        email_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_field.setForeground(new java.awt.Color(77, 77, 77));
        email_field.setText("test");

        reg_date_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_field.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_field.setText("test");

        password_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_field.setForeground(new java.awt.Color(77, 77, 77));
        password_field.setText("tset");

        exp_years_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_field.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_field.setText("test");

        firm_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_field.setForeground(new java.awt.Color(77, 77, 77));
        firm_field.setText("test");

        title_panel.setBackground(new java.awt.Color(166, 77, 255));

        profile_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        profile_L.setForeground(new java.awt.Color(255, 255, 255));
        profile_L.setText("Profile");

        javax.swing.GroupLayout title_panelLayout = new javax.swing.GroupLayout(title_panel);
        title_panel.setLayout(title_panelLayout);
        title_panelLayout.setHorizontalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(profile_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        title_panelLayout.setVerticalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(profile_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout profile_panelLayout = new javax.swing.GroupLayout(profile_panel);
        profile_panel.setLayout(profile_panelLayout);
        profile_panelLayout.setHorizontalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(reg_date_L)
                    .addComponent(exp_years_L)
                    .addComponent(firm_L)
                    .addComponent(username_L)
                    .addComponent(name_L)
                    .addComponent(surname_L)
                    .addComponent(password_L)
                    .addComponent(email_L))
                .addGap(18, 18, 18)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(surname_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reg_date_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exp_years_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(firm_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(262, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(change_B)
                .addGap(18, 18, 18)
                .addComponent(update_B)
                .addGap(25, 25, 25))
        );
        profile_panelLayout.setVerticalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addComponent(title_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_L)
                    .addComponent(name_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(surname_L)
                    .addComponent(surname_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_L)
                    .addComponent(email_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password_L)
                    .addComponent(password_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reg_date_L)
                    .addComponent(reg_date_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exp_years_L)
                    .addComponent(exp_years_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firm_L)
                    .addComponent(firm_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 305, Short.MAX_VALUE)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(update_B)
                    .addComponent(change_B))
                .addGap(24, 24, 24))
        );

        main_panel.add(profile_panel);

        my_firm_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel1.setBackground(new java.awt.Color(166, 77, 255));

        my_firm_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        my_firm_L.setForeground(new java.awt.Color(255, 255, 255));
        my_firm_L.setText("My Firm");

        javax.swing.GroupLayout title_panel1Layout = new javax.swing.GroupLayout(title_panel1);
        title_panel1.setLayout(title_panel1Layout);
        title_panel1Layout.setHorizontalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(my_firm_L)
                .addContainerGap(457, Short.MAX_VALUE))
        );
        title_panel1Layout.setVerticalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(my_firm_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        update_job_id_L1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_job_id_L1.setForeground(new java.awt.Color(77, 77, 77));
        update_job_id_L1.setText("Job ID:");

        update_job_id_salary_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_job_id_salary_CB.setForeground(new java.awt.Color(77, 77, 77));
        update_job_id_salary_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        update_job_id_salary_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_job_id_salary_CBActionPerformed(evt);
            }
        });

        update_salary_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_salary_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_salary_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_salary_TFActionPerformed(evt);
            }
        });

        update_salary_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_salary_L.setForeground(new java.awt.Color(77, 77, 77));
        update_salary_L.setText("Salary:");

        update_salary_B.setBackground(new java.awt.Color(102, 0, 204));
        update_salary_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_salary_B.setForeground(new java.awt.Color(255, 255, 255));
        update_salary_B.setText("Edit Salary");
        update_salary_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_salary_BActionPerformed(evt);
            }
        });

        available_jobs_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        available_jobs_table.setForeground(new java.awt.Color(77, 77, 77));
        available_jobs_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Salary", "Position", "Seat", "Name", "Surname", "Submission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        available_jobs_table.setRowSelectionAllowed(false);
        available_jobs_table.setShowHorizontalLines(false);
        available_jobs_table.setShowVerticalLines(false);
        available_jobs_table.getTableHeader().setReorderingAllowed(false);
        available_jobs_scroll_panel.setViewportView(available_jobs_table);
        if (available_jobs_table.getColumnModel().getColumnCount() > 0) {
            available_jobs_table.getColumnModel().getColumn(0).setResizable(false);
            available_jobs_table.getColumnModel().getColumn(0).setPreferredWidth(20);
            available_jobs_table.getColumnModel().getColumn(1).setResizable(false);
            available_jobs_table.getColumnModel().getColumn(1).setPreferredWidth(50);
            available_jobs_table.getColumnModel().getColumn(2).setResizable(false);
            available_jobs_table.getColumnModel().getColumn(2).setPreferredWidth(200);
            available_jobs_table.getColumnModel().getColumn(3).setResizable(false);
            available_jobs_table.getColumnModel().getColumn(4).setResizable(false);
            available_jobs_table.getColumnModel().getColumn(5).setResizable(false);
            available_jobs_table.getColumnModel().getColumn(6).setResizable(false);
        }

        country_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        country_L.setForeground(new java.awt.Color(77, 77, 77));
        country_L.setText("Country:");

        country_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        country_field.setForeground(new java.awt.Color(77, 77, 77));
        country_field.setText("test");

        street_no_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_no_field.setForeground(new java.awt.Color(77, 77, 77));
        street_no_field.setText("test");

        street_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_field.setForeground(new java.awt.Color(77, 77, 77));
        street_field.setText("test");

        street_no_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_no_L.setForeground(new java.awt.Color(77, 77, 77));
        street_no_L.setText("Street No.:");

        street_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_L.setForeground(new java.awt.Color(77, 77, 77));
        street_L.setText("Address Street:");

        city_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        city_L.setForeground(new java.awt.Color(77, 77, 77));
        city_L.setText("City:");

        telephone_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        telephone_L.setForeground(new java.awt.Color(77, 77, 77));
        telephone_L.setText("Telephone:");

        brand_name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        brand_name_L.setForeground(new java.awt.Color(77, 77, 77));
        brand_name_L.setText("Brand Name:");

        doy_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        doy_L.setForeground(new java.awt.Color(77, 77, 77));
        doy_L.setText("DOY");

        city_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        city_field.setForeground(new java.awt.Color(77, 77, 77));
        city_field.setText("tset");

        telephone_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        telephone_field.setForeground(new java.awt.Color(77, 77, 77));
        telephone_field.setText("test");

        brand_name_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        brand_name_field.setForeground(new java.awt.Color(77, 77, 77));
        brand_name_field.setText("test");

        doy_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        doy_field.setForeground(new java.awt.Color(77, 77, 77));
        doy_field.setText("test");

        afm_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        afm_field.setForeground(new java.awt.Color(77, 77, 77));
        afm_field.setText("test");

        afm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        afm_L.setForeground(new java.awt.Color(77, 77, 77));
        afm_L.setText("AFM:");

        change_firm_B.setBackground(new java.awt.Color(102, 0, 204));
        change_firm_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        change_firm_B.setForeground(new java.awt.Color(255, 255, 255));
        change_firm_B.setText("Change");
        change_firm_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                change_firm_BActionPerformed(evt);
            }
        });

        update_firm_B.setBackground(new java.awt.Color(102, 0, 204));
        update_firm_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_firm_B.setForeground(new java.awt.Color(255, 255, 255));
        update_firm_B.setText("Update");
        update_firm_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_firm_BActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout my_firm_panelLayout = new javax.swing.GroupLayout(my_firm_panel);
        my_firm_panel.setLayout(my_firm_panelLayout);
        my_firm_panelLayout.setHorizontalGroup(
            my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(my_firm_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(available_jobs_scroll_panel)
                    .addGroup(my_firm_panelLayout.createSequentialGroup()
                        .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(my_firm_panelLayout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(my_firm_panelLayout.createSequentialGroup()
                                        .addComponent(afm_L)
                                        .addGap(78, 78, 78)
                                        .addComponent(afm_field, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(my_firm_panelLayout.createSequentialGroup()
                                        .addComponent(change_firm_B)
                                        .addGap(18, 18, 18)
                                        .addComponent(update_firm_B))
                                    .addGroup(my_firm_panelLayout.createSequentialGroup()
                                        .addComponent(doy_L)
                                        .addGap(81, 81, 81)
                                        .addComponent(doy_field, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(my_firm_panelLayout.createSequentialGroup()
                                            .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(country_L)
                                                .addComponent(brand_name_L)
                                                .addComponent(telephone_L))
                                            .addGap(31, 31, 31)
                                            .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(brand_name_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(telephone_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(country_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(my_firm_panelLayout.createSequentialGroup()
                                            .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(street_L)
                                                .addComponent(street_no_L))
                                            .addGap(18, 18, 18)
                                            .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(street_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(street_no_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(my_firm_panelLayout.createSequentialGroup()
                                            .addComponent(city_L)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(city_field, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(my_firm_panelLayout.createSequentialGroup()
                                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(update_job_id_L1)
                                    .addComponent(update_salary_L))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(update_job_id_salary_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(my_firm_panelLayout.createSequentialGroup()
                                        .addComponent(update_salary_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(update_salary_B)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        my_firm_panelLayout.setVerticalGroup(
            my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_firm_panelLayout.createSequentialGroup()
                .addComponent(title_panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(afm_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(afm_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(doy_L)
                    .addComponent(doy_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(brand_name_L)
                    .addComponent(brand_name_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(telephone_L)
                    .addComponent(telephone_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(street_L)
                    .addComponent(street_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(street_no_L)
                    .addComponent(street_no_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(city_L)
                    .addComponent(city_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(country_L)
                    .addComponent(country_field))
                .addGap(23, 23, 23)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(update_firm_B)
                    .addComponent(change_firm_B))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(update_job_id_L1)
                    .addComponent(update_job_id_salary_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_firm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(update_salary_L)
                    .addComponent(update_salary_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(update_salary_B, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(available_jobs_scroll_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        main_panel.add(my_firm_panel);

        employees_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel2.setBackground(new java.awt.Color(166, 77, 255));

        employees_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        employees_L.setForeground(new java.awt.Color(255, 255, 255));
        employees_L.setText("Employees");

        javax.swing.GroupLayout title_panel2Layout = new javax.swing.GroupLayout(title_panel2);
        title_panel2.setLayout(title_panel2Layout);
        title_panel2Layout.setHorizontalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(employees_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        title_panel2Layout.setVerticalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(employees_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        applications_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        applications_table.setForeground(new java.awt.Color(77, 77, 77));
        applications_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Salary", "Position", "Name", "Surname", "Submission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        applications_table.setRowSelectionAllowed(false);
        applications_table.setShowHorizontalLines(false);
        applications_table.setShowVerticalLines(false);
        applications_table.getTableHeader().setReorderingAllowed(false);
        applications_scroll_panel.setViewportView(applications_table);
        if (applications_table.getColumnModel().getColumnCount() > 0) {
            applications_table.getColumnModel().getColumn(0).setResizable(false);
            applications_table.getColumnModel().getColumn(0).setPreferredWidth(10);
            applications_table.getColumnModel().getColumn(1).setResizable(false);
            applications_table.getColumnModel().getColumn(1).setPreferredWidth(50);
            applications_table.getColumnModel().getColumn(2).setResizable(false);
            applications_table.getColumnModel().getColumn(2).setPreferredWidth(200);
            applications_table.getColumnModel().getColumn(3).setResizable(false);
            applications_table.getColumnModel().getColumn(4).setResizable(false);
            applications_table.getColumnModel().getColumn(5).setResizable(false);
        }

        edit_recommendations_B.setBackground(new java.awt.Color(102, 0, 204));
        edit_recommendations_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_recommendations_B.setForeground(new java.awt.Color(255, 255, 255));
        edit_recommendations_B.setText("Edit");
        edit_recommendations_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_recommendations_BActionPerformed(evt);
            }
        });

        descr_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        descr_L.setForeground(new java.awt.Color(77, 77, 77));
        descr_L.setText("Description:");

        update_certificates_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_certificates_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_certificates_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_certificates_TFActionPerformed(evt);
            }
        });

        update_recommendations_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_recommendations_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_recommendations_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_recommendations_TFActionPerformed(evt);
            }
        });

        update_awards_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_awards_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_awards_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_awards_TFActionPerformed(evt);
            }
        });

        employee_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        employee_CB.setForeground(new java.awt.Color(77, 77, 77));
        employee_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        employee_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employee_CBActionPerformed(evt);
            }
        });

        employee_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        employee_L.setForeground(new java.awt.Color(77, 77, 77));
        employee_L.setText("Employee:");

        complete_evaluations_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        complete_evaluations_table.setForeground(new java.awt.Color(77, 77, 77));
        complete_evaluations_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Position", "Name", "Surname", "Grade"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        complete_evaluations_table.setRowSelectionAllowed(false);
        complete_evaluations_table.setShowHorizontalLines(false);
        complete_evaluations_table.setShowVerticalLines(false);
        complete_evaluations_table.getTableHeader().setReorderingAllowed(false);
        complete_evaluations_scroll_panel.setViewportView(complete_evaluations_table);
        if (complete_evaluations_table.getColumnModel().getColumnCount() > 0) {
            complete_evaluations_table.getColumnModel().getColumn(0).setResizable(false);
            complete_evaluations_table.getColumnModel().getColumn(0).setPreferredWidth(5);
            complete_evaluations_table.getColumnModel().getColumn(1).setResizable(false);
            complete_evaluations_table.getColumnModel().getColumn(1).setPreferredWidth(250);
            complete_evaluations_table.getColumnModel().getColumn(2).setResizable(false);
            complete_evaluations_table.getColumnModel().getColumn(3).setResizable(false);
            complete_evaluations_table.getColumnModel().getColumn(4).setResizable(false);
            complete_evaluations_table.getColumnModel().getColumn(4).setPreferredWidth(10);
        }

        recommendations_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        recommendations_L.setForeground(new java.awt.Color(77, 77, 77));
        recommendations_L.setText("Recommendations:");

        certificates_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        certificates_L.setForeground(new java.awt.Color(77, 77, 77));
        certificates_L.setText("Certificates:");

        award_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        award_L.setForeground(new java.awt.Color(77, 77, 77));
        award_L.setText("Awards:");

        edit_certificates_B.setBackground(new java.awt.Color(102, 0, 204));
        edit_certificates_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_certificates_B.setForeground(new java.awt.Color(255, 255, 255));
        edit_certificates_B.setText("Edit");
        edit_certificates_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_certificates_BActionPerformed(evt);
            }
        });

        edit_awards_B.setBackground(new java.awt.Color(102, 0, 204));
        edit_awards_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_awards_B.setForeground(new java.awt.Color(255, 255, 255));
        edit_awards_B.setText("Edit");
        edit_awards_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_awards_BActionPerformed(evt);
            }
        });

        languages_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        languages_L.setForeground(new java.awt.Color(77, 77, 77));
        languages_L.setText("Languages:");

        remove_language_B.setBackground(new java.awt.Color(102, 0, 204));
        remove_language_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        remove_language_B.setForeground(new java.awt.Color(255, 255, 255));
        remove_language_B.setText("Remove");
        remove_language_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                remove_language_BActionPerformed(evt);
            }
        });

        url_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        url_L.setForeground(new java.awt.Color(77, 77, 77));
        url_L.setText("Url:");

        add_url_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_url_TF.setForeground(new java.awt.Color(77, 77, 77));
        add_url_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_url_TFActionPerformed(evt);
            }
        });

        report_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        report_L.setForeground(new java.awt.Color(77, 77, 77));
        report_L.setText("Report:");

        report_TA.setColumns(20);
        report_TA.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        report_TA.setForeground(new java.awt.Color(77, 77, 77));
        report_TA.setLineWrap(true);
        report_TA.setRows(5);
        report_SP.setViewportView(report_TA);

        add_report_B.setBackground(new java.awt.Color(102, 0, 204));
        add_report_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_report_B.setForeground(new java.awt.Color(255, 255, 255));
        add_report_B.setText("Add Report");
        add_report_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_report_BActionPerformed(evt);
            }
        });

        degr_title_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        degr_title_L.setForeground(new java.awt.Color(77, 77, 77));
        degr_title_L.setText("Title:");

        degr_institute_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        degr_institute_L.setForeground(new java.awt.Color(77, 77, 77));
        degr_institute_L.setText("Institute:");

        add_year_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_year_TF.setForeground(new java.awt.Color(77, 77, 77));
        add_year_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_year_TFActionPerformed(evt);
            }
        });

        degr_year_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        degr_year_L.setForeground(new java.awt.Color(77, 77, 77));
        degr_year_L.setText("Year:");

        degr_grade_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        degr_grade_L.setForeground(new java.awt.Color(77, 77, 77));
        degr_grade_L.setText("Grade:");

        add_grade_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_grade_TF.setForeground(new java.awt.Color(77, 77, 77));
        add_grade_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_grade_TFActionPerformed(evt);
            }
        });

        descr_TA.setColumns(20);
        descr_TA.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        descr_TA.setForeground(new java.awt.Color(77, 77, 77));
        descr_TA.setLineWrap(true);
        descr_TA.setRows(5);
        descr_SP.setViewportView(descr_TA);

        add_degree_B.setBackground(new java.awt.Color(102, 0, 204));
        add_degree_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_degree_B.setForeground(new java.awt.Color(255, 255, 255));
        add_degree_B.setText("Add Degree");
        add_degree_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_degree_BActionPerformed(evt);
            }
        });

        add_project_B.setBackground(new java.awt.Color(102, 0, 204));
        add_project_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_project_B.setForeground(new java.awt.Color(255, 255, 255));
        add_project_B.setText("Add Project");
        add_project_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_project_BActionPerformed(evt);
            }
        });

        languages_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        languages_CB.setForeground(new java.awt.Color(77, 77, 77));
        languages_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        languages_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                languages_CBActionPerformed(evt);
            }
        });

        add_language_B.setBackground(new java.awt.Color(102, 0, 204));
        add_language_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_language_B.setForeground(new java.awt.Color(255, 255, 255));
        add_language_B.setText("Add");
        add_language_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_language_BActionPerformed(evt);
            }
        });

        degr_title_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        degr_title_CB.setForeground(new java.awt.Color(77, 77, 77));
        degr_title_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        degr_title_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                degr_title_CBActionPerformed(evt);
            }
        });

        degr_institute_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        degr_institute_CB.setForeground(new java.awt.Color(77, 77, 77));
        degr_institute_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        degr_institute_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                degr_institute_CBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout employees_panelLayout = new javax.swing.GroupLayout(employees_panel);
        employees_panel.setLayout(employees_panelLayout);
        employees_panelLayout.setHorizontalGroup(
            employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(employees_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(applications_scroll_panel)
                    .addComponent(complete_evaluations_scroll_panel)
                    .addGroup(employees_panelLayout.createSequentialGroup()
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(employees_panelLayout.createSequentialGroup()
                                .addComponent(recommendations_L)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(update_recommendations_TF))
                            .addGroup(employees_panelLayout.createSequentialGroup()
                                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(certificates_L)
                                    .addComponent(languages_L)
                                    .addComponent(award_L))
                                .addGap(56, 56, 56)
                                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(update_certificates_TF)
                                    .addComponent(update_awards_TF)
                                    .addGroup(employees_panelLayout.createSequentialGroup()
                                        .addComponent(languages_CB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(remove_language_B)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(edit_recommendations_B, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                .addComponent(edit_certificates_B, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(edit_awards_B, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(add_language_B, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(employees_panelLayout.createSequentialGroup()
                        .addComponent(employee_L)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(employee_CB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(add_report_B, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(employees_panelLayout.createSequentialGroup()
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(degr_title_L)
                            .addComponent(degr_grade_L)
                            .addComponent(degr_year_L)
                            .addComponent(report_L)
                            .addComponent(degr_institute_L))
                        .addGap(10, 10, 10)
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(report_SP, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(employees_panelLayout.createSequentialGroup()
                                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(employees_panelLayout.createSequentialGroup()
                                        .addComponent(add_grade_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(add_degree_B))
                                    .addComponent(degr_title_CB, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(degr_institute_CB, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(add_year_TF, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(employees_panelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(add_project_B, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(employees_panelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(url_L)
                                            .addComponent(descr_L))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(descr_SP)
                                            .addComponent(add_url_TF))))))))
                .addContainerGap())
        );
        employees_panelLayout.setVerticalGroup(
            employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(employees_panelLayout.createSequentialGroup()
                .addComponent(title_panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(employee_L)
                    .addComponent(employee_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(applications_scroll_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(complete_evaluations_scroll_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(report_SP, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(employees_panelLayout.createSequentialGroup()
                        .addComponent(report_L)
                        .addGap(0, 32, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(add_report_B, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(employees_panelLayout.createSequentialGroup()
                        .addComponent(add_url_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(descr_SP, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(add_project_B, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(employees_panelLayout.createSequentialGroup()
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(url_L)
                            .addComponent(degr_institute_L)
                            .addComponent(degr_institute_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(descr_L)
                            .addComponent(degr_title_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(degr_title_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(add_year_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(degr_year_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(add_degree_B, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(add_grade_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(degr_grade_L))))
                .addGap(11, 11, 11)
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(recommendations_L)
                    .addComponent(update_recommendations_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edit_recommendations_B))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(certificates_L)
                    .addComponent(update_certificates_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edit_certificates_B))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(award_L)
                    .addComponent(update_awards_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edit_awards_B))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(employees_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(languages_L)
                    .addComponent(remove_language_B)
                    .addComponent(languages_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(add_language_B))
                .addContainerGap())
        );

        main_panel.add(employees_panel);

        evaluation_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel3.setBackground(new java.awt.Color(166, 77, 255));

        evaluation_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        evaluation_L.setForeground(new java.awt.Color(255, 255, 255));
        evaluation_L.setText("Evaluation");

        javax.swing.GroupLayout title_panel3Layout = new javax.swing.GroupLayout(title_panel3);
        title_panel3.setLayout(title_panel3Layout);
        title_panel3Layout.setHorizontalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(evaluation_L)
                .addContainerGap(425, Short.MAX_VALUE))
        );
        title_panel3Layout.setVerticalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(evaluation_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        final_evaluation_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        final_evaluation_table.setForeground(new java.awt.Color(77, 77, 77));
        final_evaluation_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Evaluation ID", "Employee", "Job ID", "Ev. Grade", "Comments"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        final_evaluation_table.setRowSelectionAllowed(false);
        final_evaluation_table.setShowHorizontalLines(false);
        final_evaluation_table.setShowVerticalLines(false);
        final_evaluation_table.getTableHeader().setReorderingAllowed(false);
        final_evaluation_scroll_panel.setViewportView(final_evaluation_table);

        evaluators_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        evaluators_table.setForeground(new java.awt.Color(77, 77, 77));
        evaluators_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Surname", "Grade Avg."
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        evaluators_table.getTableHeader().setReorderingAllowed(false);
        evaluators_scroll_panel.setViewportView(evaluators_table);
        if (evaluators_table.getColumnModel().getColumnCount() > 0) {
            evaluators_table.getColumnModel().getColumn(0).setResizable(false);
            evaluators_table.getColumnModel().getColumn(1).setResizable(false);
            evaluators_table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout evaluation_panelLayout = new javax.swing.GroupLayout(evaluation_panel);
        evaluation_panel.setLayout(evaluation_panelLayout);
        evaluation_panelLayout.setHorizontalGroup(
            evaluation_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(evaluation_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(evaluation_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(final_evaluation_scroll_panel)
                    .addComponent(evaluators_scroll_panel))
                .addContainerGap())
        );
        evaluation_panelLayout.setVerticalGroup(
            evaluation_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(evaluation_panelLayout.createSequentialGroup()
                .addComponent(title_panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(final_evaluation_scroll_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(evaluators_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                .addContainerGap())
        );

        main_panel.add(evaluation_panel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logo_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logo_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(main_panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void profile_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_profile_subLMouseClicked
        profile_panel.setVisible(true);
        my_firm_panel.setVisible(false);
        employees_panel.setVisible(false);
        evaluation_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        employees_subpanel.setBackground(new Color(102,0,204));
        my_firm_subpanel.setBackground(new Color(102,0,204));
        evaluation_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_profile_subLMouseClicked

    private void employees_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_employees_subLMouseClicked
        profile_panel.setVisible(false);
        my_firm_panel.setVisible(false);
        employees_panel.setVisible(true);
        evaluation_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(102,0,204));
        employees_subpanel.setBackground(new Color(166,77,255));
        my_firm_subpanel.setBackground(new Color(102,0,204));
        evaluation_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_employees_subLMouseClicked

    private void my_firm_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_my_firm_subLMouseClicked
        profile_panel.setVisible(false);
        my_firm_panel.setVisible(true);
        employees_panel.setVisible(false);
        evaluation_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(102,0,204));
        employees_subpanel.setBackground(new Color(102,0,204));
        my_firm_subpanel.setBackground(new Color(166,77,255));
        evaluation_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_my_firm_subLMouseClicked

    private void evaluation_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_evaluation_subLMouseClicked
        profile_panel.setVisible(false);
        my_firm_panel.setVisible(false);
        employees_panel.setVisible(false);
        evaluation_panel.setVisible(true);
        profile_subpanel.setBackground(new Color(102,0,204));
        employees_subpanel.setBackground(new Color(102,0,204));
        my_firm_subpanel.setBackground(new Color(102,0,204));
        evaluation_subpanel.setBackground(new Color(166,77,255));
    }//GEN-LAST:event_evaluation_subLMouseClicked

    private void exit_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_subLMouseClicked
        this.dispose();
        new LoginFrame().setVisible(true);
    }//GEN-LAST:event_exit_subLMouseClicked

    private void update_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_BActionPerformed
        this.updateProfile();
    }//GEN-LAST:event_update_BActionPerformed

    private void change_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_change_BActionPerformed
        new UpdateProfileFrame(username, 2).setVisible(true);
    }//GEN-LAST:event_change_BActionPerformed

    private void update_salary_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_salary_BActionPerformed
        int salary;
        int job_id;
       
        salary = Integer.parseInt(update_salary_TF.getText());
        job_id = Integer.parseInt((String)update_job_id_salary_CB.getSelectedItem());

        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateJob = con.prepareStatement("UPDATE job SET salary=? WHERE id=?");
            updateJob.setInt(1,salary);
            updateJob.setInt(2,job_id);
            int rowsAffected = updateJob.executeUpdate();
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }

        this.updateAvailableJobsTable();
    }//GEN-LAST:event_update_salary_BActionPerformed

    private void edit_recommendations_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_recommendations_BActionPerformed
        String recommendations;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        
        try {
            recommendations = update_recommendations_TF.getText();

            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateEmployeeRecommendations = con.prepareStatement("UPDATE employee SET recommendations=? WHERE username=?");
            updateEmployeeRecommendations.setString(1,recommendations);
            updateEmployeeRecommendations.setString(2,empl_username);           
            int rowsAffected = updateEmployeeRecommendations.executeUpdate();
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_edit_recommendations_BActionPerformed

    private void update_certificates_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_certificates_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_certificates_TFActionPerformed

    private void update_salary_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_salary_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_salary_TFActionPerformed

    private void update_recommendations_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_recommendations_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_recommendations_TFActionPerformed

    private void update_awards_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_awards_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_awards_TFActionPerformed

    private void employee_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employee_CBActionPerformed
        if (employee_CB_populated == true) {
            String employee;
            String empl_username;

            employee = (String)employee_CB.getSelectedItem();
            empl_username = employee.substring(0, employee.indexOf(":"));
            this.updateApplicationsTable(empl_username);
            this.updateCompleteEvaluationsTable(empl_username);
            this.updateReportTA(empl_username);
            this.populateComboBoxLanguages(empl_username);
            try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectRecommendations = con.prepareStatement("SELECT recommendations, certificates, awards FROM employee WHERE username=?");
            selectRecommendations.setString(1, empl_username);
            ResultSet resultRecommendations = selectRecommendations.executeQuery();
                       
            while (resultRecommendations.next()) {  
                update_recommendations_TF.setText(resultRecommendations.getString("recommendations"));
                update_certificates_TF.setText(resultRecommendations.getString("certificates"));
                update_awards_TF.setText(resultRecommendations.getString("awards"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        }
    }//GEN-LAST:event_employee_CBActionPerformed

    private void update_job_id_salary_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_job_id_salary_CBActionPerformed
        if (update_job_id_salary_CB_populated == true) {
            int salary;
            int job_id;
        
            job_id = Integer.parseInt((String)update_job_id_salary_CB.getSelectedItem());
            
            try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
                PreparedStatement selectSalary = con.prepareStatement("SELECT salary FROM job WHERE id=?");
                selectSalary.setInt(1, job_id);
                ResultSet resultSalary = selectSalary.executeQuery();

                while (resultSalary.next()) {   
                    salary = resultSalary.getInt("salary");
                    update_salary_TF.setText(String.valueOf(salary));
                }
            }
            catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
                ex.printStackTrace();
            }
            finally {
                if (con != null)
                try { con.close();}
                catch (SQLException ex) { ex.printStackTrace();}
            }
        }
    }//GEN-LAST:event_update_job_id_salary_CBActionPerformed

    private void edit_certificates_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_certificates_BActionPerformed
        String certificates;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        
        try {
            certificates = update_certificates_TF.getText();

            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateEmployeeCertificates = con.prepareStatement("UPDATE employee SET certificates=? WHERE username=?");
            updateEmployeeCertificates.setString(1,certificates);
            updateEmployeeCertificates.setString(2,empl_username);           
            int rowsAffected = updateEmployeeCertificates.executeUpdate();
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_edit_certificates_BActionPerformed

    private void edit_awards_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_awards_BActionPerformed
        String awards;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        
        try {
            awards = update_awards_TF.getText();

            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateEmployeeAwards = con.prepareStatement("UPDATE employee SET awards=? WHERE username=?");
            updateEmployeeAwards.setString(1,awards);
            updateEmployeeAwards.setString(2,empl_username);           
            int rowsAffected = updateEmployeeAwards.executeUpdate();
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_edit_awards_BActionPerformed

    private void remove_language_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_remove_language_BActionPerformed
        String language;
        int rowsAffected;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        language = (String)languages_CB.getSelectedItem();
        if (language.equals("English")) {
            language = "en";
        }
        else if (language.equals("French")) {
            language = "fr";
        }
        else if (language.equals("Spanish")) {
            language = "sp";
        }
        else if (language.equals("Greek")) {
            language = "gr";
        }
        try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);    
                
                this.sendUserInfo(con);
                
                PreparedStatement deleteLanguage = con.prepareStatement("DELETE FROM languages WHERE employee=? AND lang=?");
                deleteLanguage.setString(1,empl_username);
                deleteLanguage.setString(2,language);                
                rowsAffected = deleteLanguage.executeUpdate();
                System.out.println(rowsAffected);
                
                this.restoreUserInfo(con);
            }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Unexpected error. Try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_remove_language_BActionPerformed

    private void add_url_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_url_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_add_url_TFActionPerformed

    private void add_report_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_report_BActionPerformed
        String report;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime report_date;
        int rowsAffected;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        report = report_TA.getText();
        try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD); 
                
                this.sendUserInfo(con);
                
                report_date = LocalDateTime.now();
                if (!no_report) {
                    PreparedStatement updateReport = con.prepareStatement("UPDATE reports SET report=?, managerUsername=?, report_date=? WHERE employee=?");
                    updateReport.setString(1,report);
                    updateReport.setString(2,username);
                    updateReport.setString(3,dtf.format(report_date));
                    updateReport.setString(4,empl_username);
                    rowsAffected = updateReport.executeUpdate();
                }
                else {
                    PreparedStatement insertReport = con.prepareStatement("INSERT INTO reports VALUES(?,?,?,?)");
                    insertReport.setString(1,empl_username);
                    insertReport.setString(2,report);
                    insertReport.setString(3,username);
                    insertReport.setString(4,dtf.format(report_date));                 
                    rowsAffected = insertReport.executeUpdate();
                    no_report = false;
                }
                System.out.println(rowsAffected);
                
                this.restoreUserInfo(con);
            }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_add_report_BActionPerformed

    private void add_year_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_year_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_add_year_TFActionPerformed

    private void add_grade_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_grade_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_add_grade_TFActionPerformed

    private void add_degree_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_degree_BActionPerformed
        String institute;
        String title;
        String year;
        float grade;
        int rowsAffected;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        
        institute = (String)degr_institute_CB.getSelectedItem();
        title = (String)degr_title_CB.getSelectedItem();
        year = add_year_TF.getText();
        grade = Float.parseFloat(add_grade_TF.getText());
        
        add_year_TF.setText("");
        add_grade_TF.setText("");
        try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);    
                
                this.sendUserInfo(con);
                
                PreparedStatement insertHasDegree = con.prepareStatement("INSERT INTO has_degree VALUES(?,?,?,?,?)");
                insertHasDegree.setString(1,title);
                insertHasDegree.setString(2,institute);
                insertHasDegree.setString(3,empl_username);
                insertHasDegree.setString(4,year);
                insertHasDegree.setFloat(5,grade);
                rowsAffected = insertHasDegree.executeUpdate();
                System.out.println(rowsAffected);
                
                this.restoreUserInfo(con);
            }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_add_degree_BActionPerformed

    private void add_project_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_project_BActionPerformed
        String url;
        String description;
        int rowsAffected;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        
        url = add_url_TF.getText();
        description = descr_TA.getText();   
        
        add_url_TF.setText("");
        descr_TA.setText("");
        try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);    
                
                this.sendUserInfo(con);
                
                PreparedStatement insertProject = con.prepareStatement("INSERT INTO project VALUES(?,?,?,?)");
                insertProject.setNull(1, Types.NULL);
                insertProject.setString(2,empl_username);                 
                insertProject.setString(3,description);
                insertProject.setString(4,url);                
                rowsAffected = insertProject.executeUpdate();
                System.out.println(rowsAffected);
                
                this.restoreUserInfo(con);
            }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_add_project_BActionPerformed

    private void change_firm_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_change_firm_BActionPerformed
        new UpdateCompanyFrame(firm,username).setVisible(true);
    }//GEN-LAST:event_change_firm_BActionPerformed

    private void update_firm_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_firm_BActionPerformed
        this.updateCompanyInfo();
    }//GEN-LAST:event_update_firm_BActionPerformed

    private void languages_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_languages_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_languages_CBActionPerformed

    private void add_language_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_language_BActionPerformed
        String language;
        int rowsAffected;
        String employee;
        String empl_username;
        employee = (String)employee_CB.getSelectedItem();
        empl_username = employee.substring(0, employee.indexOf(":"));
        language = (String)languages_CB.getSelectedItem();
        if (language.equals("English")) {
            language = "en";
        }
        else if (language.equals("French")) {
            language = "fr";
        }
        else if (language.equals("Spanish")) {
            language = "sp";
        }
        else if (language.equals("Greek")) {
            language = "gr";
        }
        try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);    
                
                this.sendUserInfo(con);
                
                PreparedStatement insertLanguage = con.prepareStatement("INSERT INTO languages VALUES(?,?)");
                insertLanguage.setString(1,empl_username);
                insertLanguage.setString(2,language);                
                rowsAffected = insertLanguage.executeUpdate();
                System.out.println(rowsAffected);
                
                this.restoreUserInfo(con);
            }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Language already added.");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_add_language_BActionPerformed

    private void degr_title_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_degr_title_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_degr_title_CBActionPerformed

    private void degr_institute_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_degr_institute_CBActionPerformed
        if (employee_CB_populated == true) {
            this.populateComboBoxDegreeTitle((String)degr_institute_CB.getSelectedItem());
        }
    }//GEN-LAST:event_degr_institute_CBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagerProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagerProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagerProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagerProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagerProfileFrame(username, firm).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_degree_B;
    private javax.swing.JTextField add_grade_TF;
    private javax.swing.JButton add_language_B;
    private javax.swing.JButton add_project_B;
    private javax.swing.JButton add_report_B;
    private javax.swing.JTextField add_url_TF;
    private javax.swing.JTextField add_year_TF;
    private javax.swing.JLabel afm_L;
    private javax.swing.JLabel afm_field;
    private javax.swing.JScrollPane applications_scroll_panel;
    private javax.swing.JTable applications_table;
    private javax.swing.JScrollPane available_jobs_scroll_panel;
    private javax.swing.JTable available_jobs_table;
    private javax.swing.JLabel award_L;
    private javax.swing.JLabel brand_name_L;
    private javax.swing.JLabel brand_name_field;
    private javax.swing.JLabel certificates_L;
    private javax.swing.JButton change_B;
    private javax.swing.JButton change_firm_B;
    private javax.swing.JLabel city_L;
    private javax.swing.JLabel city_field;
    private javax.swing.JScrollPane complete_evaluations_scroll_panel;
    private javax.swing.JTable complete_evaluations_table;
    private javax.swing.JLabel country_L;
    private javax.swing.JLabel country_field;
    private javax.swing.JLabel degr_grade_L;
    private javax.swing.JComboBox<String> degr_institute_CB;
    private javax.swing.JLabel degr_institute_L;
    private javax.swing.JComboBox<String> degr_title_CB;
    private javax.swing.JLabel degr_title_L;
    private javax.swing.JLabel degr_year_L;
    private javax.swing.JLabel descr_L;
    private javax.swing.JScrollPane descr_SP;
    private javax.swing.JTextArea descr_TA;
    private javax.swing.JLabel doy_L;
    private javax.swing.JLabel doy_field;
    private javax.swing.JButton edit_awards_B;
    private javax.swing.JButton edit_certificates_B;
    private javax.swing.JButton edit_recommendations_B;
    private javax.swing.JLabel email_L;
    private javax.swing.JLabel email_field;
    private javax.swing.JComboBox<String> employee_CB;
    private javax.swing.JLabel employee_L;
    private javax.swing.JLabel employees_L;
    private javax.swing.JPanel employees_panel;
    private javax.swing.JLabel employees_subL;
    private javax.swing.JPanel employees_subpanel;
    private javax.swing.JLabel evaluation_L;
    private javax.swing.JPanel evaluation_panel;
    private javax.swing.JLabel evaluation_subL;
    private javax.swing.JPanel evaluation_subpanel;
    private javax.swing.JScrollPane evaluators_scroll_panel;
    private javax.swing.JTable evaluators_table;
    private javax.swing.JLabel exit_subL;
    private javax.swing.JPanel exit_subpanel;
    private javax.swing.JLabel exp_years_L;
    private javax.swing.JLabel exp_years_field;
    private javax.swing.JScrollPane final_evaluation_scroll_panel;
    private javax.swing.JTable final_evaluation_table;
    private javax.swing.JLabel firm_L;
    private javax.swing.JLabel firm_field;
    private javax.swing.JComboBox<String> languages_CB;
    private javax.swing.JLabel languages_L;
    private javax.swing.JLabel logo_L;
    private javax.swing.JPanel logo_panel;
    private javax.swing.JPanel main_panel;
    private javax.swing.JLabel my_firm_L;
    private javax.swing.JPanel my_firm_panel;
    private javax.swing.JLabel my_firm_subL;
    private javax.swing.JPanel my_firm_subpanel;
    private javax.swing.JLabel name_L;
    private javax.swing.JLabel name_field;
    private javax.swing.JLabel password_L;
    private javax.swing.JLabel password_field;
    private javax.swing.JLabel profile_L;
    private javax.swing.JPanel profile_panel;
    private javax.swing.JLabel profile_subL;
    private javax.swing.JPanel profile_subpanel;
    private javax.swing.JLabel recommendations_L;
    private javax.swing.JLabel reg_date_L;
    private javax.swing.JLabel reg_date_field;
    private javax.swing.JButton remove_language_B;
    private javax.swing.JLabel report_L;
    private javax.swing.JScrollPane report_SP;
    private javax.swing.JTextArea report_TA;
    private javax.swing.JLabel street_L;
    private javax.swing.JLabel street_field;
    private javax.swing.JLabel street_no_L;
    private javax.swing.JLabel street_no_field;
    private javax.swing.JLabel surname_L;
    private javax.swing.JLabel surname_field;
    private javax.swing.JLabel telephone_L;
    private javax.swing.JLabel telephone_field;
    private javax.swing.JPanel title_panel;
    private javax.swing.JPanel title_panel1;
    private javax.swing.JPanel title_panel2;
    private javax.swing.JPanel title_panel3;
    private javax.swing.JButton update_B;
    private javax.swing.JTextField update_awards_TF;
    private javax.swing.JTextField update_certificates_TF;
    private javax.swing.JButton update_firm_B;
    private javax.swing.JLabel update_job_id_L1;
    private javax.swing.JComboBox<String> update_job_id_salary_CB;
    private javax.swing.JTextField update_recommendations_TF;
    private javax.swing.JButton update_salary_B;
    private javax.swing.JLabel update_salary_L;
    private javax.swing.JTextField update_salary_TF;
    private javax.swing.JLabel url_L;
    private javax.swing.JLabel username_L;
    private javax.swing.JLabel username_field;
    // End of variables declaration//GEN-END:variables
}
