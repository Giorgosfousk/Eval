package EVaLgui;

import java.sql.*;
import javax.swing.*;

public class AddSubjectFrame extends javax.swing.JFrame {

    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static EvaluatorProfileFrame frame;
    
    public AddSubjectFrame() {
        initComponents();
        this.populateComboBoxBelongs();
    }

    private void populateComboBoxBelongs() {       
        belongs_CB.removeAllItems();
        try {           
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectSubject = con.prepareStatement("SELECT title FROM subject");
            ResultSet resultSubject = selectSubject.executeQuery();
            
            belongs_CB.addItem("None");
            while (resultSubject.next()) {               
                belongs_CB.addItem(resultSubject.getString("title"));               
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        main_panel = new javax.swing.JPanel();
        add_subject_L = new javax.swing.JLabel();
        title_L = new javax.swing.JLabel();
        descr_L = new javax.swing.JLabel();
        belongs_L = new javax.swing.JLabel();
        title_TF = new javax.swing.JTextField();
        descr_TF = new javax.swing.JTextField();
        add_subject_B = new javax.swing.JButton();
        belongs_CB = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        main_panel.setBackground(new java.awt.Color(166, 77, 255));

        add_subject_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        add_subject_L.setForeground(new java.awt.Color(255, 255, 255));
        add_subject_L.setText("Add New Subject");

        javax.swing.GroupLayout main_panelLayout = new javax.swing.GroupLayout(main_panel);
        main_panel.setLayout(main_panelLayout);
        main_panelLayout.setHorizontalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(add_subject_L)
                .addGap(162, 162, 162))
        );
        main_panelLayout.setVerticalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(add_subject_L)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        title_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        title_L.setForeground(new java.awt.Color(77, 77, 77));
        title_L.setText("Title:");

        descr_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        descr_L.setForeground(new java.awt.Color(77, 77, 77));
        descr_L.setText("Description:");

        belongs_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        belongs_L.setForeground(new java.awt.Color(77, 77, 77));
        belongs_L.setText("Category:");

        title_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        title_TF.setForeground(new java.awt.Color(77, 77, 77));
        title_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                title_TFActionPerformed(evt);
            }
        });

        descr_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        descr_TF.setForeground(new java.awt.Color(77, 77, 77));
        descr_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descr_TFActionPerformed(evt);
            }
        });

        add_subject_B.setBackground(new java.awt.Color(102, 0, 204));
        add_subject_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_subject_B.setForeground(new java.awt.Color(255, 255, 255));
        add_subject_B.setText("Add");
        add_subject_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_subject_BActionPerformed(evt);
            }
        });

        belongs_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        belongs_CB.setForeground(new java.awt.Color(77, 77, 77));
        belongs_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        belongs_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                belongs_CBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(add_subject_B)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(title_L)
                        .addGap(99, 99, 99)
                        .addComponent(title_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(belongs_L)
                            .addComponent(descr_L))
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(belongs_CB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(descr_TF))))
                .addGap(132, 132, 132))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(134, 134, 134)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(title_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(title_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(descr_L)
                    .addComponent(descr_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(belongs_L)
                    .addComponent(belongs_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 119, Short.MAX_VALUE)
                .addComponent(add_subject_B)
                .addGap(49, 49, 49))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void title_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_title_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_title_TFActionPerformed

    private void descr_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descr_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_descr_TFActionPerformed

    private void add_subject_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_subject_BActionPerformed

        String title;
        String descr;
        String belongs;
        String none = "None";
        title = title_TF.getText();
        descr = descr_TF.getText();
        belongs = (String)belongs_CB.getSelectedItem();
        
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement insertSubject = con.prepareStatement("INSERT INTO subject VALUES (?,?,?)");
            insertSubject.setString(1,title);
            insertSubject.setString(2,descr);
            if (none.equalsIgnoreCase((String)belongs_CB.getSelectedItem())) {
                insertSubject.setNull(3,Types.NULL);
            }
            else {
                insertSubject.setString(3,belongs);
            }
            int rowsAffected = insertSubject.executeUpdate();
            System.out.println(rowsAffected);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        
        JOptionPane.showMessageDialog(null, "Subject added successfully");
        this.populateComboBoxBelongs();
    }//GEN-LAST:event_add_subject_BActionPerformed

    private void belongs_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_belongs_CBActionPerformed
        
    }//GEN-LAST:event_belongs_CBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddSubjectFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddSubjectFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddSubjectFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddSubjectFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddSubjectFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_subject_B;
    private javax.swing.JLabel add_subject_L;
    private javax.swing.JComboBox<String> belongs_CB;
    private javax.swing.JLabel belongs_L;
    private javax.swing.JLabel descr_L;
    private javax.swing.JTextField descr_TF;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel main_panel;
    private javax.swing.JLabel title_L;
    private javax.swing.JTextField title_TF;
    // End of variables declaration//GEN-END:variables
}
