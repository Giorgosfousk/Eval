package EVaLgui;

import java.sql.*;
import javax.swing.*;

public class UpdateCompanyFrame extends javax.swing.JFrame {

    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static String firm;
    private static String username;
    
    public UpdateCompanyFrame(String in_firm, String in_username) {
        this.firm = in_firm;
        this.username = in_username;
        initComponents();
        
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement selectCompany = con.prepareStatement("SELECT DOY, name, phone, street, num, city, country FROM company WHERE AFM=?");
            selectCompany.setString(1, firm);
            ResultSet resultCompany = selectCompany.executeQuery();

            while (resultCompany.next()) {  
                afm_TF.setText(firm);
                doy_TF.setText(resultCompany.getString("DOY"));
                brand_name_TF.setText(resultCompany.getString("name"));
                telephone_TF.setText(resultCompany.getString("phone"));
                street_TF.setText(resultCompany.getString("street"));
                street_no_TF.setText(resultCompany.getString("num"));
                city_TF.setText(resultCompany.getString("city"));  
                country_TF.setText(resultCompany.getString("country"));
            }                                    
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
  
    private void sendUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, username);  
        callSetCurrentUser.execute();
    }
   
    private void restoreUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, "local_admin");  
        callSetCurrentUser.execute();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        main_panel = new javax.swing.JPanel();
        company_L = new javax.swing.JLabel();
        afm_L = new javax.swing.JLabel();
        doy_L = new javax.swing.JLabel();
        brand_name_L = new javax.swing.JLabel();
        telephone_L = new javax.swing.JLabel();
        street_L = new javax.swing.JLabel();
        street_no_L = new javax.swing.JLabel();
        country_L = new javax.swing.JLabel();
        city_L = new javax.swing.JLabel();
        afm_TF = new javax.swing.JTextField();
        doy_TF = new javax.swing.JTextField();
        brand_name_TF = new javax.swing.JTextField();
        telephone_TF = new javax.swing.JTextField();
        street_TF = new javax.swing.JTextField();
        street_no_TF = new javax.swing.JTextField();
        country_TF = new javax.swing.JTextField();
        city_TF = new javax.swing.JTextField();
        update_company_B = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        main_panel.setBackground(new java.awt.Color(166, 77, 255));

        company_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        company_L.setForeground(new java.awt.Color(255, 255, 255));
        company_L.setText("Update Company Information");

        javax.swing.GroupLayout main_panelLayout = new javax.swing.GroupLayout(main_panel);
        main_panel.setLayout(main_panelLayout);
        main_panelLayout.setHorizontalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_panelLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(company_L)
                .addContainerGap(65, Short.MAX_VALUE))
        );
        main_panelLayout.setVerticalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_panelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(company_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        afm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        afm_L.setForeground(new java.awt.Color(77, 77, 77));
        afm_L.setText("AFM:");

        doy_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        doy_L.setForeground(new java.awt.Color(77, 77, 77));
        doy_L.setText("DOY:");

        brand_name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        brand_name_L.setForeground(new java.awt.Color(77, 77, 77));
        brand_name_L.setText("Brand Name:");

        telephone_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        telephone_L.setForeground(new java.awt.Color(77, 77, 77));
        telephone_L.setText("Telephone:");

        street_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_L.setForeground(new java.awt.Color(77, 77, 77));
        street_L.setText("Street Address:");

        street_no_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_no_L.setForeground(new java.awt.Color(77, 77, 77));
        street_no_L.setText("Street No:");

        country_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        country_L.setForeground(new java.awt.Color(77, 77, 77));
        country_L.setText("Country:");

        city_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        city_L.setForeground(new java.awt.Color(77, 77, 77));
        city_L.setText("City:");

        afm_TF.setEditable(false);
        afm_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        afm_TF.setForeground(new java.awt.Color(77, 77, 77));
        afm_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                afm_TFActionPerformed(evt);
            }
        });

        doy_TF.setEditable(false);
        doy_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        doy_TF.setForeground(new java.awt.Color(77, 77, 77));
        doy_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doy_TFActionPerformed(evt);
            }
        });

        brand_name_TF.setEditable(false);
        brand_name_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        brand_name_TF.setForeground(new java.awt.Color(77, 77, 77));
        brand_name_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brand_name_TFActionPerformed(evt);
            }
        });

        telephone_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        telephone_TF.setForeground(new java.awt.Color(77, 77, 77));
        telephone_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telephone_TFActionPerformed(evt);
            }
        });

        street_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_TF.setForeground(new java.awt.Color(77, 77, 77));
        street_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                street_TFActionPerformed(evt);
            }
        });

        street_no_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        street_no_TF.setForeground(new java.awt.Color(77, 77, 77));
        street_no_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                street_no_TFActionPerformed(evt);
            }
        });

        country_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        country_TF.setForeground(new java.awt.Color(77, 77, 77));
        country_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                country_TFActionPerformed(evt);
            }
        });

        city_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        city_TF.setForeground(new java.awt.Color(77, 77, 77));
        city_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                city_TFActionPerformed(evt);
            }
        });

        update_company_B.setBackground(new java.awt.Color(102, 0, 204));
        update_company_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_company_B.setForeground(new java.awt.Color(255, 255, 255));
        update_company_B.setText("Update");
        update_company_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_company_BActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(update_company_B)
                .addGap(10, 10, 10))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(afm_L)
                        .addGap(78, 78, 78)
                        .addComponent(afm_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(doy_L)
                        .addGap(78, 78, 78)
                        .addComponent(doy_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(brand_name_L)
                        .addGap(31, 31, 31)
                        .addComponent(brand_name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(telephone_L)
                        .addGap(44, 44, 44)
                        .addComponent(telephone_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(street_L)
                        .addGap(18, 18, 18)
                        .addComponent(street_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(street_no_L)
                        .addGap(49, 49, 49)
                        .addComponent(street_no_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(country_L)
                        .addGap(57, 57, 57)
                        .addComponent(country_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(city_L)
                        .addGap(83, 83, 83)
                        .addComponent(city_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(afm_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(afm_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(doy_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(doy_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(brand_name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(brand_name_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(telephone_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(telephone_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(street_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(street_L))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(street_no_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(street_no_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(city_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(city_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(country_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(country_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 137, Short.MAX_VALUE)
                .addComponent(update_company_B)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void afm_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_afm_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_afm_TFActionPerformed

    private void doy_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doy_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_doy_TFActionPerformed

    private void brand_name_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brand_name_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_brand_name_TFActionPerformed

    private void telephone_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telephone_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telephone_TFActionPerformed

    private void street_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_street_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_street_TFActionPerformed

    private void street_no_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_street_no_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_street_no_TFActionPerformed

    private void country_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_country_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_country_TFActionPerformed

    private void city_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_city_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_city_TFActionPerformed

    private void update_company_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_company_BActionPerformed
        String doy;
        String brand_name;
        Long telephone;
        String street;
        int street_no;
        String city;
        String country;

        doy = doy_TF.getText();
        brand_name = brand_name_TF.getText();
        telephone = Long.parseLong(telephone_TF.getText());
        street = street_TF.getText();   
        street_no = Integer.parseInt(street_no_TF.getText());
        city = city_TF.getText(); 
        country = country_TF.getText();

        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateCompany = con.prepareStatement("UPDATE company SET phone=?, street=?, num=?, city=?, country=? WHERE AFM=?");
            updateCompany.setLong(1,telephone);
            updateCompany.setString(2,street);
            updateCompany.setInt(3,street_no);
            updateCompany.setString(4,city);
            updateCompany.setString(5,country);
            updateCompany.setString(6,firm);
            
            int rowsAffected = updateCompany.executeUpdate();
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }

        this.dispose();
    }//GEN-LAST:event_update_company_BActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateCompanyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateCompanyFrame(firm,username).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel afm_L;
    private javax.swing.JTextField afm_TF;
    private javax.swing.JLabel brand_name_L;
    private javax.swing.JTextField brand_name_TF;
    private javax.swing.JLabel city_L;
    private javax.swing.JTextField city_TF;
    private javax.swing.JLabel company_L;
    private javax.swing.JLabel country_L;
    private javax.swing.JTextField country_TF;
    private javax.swing.JLabel doy_L;
    private javax.swing.JTextField doy_TF;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel main_panel;
    private javax.swing.JLabel street_L;
    private javax.swing.JTextField street_TF;
    private javax.swing.JLabel street_no_L;
    private javax.swing.JTextField street_no_TF;
    private javax.swing.JLabel telephone_L;
    private javax.swing.JTextField telephone_TF;
    private javax.swing.JButton update_company_B;
    // End of variables declaration//GEN-END:variables
}
