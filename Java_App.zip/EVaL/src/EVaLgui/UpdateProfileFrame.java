package EVaLgui;

import java.sql.*;
import javax.swing.*;

public class UpdateProfileFrame extends javax.swing.JFrame {

    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static String username;
    private static int type; // 0 for admin, 1 for evaluator, 2 for manager, 3 for employee

    public UpdateProfileFrame(String in_username, int in_type) {
        initComponents();
        this.username = in_username;
        this.type = in_type;
        bio_L.setVisible(false);
        bio_SP.setVisible(false);
        bio_TA.setVisible(false);
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement selectUserInfo = con.prepareStatement("SELECT name, surname, email, password, reg_date, firm FROM user WHERE username=?");
            selectUserInfo.setString(1, username);
            ResultSet resultUserInfo = selectUserInfo.executeQuery();
            
            PreparedStatement selectEvaluatorInfo = con.prepareStatement("SELECT exp_years FROM evaluator WHERE username=?");
            selectEvaluatorInfo.setString(1, username);
            ResultSet resultEvaluatorInfo = selectEvaluatorInfo.executeQuery();
            
            PreparedStatement selectManagerInfo = con.prepareStatement("SELECT exp_years FROM manager WHERE managerUsername=?");
            selectManagerInfo.setString(1, username);
            ResultSet resultManagerInfo = selectManagerInfo.executeQuery();
            
            PreparedStatement selectEmployeeInfo = con.prepareStatement("SELECT bio, exp_years FROM employee WHERE username=?");
            selectEmployeeInfo.setString(1, username);
            ResultSet resultEmployeeInfo = selectEmployeeInfo.executeQuery();

            while (resultUserInfo.next()) {  
                username_TF.setText(username);
                name_TF.setText(resultUserInfo.getString("name"));
                surname_TF.setText(resultUserInfo.getString("surname"));
                email_TF.setText(resultUserInfo.getString("email"));
                password_TF.setText(resultUserInfo.getString("password"));
                reg_date_TF.setText(resultUserInfo.getString("reg_date"));
                firm_TF.setText(resultUserInfo.getString("firm"));      
            }                         
            
            if (type == 0) {               
                exp_years_TF.setText("0");
            }
            
            if (type == 1) {
                while (resultEvaluatorInfo.next()) {
                    exp_years_TF.setText(resultEvaluatorInfo.getString("exp_years"));
                }
            }     
            
            if (type == 2) {
                while (resultManagerInfo.next()) {
                    exp_years_TF.setText(resultManagerInfo.getString("exp_years"));
                }
            } 
            
            if (type == 3) {
                while (resultEmployeeInfo.next()) {
                    exp_years_TF.setText(resultEmployeeInfo.getString("exp_years"));
                    bio_TA.setText(resultEmployeeInfo.getString("bio"));
                }
            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        
        if (type == 0) {
                exp_years_L.setVisible(false);
                exp_years_TF.setVisible(false);
                firm_TF.setEditable(true);
            }
        
        if (type == 1)
        {
            //System.out.println("Evaluator");        
        }
        
        if (type == 2)
        {   
            bio_L.setVisible(false);
            bio_SP.setVisible(false);
            bio_TA.setVisible(false);
            name_TF.setEditable(false);
            surname_TF.setEditable(false);
            email_TF.setEditable(true);
            password_TF.setEditable(true);
            exp_years_TF.setEditable(false);
        }
        
        if (type == 3)
        {
            name_TF.setEditable(false);
            surname_TF.setEditable(false);
            email_TF.setEditable(false);
            password_TF.setEditable(true);
            exp_years_TF.setEditable(false);
            bio_L.setVisible(true);
            bio_SP.setVisible(true);
            bio_TA.setVisible(true);
        }
        this.revalidate();
        this.repaint();
    }

    private void sendUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, username);  
        callSetCurrentUser.execute();
    }
   
    private void restoreUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, "local_admin");  
        callSetCurrentUser.execute();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        main_panel = new javax.swing.JPanel();
        profile_L = new javax.swing.JLabel();
        username_L = new javax.swing.JLabel();
        name_L = new javax.swing.JLabel();
        surname_L = new javax.swing.JLabel();
        email_L = new javax.swing.JLabel();
        password_L = new javax.swing.JLabel();
        reg_date_L = new javax.swing.JLabel();
        exp_years_L = new javax.swing.JLabel();
        firm_L = new javax.swing.JLabel();
        username_TF = new javax.swing.JTextField();
        name_TF = new javax.swing.JTextField();
        surname_TF = new javax.swing.JTextField();
        email_TF = new javax.swing.JTextField();
        password_TF = new javax.swing.JTextField();
        reg_date_TF = new javax.swing.JTextField();
        exp_years_TF = new javax.swing.JTextField();
        firm_TF = new javax.swing.JTextField();
        update_profile_B = new javax.swing.JButton();
        bio_L = new javax.swing.JLabel();
        bio_SP = new javax.swing.JScrollPane();
        bio_TA = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        main_panel.setBackground(new java.awt.Color(166, 77, 255));

        profile_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        profile_L.setForeground(new java.awt.Color(255, 255, 255));
        profile_L.setText("Update Profile Information");

        javax.swing.GroupLayout main_panelLayout = new javax.swing.GroupLayout(main_panel);
        main_panel.setLayout(main_panelLayout);
        main_panelLayout.setHorizontalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_panelLayout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(profile_L)
                .addContainerGap(90, Short.MAX_VALUE))
        );
        main_panelLayout.setVerticalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(profile_L)
                .addGap(19, 19, 19))
        );

        username_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_L.setForeground(new java.awt.Color(77, 77, 77));
        username_L.setText("Username:");

        name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_L.setForeground(new java.awt.Color(77, 77, 77));
        name_L.setText("Name:");

        surname_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_L.setForeground(new java.awt.Color(77, 77, 77));
        surname_L.setText("Surname:");

        email_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_L.setForeground(new java.awt.Color(77, 77, 77));
        email_L.setText("Email:");

        password_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_L.setForeground(new java.awt.Color(77, 77, 77));
        password_L.setText("Password:");

        reg_date_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_L.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_L.setText("Date of Registration:");

        exp_years_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_L.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_L.setText("Years of Experience:");

        firm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_L.setForeground(new java.awt.Color(77, 77, 77));
        firm_L.setText("Firm:");

        username_TF.setEditable(false);
        username_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_TF.setForeground(new java.awt.Color(77, 77, 77));
        username_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                username_TFActionPerformed(evt);
            }
        });

        name_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_TF.setForeground(new java.awt.Color(77, 77, 77));
        name_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name_TFActionPerformed(evt);
            }
        });

        surname_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_TF.setForeground(new java.awt.Color(77, 77, 77));
        surname_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                surname_TFActionPerformed(evt);
            }
        });

        email_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_TF.setForeground(new java.awt.Color(77, 77, 77));
        email_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                email_TFActionPerformed(evt);
            }
        });

        password_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_TF.setForeground(new java.awt.Color(77, 77, 77));
        password_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                password_TFActionPerformed(evt);
            }
        });

        reg_date_TF.setEditable(false);
        reg_date_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_TF.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reg_date_TFActionPerformed(evt);
            }
        });

        exp_years_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_TF.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exp_years_TFActionPerformed(evt);
            }
        });

        firm_TF.setEditable(false);
        firm_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_TF.setForeground(new java.awt.Color(77, 77, 77));
        firm_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firm_TFActionPerformed(evt);
            }
        });

        update_profile_B.setBackground(new java.awt.Color(102, 0, 204));
        update_profile_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_profile_B.setForeground(new java.awt.Color(255, 255, 255));
        update_profile_B.setText("Update");
        update_profile_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_profile_BActionPerformed(evt);
            }
        });

        bio_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        bio_L.setForeground(new java.awt.Color(77, 77, 77));
        bio_L.setText("Bio:");

        bio_TA.setColumns(20);
        bio_TA.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        bio_TA.setForeground(new java.awt.Color(77, 77, 77));
        bio_TA.setLineWrap(true);
        bio_TA.setRows(5);
        bio_SP.setViewportView(bio_TA);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(update_profile_B))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(firm_L)
                            .addComponent(reg_date_L)
                            .addComponent(exp_years_L)
                            .addComponent(bio_L)
                            .addComponent(password_L)
                            .addComponent(email_L)
                            .addComponent(surname_L)
                            .addComponent(name_L)
                            .addComponent(username_L))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                .addComponent(exp_years_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(firm_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(reg_date_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(password_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(email_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(surname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(username_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(bio_SP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(surname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(surname_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_L))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reg_date_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reg_date_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firm_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(firm_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exp_years_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exp_years_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bio_SP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bio_L))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(update_profile_B)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void username_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_username_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_username_TFActionPerformed

    private void name_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_name_TFActionPerformed

    private void surname_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_surname_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_surname_TFActionPerformed

    private void email_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_email_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_email_TFActionPerformed

    private void password_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_password_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_password_TFActionPerformed

    private void reg_date_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reg_date_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_reg_date_TFActionPerformed

    private void exp_years_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exp_years_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_exp_years_TFActionPerformed

    private void firm_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firm_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firm_TFActionPerformed

    private void update_profile_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_profile_BActionPerformed

        String name;
        String surname;
        String email;
        String password;
        String bio;
        String firm;
        int exp_years = 0;
       
        name = name_TF.getText();
        surname = surname_TF.getText();
        email = email_TF.getText();
        password = password_TF.getText();       
        if (type == 1 || type == 2 || type == 3) {
            exp_years = Integer.parseInt(exp_years_TF.getText());
        }
        bio = bio_TA.getText();   
        firm = firm_TF.getText();
                
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateUser = con.prepareStatement("UPDATE user SET password=?, name=?, surname=?, email=? WHERE username=?");
            updateUser.setString(1,password);
            updateUser.setString(2,name);
            updateUser.setString(3,surname);
            updateUser.setString(4,email);
            updateUser.setString(5,username);
            int rowsAffected = updateUser.executeUpdate();
            
            if (type == 0) {
                PreparedStatement updateAdmin = con.prepareStatement("UPDATE user SET firm=? WHERE username=?");
                updateAdmin.setString(1,firm);
                updateAdmin.setString(2,username);
                rowsAffected = updateAdmin.executeUpdate();
            }
            
            if (type == 1) {
                PreparedStatement updateEvaluator = con.prepareStatement("UPDATE evaluator SET exp_years=? WHERE username=?");
                updateEvaluator.setInt(1,exp_years);
                updateEvaluator.setString(2,username);
                rowsAffected = updateEvaluator.executeUpdate();
            }
            
            if (type == 2) {
                PreparedStatement updateManager = con.prepareStatement("UPDATE manager SET exp_years=? WHERE managerUsername=?");
                updateManager.setInt(1,exp_years);
                updateManager.setString(2,username);
                rowsAffected = updateManager.executeUpdate();
            }
            
            if (type == 3) {
                PreparedStatement updateEmployee = con.prepareStatement("UPDATE employee SET bio=?, exp_years=? WHERE username=?");
                updateEmployee.setString(1,bio);
                updateEmployee.setInt(2,exp_years);
                updateEmployee.setString(3,username);
                rowsAffected = updateEmployee.executeUpdate();
            }
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
             
        this.dispose();
    }//GEN-LAST:event_update_profile_BActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateProfileFrame(username, type).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bio_L;
    private javax.swing.JScrollPane bio_SP;
    private javax.swing.JTextArea bio_TA;
    private javax.swing.JLabel email_L;
    private javax.swing.JTextField email_TF;
    private javax.swing.JLabel exp_years_L;
    private javax.swing.JTextField exp_years_TF;
    private javax.swing.JLabel firm_L;
    private javax.swing.JTextField firm_TF;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel main_panel;
    private javax.swing.JLabel name_L;
    private javax.swing.JTextField name_TF;
    private javax.swing.JLabel password_L;
    private javax.swing.JTextField password_TF;
    private javax.swing.JLabel profile_L;
    private javax.swing.JLabel reg_date_L;
    private javax.swing.JTextField reg_date_TF;
    private javax.swing.JLabel surname_L;
    private javax.swing.JTextField surname_TF;
    private javax.swing.JButton update_profile_B;
    private javax.swing.JLabel username_L;
    private javax.swing.JTextField username_TF;
    // End of variables declaration//GEN-END:variables
}
