package EVaLgui;

import java.awt.Color;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminProfileFrame extends javax.swing.JFrame {

    private static String username;
    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private DefaultTableModel model_companies;    
    private DefaultTableModel model_users; 
    private DefaultTableModel model_log;
    private static boolean edit_afm_CB_populated;
    private static boolean username_CB_populated;
    private static boolean firm_CB_populated;
    
    public AdminProfileFrame(String login_username) {
        initComponents();
        this.username = login_username;
        profile_panel.setVisible(true);
        my_group_panel.setVisible(false);
        users_panel.setVisible(false);
        log_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        username_field.setText(username);       
        this.updateProfile();
        this.updateCompaniesTable();
        this.populateComboBoxEditAFM();
        this.updateUsersTable();
        this.populateComboBoxFirm();
        this.populateComboBoxType();
        this.populateComboBoxUsername();
        this.updateLogTable();
    }

    private void sendUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, username);  
        callSetCurrentUser.execute();
    }
   
    private void restoreUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, "local_admin");  
        callSetCurrentUser.execute();
    }
    
    private void updateProfile() {
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectUserInfo = con.prepareStatement("SELECT name, surname, email, password, reg_date, firm FROM user WHERE username LIKE ?");
            selectUserInfo.setString(1, username);
            ResultSet resultUserInfo = selectUserInfo.executeQuery();
            
            while (resultUserInfo.next()) {           
                name_field.setText(resultUserInfo.getString("name"));
                surname_field.setText(resultUserInfo.getString("surname"));
                email_field.setText(resultUserInfo.getString("email"));
                password_field.setText(resultUserInfo.getString("password").replaceAll(".", "*"));
                reg_date_field.setText(resultUserInfo.getString("reg_date"));
                firm_field.setText(resultUserInfo.getString("firm"));      
            }            
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateCompaniesTable() {
        model_companies = (DefaultTableModel) companies_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectCompanies = con.prepareStatement("SELECT * FROM company ORDER BY AFM ASC");
            ResultSet resultCompanies = selectCompanies.executeQuery();           
            model_companies.setRowCount(0);
            while (resultCompanies.next()) {
                model_companies.insertRow(model_companies.getRowCount(), new Object[]{resultCompanies.getString("AFM"),resultCompanies.getString("DOY"),resultCompanies.getString("name"),resultCompanies.getLong("phone"),resultCompanies.getString("street"),resultCompanies.getInt("num"),resultCompanies.getString("city"),resultCompanies.getString("country")});
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateUsersTable() {
        String user_type = "User";
        String admin_bool = "0";
        String admin = "No";
        model_users = (DefaultTableModel) users_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectUsers = con.prepareStatement("SELECT username, password, name, surname, reg_date, email, firm, admin_rights FROM user ORDER BY username ASC");
            ResultSet resultUsers = selectUsers.executeQuery();           
            model_users.setRowCount(0);
            while (resultUsers.next()) {
                admin = "No";
                PreparedStatement selectEvaluator = con.prepareStatement("SELECT username FROM evaluator WHERE username=?");
                selectEvaluator.setString(1, resultUsers.getString("username"));
                ResultSet resultEvaluator = selectEvaluator.executeQuery();
                
                PreparedStatement selectManager = con.prepareStatement("SELECT managerUsername FROM manager WHERE managerUsername=?");
                selectManager.setString(1, resultUsers.getString("username"));
                ResultSet resultManager = selectManager.executeQuery();
                
                PreparedStatement selectEmployee = con.prepareStatement("SELECT username FROM employee WHERE username=?");
                selectEmployee.setString(1, resultUsers.getString("username"));
                ResultSet resultEmployee = selectEmployee.executeQuery();
                
                if (resultEvaluator.next()) {
                    user_type = "Evaluator";
                }
                else if (resultManager.next()) {
                    user_type = "Manager";
                }
                else if (resultEmployee.next()) {
                    user_type = "Employee";
                }
                else {
                    user_type = "User";
                }
                if (!admin_bool.equals((resultUsers.getString("admin_rights")))) {
                    user_type = "Admin";
                    admin = "Yes";
                }
                model_users.insertRow(model_users.getRowCount(), new Object[]{resultUsers.getString("username"),resultUsers.getString("password"),resultUsers.getString("name"),resultUsers.getString("surname"),resultUsers.getString("email"),resultUsers.getString("firm"),user_type,admin,resultUsers.getString("reg_date")});
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateLogTable() {
        model_log = (DefaultTableModel) log_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectLogEntries = con.prepareStatement("SELECT username, log_text, log_date, table_affected, action, done FROM log");
            ResultSet resultLogEntries = selectLogEntries.executeQuery();           
            model_log.setRowCount(0);
            while (resultLogEntries.next()) {
                model_log.insertRow(model_log.getRowCount(), new Object[]{resultLogEntries.getString("log_date"),resultLogEntries.getString("username"),resultLogEntries.getString("log_text"),resultLogEntries.getString("table_affected"),resultLogEntries.getString("action"),resultLogEntries.getString("done")});
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void populateComboBoxEditAFM() {       
        edit_afm_CB_populated = false;
        edit_afm_CB.removeAllItems();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectCompanyAFM = con.prepareStatement("SELECT afm FROM company");
            ResultSet resultCompanyAFM = selectCompanyAFM.executeQuery();
                       
            while (resultCompanyAFM.next()) {               
                edit_afm_CB.addItem(resultCompanyAFM.getString("afm"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        edit_afm_CB_populated = true;
    }
    
    private void populateComboBoxFirm() {       
        firm_CB_populated = false;
        create_firm_CB.removeAllItems();
        edit_firm_CB.removeAllItems();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectCompanyAFM = con.prepareStatement("SELECT afm FROM company");
            ResultSet resultCompanyAFM = selectCompanyAFM.executeQuery();
                       
            while (resultCompanyAFM.next()) {               
                create_firm_CB.addItem(resultCompanyAFM.getString("afm"));
                edit_firm_CB.addItem(resultCompanyAFM.getString("afm"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        firm_CB_populated = true;
    }
    
    private void populateComboBoxType() {       
        create_type_CB.removeAllItems();
        create_type_CB.addItem("Evaluator");
        create_type_CB.addItem("Manager");
        create_type_CB.addItem("Employee");
        create_type_CB.addItem("Admin");       
    }
    
    private void populateComboBoxUsername() {       
        username_CB_populated = false;
        edit_username_CB.removeAllItems();     
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectUsername = con.prepareStatement("SELECT username FROM user ORDER BY username ASC");
            ResultSet resultUsername = selectUsername.executeQuery();
                       
            while (resultUsername.next()) {               
                edit_username_CB.addItem(resultUsername.getString("username"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        username_CB_populated = true;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logo_panel = new javax.swing.JPanel();
        logo_L = new javax.swing.JLabel();
        profile_subpanel = new javax.swing.JPanel();
        profile_subL = new javax.swing.JLabel();
        my_group_subpanel = new javax.swing.JPanel();
        my_group_subL = new javax.swing.JLabel();
        users_subpanel = new javax.swing.JPanel();
        users_subL = new javax.swing.JLabel();
        log_subpanel = new javax.swing.JPanel();
        log_subL = new javax.swing.JLabel();
        exit_subpanel = new javax.swing.JPanel();
        exit_subL = new javax.swing.JLabel();
        main_panel = new javax.swing.JPanel();
        profile_panel = new javax.swing.JPanel();
        username_L = new javax.swing.JLabel();
        name_L = new javax.swing.JLabel();
        surname_L = new javax.swing.JLabel();
        email_L = new javax.swing.JLabel();
        password_L = new javax.swing.JLabel();
        reg_date_L = new javax.swing.JLabel();
        firm_L = new javax.swing.JLabel();
        update_B = new javax.swing.JButton();
        change_B = new javax.swing.JButton();
        username_field = new javax.swing.JLabel();
        name_field = new javax.swing.JLabel();
        surname_field = new javax.swing.JLabel();
        email_field = new javax.swing.JLabel();
        reg_date_field = new javax.swing.JLabel();
        password_field = new javax.swing.JLabel();
        firm_field = new javax.swing.JLabel();
        title_panel = new javax.swing.JPanel();
        profile_L = new javax.swing.JLabel();
        my_group_panel = new javax.swing.JPanel();
        title_panel1 = new javax.swing.JPanel();
        my_group_L = new javax.swing.JLabel();
        companies_scroll_panel = new javax.swing.JScrollPane();
        companies_table = new javax.swing.JTable();
        create_doy_TF = new javax.swing.JTextField();
        create_doy_L = new javax.swing.JLabel();
        create_name_L = new javax.swing.JLabel();
        create_name_TF = new javax.swing.JTextField();
        create_phone_L = new javax.swing.JLabel();
        create_phone_TF = new javax.swing.JTextField();
        create_street_L = new javax.swing.JLabel();
        create_street_TF = new javax.swing.JTextField();
        create_number_L = new javax.swing.JLabel();
        create_number_TF = new javax.swing.JTextField();
        create_city_L = new javax.swing.JLabel();
        create_city_TF = new javax.swing.JTextField();
        create_country_L = new javax.swing.JLabel();
        create_country_TF = new javax.swing.JTextField();
        add_company_B = new javax.swing.JButton();
        edit_company_B = new javax.swing.JButton();
        create_afm_L = new javax.swing.JLabel();
        create_afm_TF = new javax.swing.JTextField();
        edit_city_TF = new javax.swing.JTextField();
        edit_city_L = new javax.swing.JLabel();
        edit_number_TF = new javax.swing.JTextField();
        edit_number_L = new javax.swing.JLabel();
        edit_street_TF = new javax.swing.JTextField();
        edit_street_L = new javax.swing.JLabel();
        edit_phone_TF = new javax.swing.JTextField();
        edit_phone_L = new javax.swing.JLabel();
        edit_name_TF = new javax.swing.JTextField();
        edit_name_L = new javax.swing.JLabel();
        edit_doy_TF = new javax.swing.JTextField();
        edit_doy_L = new javax.swing.JLabel();
        edit_afm_L = new javax.swing.JLabel();
        edit_afm_CB = new javax.swing.JComboBox<>();
        edit_country_TF = new javax.swing.JTextField();
        edit_country_L = new javax.swing.JLabel();
        add_new_subject_B = new javax.swing.JButton();
        users_panel = new javax.swing.JPanel();
        title_panel2 = new javax.swing.JPanel();
        users_L = new javax.swing.JLabel();
        edit_user_B = new javax.swing.JButton();
        add_user_B = new javax.swing.JButton();
        create_username_L = new javax.swing.JLabel();
        create_password_L = new javax.swing.JLabel();
        create_name_user_L = new javax.swing.JLabel();
        create_surname_L = new javax.swing.JLabel();
        create_email_L = new javax.swing.JLabel();
        create_username_TF = new javax.swing.JTextField();
        create_password_TF = new javax.swing.JTextField();
        create_name_user_TF = new javax.swing.JTextField();
        create_surname_TF = new javax.swing.JTextField();
        create_email_TF = new javax.swing.JTextField();
        create_type_L = new javax.swing.JLabel();
        create_type_CB = new javax.swing.JComboBox<>();
        create_firm_L = new javax.swing.JLabel();
        create_firm_CB = new javax.swing.JComboBox<>();
        edit_firm_L = new javax.swing.JLabel();
        edit_firm_CB = new javax.swing.JComboBox<>();
        edit_email_TF = new javax.swing.JTextField();
        edit_email_L = new javax.swing.JLabel();
        edit_surname_L = new javax.swing.JLabel();
        edit_surname_TF = new javax.swing.JTextField();
        edit_name_user_TF = new javax.swing.JTextField();
        edit_name_user_L = new javax.swing.JLabel();
        edit_password_L = new javax.swing.JLabel();
        edit_password_TF = new javax.swing.JTextField();
        edit_username_L = new javax.swing.JLabel();
        edit_username_CB = new javax.swing.JComboBox<>();
        users_scroll_panel = new javax.swing.JScrollPane();
        users_table = new javax.swing.JTable();
        admin_rights_RB = new javax.swing.JRadioButton();
        log_panel = new javax.swing.JPanel();
        title_panel3 = new javax.swing.JPanel();
        log_L = new javax.swing.JLabel();
        log_scroll_panel = new javax.swing.JScrollPane();
        log_table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        logo_panel.setBackground(new java.awt.Color(102, 0, 204));

        logo_L.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        logo_L.setForeground(new java.awt.Color(255, 255, 255));
        logo_L.setText("EVaL");

        profile_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        profile_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        profile_subL.setForeground(new java.awt.Color(255, 255, 255));
        profile_subL.setText("                            Profile");
        profile_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                profile_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout profile_subpanelLayout = new javax.swing.GroupLayout(profile_subpanel);
        profile_subpanel.setLayout(profile_subpanelLayout);
        profile_subpanelLayout.setHorizontalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        profile_subpanelLayout.setVerticalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );

        my_group_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        my_group_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        my_group_subL.setForeground(new java.awt.Color(255, 255, 255));
        my_group_subL.setText("                         My Group");
        my_group_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                my_group_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout my_group_subpanelLayout = new javax.swing.GroupLayout(my_group_subpanel);
        my_group_subpanel.setLayout(my_group_subpanelLayout);
        my_group_subpanelLayout.setHorizontalGroup(
            my_group_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_group_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_group_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        my_group_subpanelLayout.setVerticalGroup(
            my_group_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_group_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_group_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        users_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        users_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        users_subL.setForeground(new java.awt.Color(255, 255, 255));
        users_subL.setText("                            Users");
        users_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                users_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout users_subpanelLayout = new javax.swing.GroupLayout(users_subpanel);
        users_subpanel.setLayout(users_subpanelLayout);
        users_subpanelLayout.setHorizontalGroup(
            users_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, users_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(users_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        users_subpanelLayout.setVerticalGroup(
            users_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, users_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(users_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        log_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        log_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        log_subL.setForeground(new java.awt.Color(255, 255, 255));
        log_subL.setText("                             Log");
        log_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                log_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout log_subpanelLayout = new javax.swing.GroupLayout(log_subpanel);
        log_subpanel.setLayout(log_subpanelLayout);
        log_subpanelLayout.setHorizontalGroup(
            log_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, log_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(log_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        log_subpanelLayout.setVerticalGroup(
            log_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, log_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(log_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                .addContainerGap())
        );

        exit_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        exit_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exit_subL.setForeground(new java.awt.Color(255, 255, 255));
        exit_subL.setText("                             Exit");
        exit_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exit_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout exit_subpanelLayout = new javax.swing.GroupLayout(exit_subpanel);
        exit_subpanel.setLayout(exit_subpanelLayout);
        exit_subpanelLayout.setHorizontalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        exit_subpanelLayout.setVerticalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout logo_panelLayout = new javax.swing.GroupLayout(logo_panel);
        logo_panel.setLayout(logo_panelLayout);
        logo_panelLayout.setHorizontalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(logo_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(my_group_subpanel, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profile_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(logo_panelLayout.createSequentialGroup()
                        .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(users_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(log_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(exit_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        logo_panelLayout.setVerticalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logo_L)
                .addGap(52, 52, 52)
                .addComponent(profile_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(my_group_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(users_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(log_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(exit_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        main_panel.setBackground(new java.awt.Color(255, 255, 255));
        main_panel.setLayout(new javax.swing.OverlayLayout(main_panel));

        profile_panel.setBackground(new java.awt.Color(255, 255, 255));

        username_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_L.setForeground(new java.awt.Color(77, 77, 77));
        username_L.setText("Username:");

        name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_L.setForeground(new java.awt.Color(77, 77, 77));
        name_L.setText("Name:");

        surname_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_L.setForeground(new java.awt.Color(77, 77, 77));
        surname_L.setText("Surname:");

        email_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_L.setForeground(new java.awt.Color(77, 77, 77));
        email_L.setText("Email:");

        password_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_L.setForeground(new java.awt.Color(77, 77, 77));
        password_L.setText("Password:");

        reg_date_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_L.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_L.setText("Date of Registration:");

        firm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_L.setForeground(new java.awt.Color(77, 77, 77));
        firm_L.setText("Firm:");

        update_B.setBackground(new java.awt.Color(102, 0, 204));
        update_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_B.setForeground(new java.awt.Color(255, 255, 255));
        update_B.setText("Update");
        update_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_BActionPerformed(evt);
            }
        });

        change_B.setBackground(new java.awt.Color(102, 0, 204));
        change_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        change_B.setForeground(new java.awt.Color(255, 255, 255));
        change_B.setText("Change");
        change_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                change_BActionPerformed(evt);
            }
        });

        username_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_field.setForeground(new java.awt.Color(77, 77, 77));
        username_field.setText("test");

        name_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_field.setForeground(new java.awt.Color(77, 77, 77));
        name_field.setText("test");

        surname_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_field.setForeground(new java.awt.Color(77, 77, 77));
        surname_field.setText("test");

        email_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_field.setForeground(new java.awt.Color(77, 77, 77));
        email_field.setText("test");

        reg_date_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_field.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_field.setText("test");

        password_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_field.setForeground(new java.awt.Color(77, 77, 77));
        password_field.setText("tset");

        firm_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_field.setForeground(new java.awt.Color(77, 77, 77));
        firm_field.setText("test");

        title_panel.setBackground(new java.awt.Color(166, 77, 255));

        profile_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        profile_L.setForeground(new java.awt.Color(255, 255, 255));
        profile_L.setText("Profile");

        javax.swing.GroupLayout title_panelLayout = new javax.swing.GroupLayout(title_panel);
        title_panel.setLayout(title_panelLayout);
        title_panelLayout.setHorizontalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(profile_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        title_panelLayout.setVerticalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(profile_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout profile_panelLayout = new javax.swing.GroupLayout(profile_panel);
        profile_panel.setLayout(profile_panelLayout);
        profile_panelLayout.setHorizontalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(reg_date_L)
                    .addComponent(firm_L)
                    .addComponent(username_L)
                    .addComponent(name_L)
                    .addComponent(surname_L)
                    .addComponent(password_L)
                    .addComponent(email_L))
                .addGap(18, 18, 18)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(surname_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reg_date_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(firm_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(336, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(change_B)
                .addGap(18, 18, 18)
                .addComponent(update_B)
                .addGap(25, 25, 25))
        );
        profile_panelLayout.setVerticalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addComponent(title_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_L)
                    .addComponent(name_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(surname_L)
                    .addComponent(surname_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_L)
                    .addComponent(email_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password_L)
                    .addComponent(password_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reg_date_L)
                    .addComponent(reg_date_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firm_L)
                    .addComponent(firm_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 385, Short.MAX_VALUE)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(update_B)
                    .addComponent(change_B))
                .addGap(24, 24, 24))
        );

        main_panel.add(profile_panel);

        my_group_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel1.setBackground(new java.awt.Color(166, 77, 255));

        my_group_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        my_group_L.setForeground(new java.awt.Color(255, 255, 255));
        my_group_L.setText("My Group");

        javax.swing.GroupLayout title_panel1Layout = new javax.swing.GroupLayout(title_panel1);
        title_panel1.setLayout(title_panel1Layout);
        title_panel1Layout.setHorizontalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(my_group_L)
                .addContainerGap(502, Short.MAX_VALUE))
        );
        title_panel1Layout.setVerticalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(my_group_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        companies_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        companies_table.setForeground(new java.awt.Color(77, 77, 77));
        companies_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "AFM", "DOY", "Name", "Phone No.", "Street", "Number", "City", "Country"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Long.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        companies_table.setGridColor(new java.awt.Color(102, 0, 204));
        companies_table.setRowSelectionAllowed(false);
        companies_table.setShowGrid(false);
        companies_table.getTableHeader().setReorderingAllowed(false);
        companies_scroll_panel.setViewportView(companies_table);

        create_doy_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_doy_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_doy_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_doy_TFActionPerformed(evt);
            }
        });

        create_doy_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_doy_L.setForeground(new java.awt.Color(77, 77, 77));
        create_doy_L.setText("DOY:");

        create_name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_name_L.setForeground(new java.awt.Color(77, 77, 77));
        create_name_L.setText("Name:");

        create_name_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_name_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_name_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_name_TFActionPerformed(evt);
            }
        });

        create_phone_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_phone_L.setForeground(new java.awt.Color(77, 77, 77));
        create_phone_L.setText("Phone No:");

        create_phone_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_phone_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_phone_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_phone_TFActionPerformed(evt);
            }
        });

        create_street_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_street_L.setForeground(new java.awt.Color(77, 77, 77));
        create_street_L.setText("Street:");

        create_street_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_street_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_street_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_street_TFActionPerformed(evt);
            }
        });

        create_number_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_number_L.setForeground(new java.awt.Color(77, 77, 77));
        create_number_L.setText("Number:");

        create_number_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_number_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_number_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_number_TFActionPerformed(evt);
            }
        });

        create_city_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_city_L.setForeground(new java.awt.Color(77, 77, 77));
        create_city_L.setText("City:");

        create_city_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_city_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_city_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_city_TFActionPerformed(evt);
            }
        });

        create_country_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_country_L.setForeground(new java.awt.Color(77, 77, 77));
        create_country_L.setText("Country:");

        create_country_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_country_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_country_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_country_TFActionPerformed(evt);
            }
        });

        add_company_B.setBackground(new java.awt.Color(102, 0, 204));
        add_company_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_company_B.setForeground(new java.awt.Color(255, 255, 255));
        add_company_B.setText("Add Company");
        add_company_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_company_BActionPerformed(evt);
            }
        });

        edit_company_B.setBackground(new java.awt.Color(102, 0, 204));
        edit_company_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_company_B.setForeground(new java.awt.Color(255, 255, 255));
        edit_company_B.setText("Edit Company");
        edit_company_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_company_BActionPerformed(evt);
            }
        });

        create_afm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_afm_L.setForeground(new java.awt.Color(77, 77, 77));
        create_afm_L.setText("AFM");

        create_afm_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_afm_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_afm_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_afm_TFActionPerformed(evt);
            }
        });

        edit_city_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_city_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_city_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_city_TFActionPerformed(evt);
            }
        });

        edit_city_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_city_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_city_L.setText("City:");

        edit_number_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_number_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_number_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_number_TFActionPerformed(evt);
            }
        });

        edit_number_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_number_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_number_L.setText("Number:");

        edit_street_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_street_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_street_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_street_TFActionPerformed(evt);
            }
        });

        edit_street_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_street_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_street_L.setText("Street:");

        edit_phone_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_phone_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_phone_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_phone_TFActionPerformed(evt);
            }
        });

        edit_phone_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_phone_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_phone_L.setText("Phone No:");

        edit_name_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_name_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_name_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_name_TFActionPerformed(evt);
            }
        });

        edit_name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_name_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_name_L.setText("Name:");

        edit_doy_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_doy_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_doy_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_doy_TFActionPerformed(evt);
            }
        });

        edit_doy_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_doy_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_doy_L.setText("DOY:");

        edit_afm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_afm_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_afm_L.setText("AFM");

        edit_afm_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_afm_CB.setForeground(new java.awt.Color(77, 77, 77));
        edit_afm_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_afm_CBActionPerformed(evt);
            }
        });

        edit_country_TF.setEditable(false);
        edit_country_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_country_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_country_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_country_TFActionPerformed(evt);
            }
        });

        edit_country_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_country_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_country_L.setText("Country:");

        add_new_subject_B.setBackground(new java.awt.Color(102, 0, 204));
        add_new_subject_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_new_subject_B.setForeground(new java.awt.Color(255, 255, 255));
        add_new_subject_B.setText("Add Subject");
        add_new_subject_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_new_subject_BActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout my_group_panelLayout = new javax.swing.GroupLayout(my_group_panel);
        my_group_panel.setLayout(my_group_panelLayout);
        my_group_panelLayout.setHorizontalGroup(
            my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(my_group_panelLayout.createSequentialGroup()
                .addGap(134, 134, 134)
                .addComponent(add_company_B)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(my_group_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(my_group_panelLayout.createSequentialGroup()
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(my_group_panelLayout.createSequentialGroup()
                                .addGap(85, 85, 85)
                                .addComponent(create_country_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(create_country_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(my_group_panelLayout.createSequentialGroup()
                                .addGap(85, 85, 85)
                                .addComponent(edit_country_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(edit_country_L)))
                    .addComponent(companies_scroll_panel)
                    .addGroup(my_group_panelLayout.createSequentialGroup()
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(my_group_panelLayout.createSequentialGroup()
                                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(create_phone_L)
                                    .addComponent(create_street_L)
                                    .addComponent(create_number_L))
                                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(my_group_panelLayout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(create_number_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(create_street_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(create_city_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(create_afm_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(create_name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(create_doy_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_group_panelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(create_phone_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(create_city_L)
                            .addComponent(create_afm_L)
                            .addComponent(create_doy_L)
                            .addComponent(create_name_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(my_group_panelLayout.createSequentialGroup()
                                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(edit_phone_L)
                                    .addComponent(edit_street_L)
                                    .addComponent(edit_number_L))
                                .addGap(21, 21, 21)
                                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                    .addComponent(edit_number_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(edit_street_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(edit_phone_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(edit_city_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(edit_name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(edit_doy_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(edit_company_B)))
                            .addComponent(edit_city_L)
                            .addGroup(my_group_panelLayout.createSequentialGroup()
                                .addComponent(edit_afm_L)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(edit_afm_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(edit_doy_L)
                            .addComponent(edit_name_L)))
                    .addComponent(add_new_subject_B, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        my_group_panelLayout.setVerticalGroup(
            my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_group_panelLayout.createSequentialGroup()
                .addComponent(title_panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(add_new_subject_B)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(companies_scroll_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(my_group_panelLayout.createSequentialGroup()
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_afm_L)
                            .addComponent(create_afm_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_doy_L)
                            .addComponent(create_doy_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_name_L)
                            .addComponent(create_name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_street_L)
                            .addComponent(create_street_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_number_L)
                            .addComponent(create_number_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_city_L)
                            .addComponent(create_city_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(my_group_panelLayout.createSequentialGroup()
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_afm_L)
                            .addComponent(edit_afm_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_doy_L)
                            .addComponent(edit_doy_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_name_L)
                            .addComponent(edit_name_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_phone_L)
                            .addComponent(edit_phone_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_phone_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_phone_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_street_L)
                            .addComponent(edit_street_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_number_L)
                            .addComponent(edit_number_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_city_L)
                            .addComponent(edit_city_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(create_country_L)
                    .addComponent(create_country_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edit_country_L)
                    .addComponent(edit_country_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_group_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(add_company_B)
                    .addComponent(edit_company_B))
                .addGap(16, 16, 16))
        );

        main_panel.add(my_group_panel);

        users_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel2.setBackground(new java.awt.Color(166, 77, 255));

        users_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        users_L.setForeground(new java.awt.Color(255, 255, 255));
        users_L.setText("Users");

        javax.swing.GroupLayout title_panel2Layout = new javax.swing.GroupLayout(title_panel2);
        title_panel2.setLayout(title_panel2Layout);
        title_panel2Layout.setHorizontalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(users_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        title_panel2Layout.setVerticalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(users_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        edit_user_B.setBackground(new java.awt.Color(102, 0, 204));
        edit_user_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_user_B.setForeground(new java.awt.Color(255, 255, 255));
        edit_user_B.setText("Edit User");
        edit_user_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_user_BActionPerformed(evt);
            }
        });

        add_user_B.setBackground(new java.awt.Color(102, 0, 204));
        add_user_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_user_B.setForeground(new java.awt.Color(255, 255, 255));
        add_user_B.setText("Add User");
        add_user_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_user_BActionPerformed(evt);
            }
        });

        create_username_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_username_L.setForeground(new java.awt.Color(77, 77, 77));
        create_username_L.setText("Username:");

        create_password_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_password_L.setForeground(new java.awt.Color(77, 77, 77));
        create_password_L.setText("Password:");

        create_name_user_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_name_user_L.setForeground(new java.awt.Color(77, 77, 77));
        create_name_user_L.setText("Name:");

        create_surname_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_surname_L.setForeground(new java.awt.Color(77, 77, 77));
        create_surname_L.setText("Surname:");

        create_email_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_email_L.setForeground(new java.awt.Color(77, 77, 77));
        create_email_L.setText("Email:");

        create_username_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_username_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_username_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_username_TFActionPerformed(evt);
            }
        });

        create_password_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_password_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_password_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_password_TFActionPerformed(evt);
            }
        });

        create_name_user_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_name_user_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_name_user_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_name_user_TFActionPerformed(evt);
            }
        });

        create_surname_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_surname_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_surname_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_surname_TFActionPerformed(evt);
            }
        });

        create_email_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_email_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_email_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_email_TFActionPerformed(evt);
            }
        });

        create_type_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_type_L.setForeground(new java.awt.Color(77, 77, 77));
        create_type_L.setText("Type:");

        create_type_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_type_CB.setForeground(new java.awt.Color(77, 77, 77));
        create_type_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        create_type_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_type_CBActionPerformed(evt);
            }
        });

        create_firm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_firm_L.setForeground(new java.awt.Color(77, 77, 77));
        create_firm_L.setText("Firm:");

        create_firm_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_firm_CB.setForeground(new java.awt.Color(77, 77, 77));
        create_firm_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        create_firm_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_firm_CBActionPerformed(evt);
            }
        });

        edit_firm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_firm_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_firm_L.setText("Firm:");

        edit_firm_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_firm_CB.setForeground(new java.awt.Color(77, 77, 77));
        edit_firm_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        edit_firm_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_firm_CBActionPerformed(evt);
            }
        });

        edit_email_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_email_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_email_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_email_TFActionPerformed(evt);
            }
        });

        edit_email_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_email_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_email_L.setText("Email:");

        edit_surname_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_surname_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_surname_L.setText("Surname:");

        edit_surname_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_surname_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_surname_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_surname_TFActionPerformed(evt);
            }
        });

        edit_name_user_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_name_user_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_name_user_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_name_user_TFActionPerformed(evt);
            }
        });

        edit_name_user_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_name_user_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_name_user_L.setText("Name:");

        edit_password_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_password_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_password_L.setText("Password:");

        edit_password_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_password_TF.setForeground(new java.awt.Color(77, 77, 77));
        edit_password_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_password_TFActionPerformed(evt);
            }
        });

        edit_username_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_username_L.setForeground(new java.awt.Color(77, 77, 77));
        edit_username_L.setText("Username:");

        edit_username_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        edit_username_CB.setForeground(new java.awt.Color(77, 77, 77));
        edit_username_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        edit_username_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_username_CBActionPerformed(evt);
            }
        });

        users_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        users_table.setForeground(new java.awt.Color(77, 77, 77));
        users_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Username", "Password", "Name", "Surname", "Email", "Firm", "Type", "Admin", "Registration"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        users_table.setRowSelectionAllowed(false);
        users_table.setShowHorizontalLines(false);
        users_table.setShowVerticalLines(false);
        users_table.getTableHeader().setReorderingAllowed(false);
        users_scroll_panel.setViewportView(users_table);
        if (users_table.getColumnModel().getColumnCount() > 0) {
            users_table.getColumnModel().getColumn(0).setResizable(false);
            users_table.getColumnModel().getColumn(1).setResizable(false);
            users_table.getColumnModel().getColumn(2).setResizable(false);
            users_table.getColumnModel().getColumn(3).setResizable(false);
            users_table.getColumnModel().getColumn(4).setResizable(false);
            users_table.getColumnModel().getColumn(5).setResizable(false);
            users_table.getColumnModel().getColumn(6).setResizable(false);
            users_table.getColumnModel().getColumn(7).setResizable(false);
            users_table.getColumnModel().getColumn(8).setResizable(false);
        }

        admin_rights_RB.setBackground(new java.awt.Color(255, 255, 255));
        admin_rights_RB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        admin_rights_RB.setForeground(new java.awt.Color(77, 77, 77));
        admin_rights_RB.setText("Admin Rights");
        admin_rights_RB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admin_rights_RBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout users_panelLayout = new javax.swing.GroupLayout(users_panel);
        users_panel.setLayout(users_panelLayout);
        users_panelLayout.setHorizontalGroup(
            users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(users_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(users_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 663, Short.MAX_VALUE)
                    .addGroup(users_panelLayout.createSequentialGroup()
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(create_username_L)
                            .addComponent(create_password_L)
                            .addComponent(create_name_user_L)
                            .addComponent(create_surname_L)
                            .addComponent(create_email_L)
                            .addComponent(create_firm_L)
                            .addComponent(create_type_L))
                        .addGap(21, 21, 21)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(create_email_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_surname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_name_user_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_password_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_username_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(add_user_B)
                            .addComponent(create_type_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_firm_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, users_panelLayout.createSequentialGroup()
                                .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(edit_username_L)
                                    .addComponent(edit_password_L)
                                    .addComponent(edit_name_user_L)
                                    .addComponent(edit_surname_L)
                                    .addComponent(edit_email_L)
                                    .addComponent(edit_firm_L))
                                .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, users_panelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(edit_username_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(users_panelLayout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                                .addComponent(edit_email_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(edit_surname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(edit_name_user_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(edit_password_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(edit_firm_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(admin_rights_RB, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, users_panelLayout.createSequentialGroup()
                                .addComponent(edit_user_B, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)))))
                .addContainerGap())
        );
        users_panelLayout.setVerticalGroup(
            users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(users_panelLayout.createSequentialGroup()
                .addComponent(title_panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(users_scroll_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(users_panelLayout.createSequentialGroup()
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_username_L)
                            .addComponent(create_username_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_password_L)
                            .addComponent(create_password_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_name_user_L)
                            .addComponent(create_name_user_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_surname_L)
                            .addComponent(create_surname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_email_L)
                            .addComponent(create_email_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_firm_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_firm_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_type_L)
                            .addComponent(create_type_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(add_user_B)
                            .addComponent(edit_user_B)))
                    .addGroup(users_panelLayout.createSequentialGroup()
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_username_L)
                            .addComponent(edit_username_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_password_L)
                            .addComponent(edit_password_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_name_user_L)
                            .addComponent(edit_name_user_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_surname_L)
                            .addComponent(edit_surname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_email_L)
                            .addComponent(edit_email_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_firm_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(edit_firm_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin_rights_RB)))
                .addContainerGap())
        );

        main_panel.add(users_panel);

        log_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel3.setBackground(new java.awt.Color(166, 77, 255));

        log_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        log_L.setForeground(new java.awt.Color(255, 255, 255));
        log_L.setText("Log Table");

        javax.swing.GroupLayout title_panel3Layout = new javax.swing.GroupLayout(title_panel3);
        title_panel3.setLayout(title_panel3Layout);
        title_panel3Layout.setHorizontalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(log_L)
                .addContainerGap(506, Short.MAX_VALUE))
        );
        title_panel3Layout.setVerticalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(log_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        log_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        log_table.setForeground(new java.awt.Color(77, 77, 77));
        log_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "Username", "Info", "Affected Table", "Action", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        log_table.setRowSelectionAllowed(false);
        log_table.setShowHorizontalLines(false);
        log_table.setShowVerticalLines(false);
        log_table.getTableHeader().setReorderingAllowed(false);
        log_scroll_panel.setViewportView(log_table);
        if (log_table.getColumnModel().getColumnCount() > 0) {
            log_table.getColumnModel().getColumn(0).setResizable(false);
            log_table.getColumnModel().getColumn(1).setResizable(false);
            log_table.getColumnModel().getColumn(2).setResizable(false);
            log_table.getColumnModel().getColumn(3).setResizable(false);
            log_table.getColumnModel().getColumn(4).setResizable(false);
            log_table.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout log_panelLayout = new javax.swing.GroupLayout(log_panel);
        log_panel.setLayout(log_panelLayout);
        log_panelLayout.setHorizontalGroup(
            log_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(log_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(log_scroll_panel)
                .addContainerGap())
        );
        log_panelLayout.setVerticalGroup(
            log_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(log_panelLayout.createSequentialGroup()
                .addComponent(title_panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(log_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE)
                .addContainerGap())
        );

        main_panel.add(log_panel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logo_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logo_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(main_panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void profile_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_profile_subLMouseClicked
        profile_panel.setVisible(true);
        my_group_panel.setVisible(false);
        users_panel.setVisible(false);
        log_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        users_subpanel.setBackground(new Color(102,0,204));
        my_group_subpanel.setBackground(new Color(102,0,204));
        log_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_profile_subLMouseClicked

    private void users_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_users_subLMouseClicked
        profile_panel.setVisible(false);
        my_group_panel.setVisible(false);
        users_panel.setVisible(true);
        log_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(102,0,204));
        users_subpanel.setBackground(new Color(166,77,255));
        my_group_subpanel.setBackground(new Color(102,0,204));
        log_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_users_subLMouseClicked

    private void my_group_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_my_group_subLMouseClicked
        profile_panel.setVisible(false);
        my_group_panel.setVisible(true);
        users_panel.setVisible(false);
        log_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(102,0,204));
        users_subpanel.setBackground(new Color(102,0,204));
        my_group_subpanel.setBackground(new Color(166,77,255));
        log_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_my_group_subLMouseClicked

    private void log_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_log_subLMouseClicked
        this.updateLogTable();
        profile_panel.setVisible(false);
        my_group_panel.setVisible(false);
        users_panel.setVisible(false);
        log_panel.setVisible(true);
        profile_subpanel.setBackground(new Color(102,0,204));
        users_subpanel.setBackground(new Color(102,0,204));
        my_group_subpanel.setBackground(new Color(102,0,204));
        log_subpanel.setBackground(new Color(166,77,255));      
    }//GEN-LAST:event_log_subLMouseClicked

    private void exit_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_subLMouseClicked
        this.dispose();
        new LoginFrame().setVisible(true);
    }//GEN-LAST:event_exit_subLMouseClicked

    private void update_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_BActionPerformed
        this.updateProfile();
    }//GEN-LAST:event_update_BActionPerformed

    private void change_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_change_BActionPerformed
        new UpdateProfileFrame(username, 0).setVisible(true);
    }//GEN-LAST:event_change_BActionPerformed

    private void edit_user_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_user_BActionPerformed
        String username_user;
        String password;
        String name;
        String surname;
        String email;
        String firm;
        String admin_rights;
        
        username_user = (String)edit_username_CB.getSelectedItem();
        password = edit_password_TF.getText();
        name = edit_name_user_TF.getText();
        surname = edit_surname_TF.getText();
        email = edit_email_TF.getText();
        firm = (String)edit_firm_CB.getSelectedItem();
        if (admin_rights_RB.isSelected()) {
            admin_rights = "1";
        }
        else {
            admin_rights = "0";
        }
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateUser = con.prepareStatement("UPDATE user SET password=?, name=?, surname=?, email=?, firm=?, admin_rights=? WHERE username=?");
            updateUser.setString(1,password);
            updateUser.setString(2,name);
            updateUser.setString(3,surname);
            updateUser.setString(4,email);
            updateUser.setString(5,firm);
            updateUser.setString(6,admin_rights);
            updateUser.setString(7,username_user);
            int rowsAffected = updateUser.executeUpdate();
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }

        this.updateUsersTable();
    }//GEN-LAST:event_edit_user_BActionPerformed

    private void add_user_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_user_BActionPerformed
        String username_user;
        String password;
        String name;
        String surname;
        String email;
        String firm;
        String admin_rights;
        String type;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime reg_date;
        reg_date = LocalDateTime.now();
        
        username_user = create_username_TF.getText();
        password = create_password_TF.getText();
        name = create_name_user_TF.getText();
        surname = create_surname_TF.getText();
        email = create_email_TF.getText();
        firm = (String)create_firm_CB.getSelectedItem();
        type = (String)create_type_CB.getSelectedItem();
        if (type.equals("Admin")) {
            admin_rights = "1";
        }
        else {
            admin_rights = "0";
        }
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement insertUser = con.prepareStatement("INSERT INTO user VALUES (?,?,?,?,?,?,?,?)");
            insertUser.setString(1,username_user);
            insertUser.setString(2,password);
            insertUser.setString(3,name);
            insertUser.setString(4,surname);
            insertUser.setString(5,dtf.format(reg_date));
            insertUser.setString(6,email);
            insertUser.setString(7,firm);
            insertUser.setString(8,admin_rights);
            int rowsAffected = insertUser.executeUpdate();
            System.out.println(rowsAffected);
            
            if (type.equals("Evaluator")) {
                PreparedStatement insertEvaluator = con.prepareStatement("INSERT INTO evaluator VALUES (?,?)");
                insertEvaluator.setString(1,username_user);
                insertEvaluator.setInt(2,0);
                rowsAffected = insertEvaluator.executeUpdate();
                System.out.println(rowsAffected);
            }
            else if (type.equals("Manager")) {
                PreparedStatement insertManager = con.prepareStatement("INSERT INTO manager VALUES (?,?)");
                insertManager.setString(1,username_user);
                insertManager.setInt(2,0);
                rowsAffected = insertManager.executeUpdate();
                System.out.println(rowsAffected);
            }
            else if (type.equals("Employee")) {
                PreparedStatement insertEmployee = con.prepareStatement("INSERT INTO employee (username,bio,exp_years) VALUES (?,?,?)");
                insertEmployee.setString(1,username_user);
                insertEmployee.setString(2,"No bio yet. Please write a bio.");
                insertEmployee.setInt(3,0);
                rowsAffected = insertEmployee.executeUpdate();
                System.out.println(rowsAffected);
                
                this.restoreUserInfo(con);
            }
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }

        this.updateUsersTable();
    }//GEN-LAST:event_add_user_BActionPerformed

    private void create_username_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_username_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_username_TFActionPerformed

    private void create_password_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_password_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_password_TFActionPerformed

    private void create_name_user_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_name_user_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_name_user_TFActionPerformed

    private void create_surname_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_surname_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_surname_TFActionPerformed

    private void create_email_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_email_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_email_TFActionPerformed

    private void create_type_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_type_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_type_CBActionPerformed

    private void create_doy_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_doy_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_doy_TFActionPerformed

    private void create_name_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_name_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_name_TFActionPerformed

    private void create_phone_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_phone_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_phone_TFActionPerformed

    private void create_street_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_street_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_street_TFActionPerformed

    private void create_number_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_number_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_number_TFActionPerformed

    private void create_city_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_city_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_city_TFActionPerformed

    private void create_country_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_country_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_country_TFActionPerformed

    private void add_company_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_company_BActionPerformed
        String afm;
        String doy;
        String name;
        long phone;
        String street;
        int number;       
        String city;
        String country;
      
        try {
            afm = create_afm_TF.getText();
            doy = create_doy_TF.getText();
            name = create_name_TF.getText();
            phone = Long.parseLong(create_phone_TF.getText());       
            street = create_street_TF.getText();
            number = Integer.parseInt(create_number_TF.getText());
            city = create_city_TF.getText();
            country = create_country_TF.getText();

            create_afm_TF.setText(" ");
            create_doy_TF.setText(" ");
            create_name_TF.setText(" ");
            create_street_TF.setText(" ");
            create_number_TF.setText(" ");
            create_city_TF.setText(" ");
            create_country_TF.setText(" ");
            
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement insertCompany = con.prepareStatement("INSERT INTO company VALUES (?,?,?,?,?,?,?,?)");
            insertCompany.setString(1, afm);
            insertCompany.setString(2,doy);
            insertCompany.setString(3,name);
            insertCompany.setLong(4,phone);
            insertCompany.setString(5,street);
            insertCompany.setInt(6,number);
            insertCompany.setString(7,city);
            insertCompany.setString(8,country);
            int rowsAffected = insertCompany.executeUpdate();
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }

        this.updateCompaniesTable();
        this.populateComboBoxEditAFM();
        this.populateComboBoxFirm();
    }//GEN-LAST:event_add_company_BActionPerformed

    private void edit_company_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_company_BActionPerformed
        String afm;
        String doy;
        String name;
        long phone;
        String street;
        int number;       
        String city;
        String country;      
        
        try {
            afm = (String)edit_afm_CB.getSelectedItem();
            doy = edit_doy_TF.getText();
            name = edit_name_TF.getText();
            phone = Long.parseLong(edit_phone_TF.getText());       
            street = edit_street_TF.getText();
            number = Integer.parseInt(edit_number_TF.getText());
            city = edit_city_TF.getText();
            country = edit_country_TF.getText();
            
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            this.sendUserInfo(con);
            
            PreparedStatement updateCompany = con.prepareStatement("UPDATE company SET DOY=?, name=?, phone=?, street=?, num=?, city=?, country=? WHERE AFM=?");           
            updateCompany.setString(1,doy);
            updateCompany.setString(2,name);
            updateCompany.setLong(3,phone);
            updateCompany.setString(4,street);
            updateCompany.setInt(5,number);
            updateCompany.setString(6,city);
            updateCompany.setString(7,country);
            updateCompany.setString(8, afm);
            int rowsAffected = updateCompany.executeUpdate();   
            System.out.println(rowsAffected);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        
        this.updateCompaniesTable();
    }//GEN-LAST:event_edit_company_BActionPerformed

    private void create_afm_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_afm_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_afm_TFActionPerformed

    private void edit_city_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_city_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_city_TFActionPerformed

    private void edit_number_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_number_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_number_TFActionPerformed

    private void edit_street_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_street_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_street_TFActionPerformed

    private void edit_phone_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_phone_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_phone_TFActionPerformed

    private void edit_name_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_name_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_name_TFActionPerformed

    private void edit_doy_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_doy_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_doy_TFActionPerformed

    private void edit_afm_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_afm_CBActionPerformed
        if (edit_afm_CB_populated == true) {
            String afm;
            String doy;
            String name;
            long phone;
            String street;
            int number;       
            String city;
            String country;
            
        
            afm = (String)edit_afm_CB.getSelectedItem();
            
            try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
                PreparedStatement selectCompany = con.prepareStatement("SELECT DOY, name, phone, street, num, city, country FROM company WHERE AFM=?");
                selectCompany.setString(1, afm);
                ResultSet resultCompany = selectCompany.executeQuery();

                while (resultCompany.next()) {
                    doy = resultCompany.getString("DOY");    
                    name = resultCompany.getString("name");
                    phone = resultCompany.getLong("phone");
                    street = resultCompany.getString("street");
                    number = resultCompany.getInt("num");
                    city = resultCompany.getString("city");
                    country = resultCompany.getString("country");
                    
                    edit_doy_TF.setText(doy);
                    edit_name_TF.setText(name);
                    edit_phone_TF.setText(String.valueOf(phone));
                    edit_street_TF.setText(street);
                    edit_number_TF.setText(String.valueOf(number));
                    edit_city_TF.setText(city);
                    edit_country_TF.setText(country);
                }
            }
            catch (SQLException ex) {
                //JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
                ex.printStackTrace();
            }
            finally {
                if (con != null)
                try { con.close();}
                catch (SQLException ex) { ex.printStackTrace();}
            }
        }
    }//GEN-LAST:event_edit_afm_CBActionPerformed

    private void edit_country_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_country_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_country_TFActionPerformed

    private void create_firm_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_firm_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_firm_CBActionPerformed

    private void edit_firm_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_firm_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_firm_CBActionPerformed

    private void edit_email_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_email_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_email_TFActionPerformed

    private void edit_surname_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_surname_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_surname_TFActionPerformed

    private void edit_name_user_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_name_user_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_name_user_TFActionPerformed

    private void edit_password_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_password_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edit_password_TFActionPerformed

    private void edit_username_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_username_CBActionPerformed
        if (username_CB_populated == true) {
            String username;
            String password;
            String name;
            String surname;
            String email;       
                  
            username = (String)edit_username_CB.getSelectedItem();
            
            try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
                PreparedStatement selectUser = con.prepareStatement("SELECT password, name, surname, email FROM user WHERE username=?");
                selectUser.setString(1, username);
                ResultSet resultUser = selectUser.executeQuery();

                while (resultUser.next()) {
                    password = resultUser.getString("password");    
                    name = resultUser.getString("name");
                    surname = resultUser.getString("surname");
                    email = resultUser.getString("email");
                    edit_password_TF.setText(password);
                    edit_name_user_TF.setText(name);
                    edit_surname_TF.setText(surname);
                    edit_email_TF.setText(email);
                }
            }
            catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
                ex.printStackTrace();
            }
            finally {
                if (con != null)
                try { con.close();}
                catch (SQLException ex) { ex.printStackTrace();}
            }
        }
    }//GEN-LAST:event_edit_username_CBActionPerformed

    private void add_new_subject_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_new_subject_BActionPerformed
        new AddSubjectFrame().setVisible(true);
    }//GEN-LAST:event_add_new_subject_BActionPerformed

    private void admin_rights_RBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admin_rights_RBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_admin_rights_RBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminProfileFrame(username).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_company_B;
    private javax.swing.JButton add_new_subject_B;
    private javax.swing.JButton add_user_B;
    private javax.swing.JRadioButton admin_rights_RB;
    private javax.swing.JButton change_B;
    private javax.swing.JScrollPane companies_scroll_panel;
    private javax.swing.JTable companies_table;
    private javax.swing.JLabel create_afm_L;
    private javax.swing.JTextField create_afm_TF;
    private javax.swing.JLabel create_city_L;
    private javax.swing.JTextField create_city_TF;
    private javax.swing.JLabel create_country_L;
    private javax.swing.JTextField create_country_TF;
    private javax.swing.JLabel create_doy_L;
    private javax.swing.JTextField create_doy_TF;
    private javax.swing.JLabel create_email_L;
    private javax.swing.JTextField create_email_TF;
    private javax.swing.JComboBox<String> create_firm_CB;
    private javax.swing.JLabel create_firm_L;
    private javax.swing.JLabel create_name_L;
    private javax.swing.JTextField create_name_TF;
    private javax.swing.JLabel create_name_user_L;
    private javax.swing.JTextField create_name_user_TF;
    private javax.swing.JLabel create_number_L;
    private javax.swing.JTextField create_number_TF;
    private javax.swing.JLabel create_password_L;
    private javax.swing.JTextField create_password_TF;
    private javax.swing.JLabel create_phone_L;
    private javax.swing.JTextField create_phone_TF;
    private javax.swing.JLabel create_street_L;
    private javax.swing.JTextField create_street_TF;
    private javax.swing.JLabel create_surname_L;
    private javax.swing.JTextField create_surname_TF;
    private javax.swing.JComboBox<String> create_type_CB;
    private javax.swing.JLabel create_type_L;
    private javax.swing.JLabel create_username_L;
    private javax.swing.JTextField create_username_TF;
    private javax.swing.JComboBox<String> edit_afm_CB;
    private javax.swing.JLabel edit_afm_L;
    private javax.swing.JLabel edit_city_L;
    private javax.swing.JTextField edit_city_TF;
    private javax.swing.JButton edit_company_B;
    private javax.swing.JLabel edit_country_L;
    private javax.swing.JTextField edit_country_TF;
    private javax.swing.JLabel edit_doy_L;
    private javax.swing.JTextField edit_doy_TF;
    private javax.swing.JLabel edit_email_L;
    private javax.swing.JTextField edit_email_TF;
    private javax.swing.JComboBox<String> edit_firm_CB;
    private javax.swing.JLabel edit_firm_L;
    private javax.swing.JLabel edit_name_L;
    private javax.swing.JTextField edit_name_TF;
    private javax.swing.JLabel edit_name_user_L;
    private javax.swing.JTextField edit_name_user_TF;
    private javax.swing.JLabel edit_number_L;
    private javax.swing.JTextField edit_number_TF;
    private javax.swing.JLabel edit_password_L;
    private javax.swing.JTextField edit_password_TF;
    private javax.swing.JLabel edit_phone_L;
    private javax.swing.JTextField edit_phone_TF;
    private javax.swing.JLabel edit_street_L;
    private javax.swing.JTextField edit_street_TF;
    private javax.swing.JLabel edit_surname_L;
    private javax.swing.JTextField edit_surname_TF;
    private javax.swing.JButton edit_user_B;
    private javax.swing.JComboBox<String> edit_username_CB;
    private javax.swing.JLabel edit_username_L;
    private javax.swing.JLabel email_L;
    private javax.swing.JLabel email_field;
    private javax.swing.JLabel exit_subL;
    private javax.swing.JPanel exit_subpanel;
    private javax.swing.JLabel firm_L;
    private javax.swing.JLabel firm_field;
    private javax.swing.JLabel log_L;
    private javax.swing.JPanel log_panel;
    private javax.swing.JScrollPane log_scroll_panel;
    private javax.swing.JLabel log_subL;
    private javax.swing.JPanel log_subpanel;
    private javax.swing.JTable log_table;
    private javax.swing.JLabel logo_L;
    private javax.swing.JPanel logo_panel;
    private javax.swing.JPanel main_panel;
    private javax.swing.JLabel my_group_L;
    private javax.swing.JPanel my_group_panel;
    private javax.swing.JLabel my_group_subL;
    private javax.swing.JPanel my_group_subpanel;
    private javax.swing.JLabel name_L;
    private javax.swing.JLabel name_field;
    private javax.swing.JLabel password_L;
    private javax.swing.JLabel password_field;
    private javax.swing.JLabel profile_L;
    private javax.swing.JPanel profile_panel;
    private javax.swing.JLabel profile_subL;
    private javax.swing.JPanel profile_subpanel;
    private javax.swing.JLabel reg_date_L;
    private javax.swing.JLabel reg_date_field;
    private javax.swing.JLabel surname_L;
    private javax.swing.JLabel surname_field;
    private javax.swing.JPanel title_panel;
    private javax.swing.JPanel title_panel1;
    private javax.swing.JPanel title_panel2;
    private javax.swing.JPanel title_panel3;
    private javax.swing.JButton update_B;
    private javax.swing.JLabel username_L;
    private javax.swing.JLabel username_field;
    private javax.swing.JLabel users_L;
    private javax.swing.JPanel users_panel;
    private javax.swing.JScrollPane users_scroll_panel;
    private javax.swing.JLabel users_subL;
    private javax.swing.JPanel users_subpanel;
    private javax.swing.JTable users_table;
    // End of variables declaration//GEN-END:variables
}
