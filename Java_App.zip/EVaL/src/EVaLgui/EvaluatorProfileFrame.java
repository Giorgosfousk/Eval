// Problem with evaluation panel (all)
// Add subject not updating without logout
package EVaLgui;

import java.awt.Color;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class EvaluatorProfileFrame extends javax.swing.JFrame {

    private static String username;
    private static String firm;
    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private DefaultTableModel model_all_jobs;
    private DefaultTableModel model_my_jobs;
    private DefaultTableModel model_evaluation1;
    private DefaultTableModel model_evaluation2;         
    
    private static boolean update_job_id_CB_populated;
    
    public EvaluatorProfileFrame(String login_username, String login_firm) {
        initComponents();
        this.username = login_username;
        this.firm = login_firm;
        profile_panel.setVisible(true);
        all_jobs_panel.setVisible(false);
        my_jobs_panel.setVisible(false);
        evaluation_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        username_field.setText(username);       
        this.updateProfile();
        this.updateAllJobsTable();
        this.updateMyJobsTable();
        this.updateEvaluation1Table();
        this.populateComboBoxUpdateJobId();
        this.populateComboBoxSubject();
        this.updateEvaluation2Table();
    }
    
    private void sendUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, username);  
        callSetCurrentUser.execute();
    }
   
    private void restoreUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, "local_admin");  
        callSetCurrentUser.execute();
    }
    
    private void updateProfile() {
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectUserInfo = con.prepareStatement("SELECT name, surname, email, password, reg_date, firm FROM user WHERE username LIKE ?");
            selectUserInfo.setString(1, username);
            ResultSet resultUserInfo = selectUserInfo.executeQuery();

            PreparedStatement selectEvaluatorInfo = con.prepareStatement("SELECT exp_years FROM evaluator WHERE username LIKE ?");
            selectEvaluatorInfo.setString(1, username);
            ResultSet resultEvaluatorInfo = selectEvaluatorInfo.executeQuery();
            
            while (resultUserInfo.next()) {           
                name_field.setText(resultUserInfo.getString("name"));
                surname_field.setText(resultUserInfo.getString("surname"));
                email_field.setText(resultUserInfo.getString("email"));
                password_field.setText(resultUserInfo.getString("password").replaceAll(".", "*"));
                reg_date_field.setText(resultUserInfo.getString("reg_date"));
                firm_field.setText(resultUserInfo.getString("firm"));      
            }   
            while (resultEvaluatorInfo.next()) {
                exp_years_field.setText(resultEvaluatorInfo.getString("exp_years"));
            }          
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateAllJobsTable() {
        model_all_jobs = (DefaultTableModel) all_jobs_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectJobs = con.prepareStatement("SELECT * FROM job WHERE firm=?");
            selectJobs.setString(1, firm);
            ResultSet resultJobs = selectJobs.executeQuery();           
            model_all_jobs.setRowCount(0);
            while (resultJobs.next()) {
                model_all_jobs.insertRow(model_all_jobs.getRowCount(), new Object[]{resultJobs.getInt("id"),resultJobs.getString("start_date"),resultJobs.getFloat("salary"),resultJobs.getString("position"),resultJobs.getString("seat"),resultJobs.getString("evaluator"),resultJobs.getString("announce_date"),resultJobs.getString("submission_date")});
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateMyJobsTable() {
        model_my_jobs = (DefaultTableModel) my_jobs_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
           
            PreparedStatement selectMyJobs = con.prepareStatement("SELECT * FROM job INNER JOIN needs ON id=job_id WHERE evaluator LIKE ? AND firm=?");
            selectMyJobs.setString(1, username);
            selectMyJobs.setString(2, firm);
            ResultSet resultMyJobs = selectMyJobs.executeQuery();                     
            model_my_jobs.setRowCount(0);
            while (resultMyJobs.next()) {

                model_my_jobs.insertRow(model_my_jobs.getRowCount(), new Object[]{resultMyJobs.getInt("id"),resultMyJobs.getString("start_date"),resultMyJobs.getFloat("salary"),resultMyJobs.getString("position"),resultMyJobs.getString("seat"),resultMyJobs.getString("evaluator"),resultMyJobs.getString("announce_date"),resultMyJobs.getString("submission_date"),resultMyJobs.getString("subject_title")});
            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateEvaluation1Table() {
        model_evaluation1 = (DefaultTableModel) evaluation_table1.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectEvaluation1 = con.prepareStatement("SELECT * FROM evaluation_results WHERE job_id IN (SELECT id FROM job WHERE evaluator LIKE ?)");
            selectEvaluation1.setString(1, username);
            ResultSet resultEvaluation1 = selectEvaluation1.executeQuery();
            model_evaluation1.setRowCount(0);
            while (resultEvaluation1.next()) {
                model_evaluation1.insertRow(model_evaluation1.getRowCount(), new Object[]{resultEvaluation1.getInt("ev_id"),resultEvaluation1.getString("employee"),resultEvaluation1.getInt("job_id"),resultEvaluation1.getInt("grade"),resultEvaluation1.getString("comments")});
            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateEvaluation2Table() {
        model_evaluation2 = (DefaultTableModel) evaluation_table2.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectEvaluation2 = con.prepareStatement("SELECT id, position, submission_date, COUNT(*) FROM requests_evaluation INNER JOIN job ON job_id=id WHERE evaluator=? GROUP BY job_id");
            selectEvaluation2.setString(1, username);
            ResultSet resultEvaluation2 = selectEvaluation2.executeQuery();
            model_evaluation2.setRowCount(0);
            while (resultEvaluation2.next()) {
                model_evaluation2.insertRow(model_evaluation2.getRowCount(), new Object[]{resultEvaluation2.getInt("id"),resultEvaluation2.getString("position"),resultEvaluation2.getString("submission_date"),resultEvaluation2.getInt("COUNT(*)")});
            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void populateComboBoxUpdateJobId() {       
        update_job_id_CB_populated = false;
        update_job_id_CB.removeAllItems();
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime current_date =  LocalDateTime.now();
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectMyJobsId = con.prepareStatement("SELECT id FROM job WHERE evaluator=? AND submission_date>=?");
            selectMyJobsId.setString(1, username);
            selectMyJobsId.setString(2, dtf.format(current_date));
            ResultSet resultMyJobsId = selectMyJobsId.executeQuery();
                       
            while (resultMyJobsId.next()) {               
                update_job_id_CB.addItem(resultMyJobsId.getString("id"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        update_job_id_CB_populated = true;
    }
    
    protected void populateComboBoxSubject() {       
        create_subject_CB.removeAllItems();
        update_subject_CB.removeAllItems();
        try {           
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectSubject = con.prepareStatement("SELECT title FROM subject");
            ResultSet resultSubject = selectSubject.executeQuery();
                       
            while (resultSubject.next()) {               
                create_subject_CB.addItem(resultSubject.getString("title"));
                update_subject_CB.addItem(resultSubject.getString("title"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logo_panel = new javax.swing.JPanel();
        logo_L = new javax.swing.JLabel();
        profile_subpanel = new javax.swing.JPanel();
        profile_subL = new javax.swing.JLabel();
        all_jobs_subpanel = new javax.swing.JPanel();
        all_jobs_subL = new javax.swing.JLabel();
        my_jobs_subpanel = new javax.swing.JPanel();
        my_jobs_subL = new javax.swing.JLabel();
        evaluation_subpanel = new javax.swing.JPanel();
        evaluation_subL = new javax.swing.JLabel();
        exit_subpanel = new javax.swing.JPanel();
        exit_subL = new javax.swing.JLabel();
        main_panel = new javax.swing.JPanel();
        profile_panel = new javax.swing.JPanel();
        username_L = new javax.swing.JLabel();
        name_L = new javax.swing.JLabel();
        surname_L = new javax.swing.JLabel();
        email_L = new javax.swing.JLabel();
        password_L = new javax.swing.JLabel();
        reg_date_L = new javax.swing.JLabel();
        exp_years_L = new javax.swing.JLabel();
        firm_L = new javax.swing.JLabel();
        update_B = new javax.swing.JButton();
        change_B = new javax.swing.JButton();
        username_field = new javax.swing.JLabel();
        name_field = new javax.swing.JLabel();
        surname_field = new javax.swing.JLabel();
        email_field = new javax.swing.JLabel();
        reg_date_field = new javax.swing.JLabel();
        password_field = new javax.swing.JLabel();
        exp_years_field = new javax.swing.JLabel();
        firm_field = new javax.swing.JLabel();
        title_panel = new javax.swing.JPanel();
        profile_L = new javax.swing.JLabel();
        all_jobs_panel = new javax.swing.JPanel();
        title_panel1 = new javax.swing.JPanel();
        all_jobs_L = new javax.swing.JLabel();
        all_jobs_scroll_panel = new javax.swing.JScrollPane();
        all_jobs_table = new javax.swing.JTable();
        my_jobs_panel = new javax.swing.JPanel();
        title_panel2 = new javax.swing.JPanel();
        my_jobs_L = new javax.swing.JLabel();
        myl_jobs_scroll_panel = new javax.swing.JScrollPane();
        my_jobs_table = new javax.swing.JTable();
        update_job_B = new javax.swing.JButton();
        create_new_job_B = new javax.swing.JButton();
        create_start_date_L = new javax.swing.JLabel();
        create_salary_L = new javax.swing.JLabel();
        create_position_L = new javax.swing.JLabel();
        create_seat_L = new javax.swing.JLabel();
        create_submission_L = new javax.swing.JLabel();
        create_start_date_TF = new javax.swing.JTextField();
        create_salary_TF = new javax.swing.JTextField();
        create_position_TF = new javax.swing.JTextField();
        create_seat_TF = new javax.swing.JTextField();
        create_submission_TF = new javax.swing.JTextField();
        update_start_date_L = new javax.swing.JLabel();
        update_start_date_TF = new javax.swing.JTextField();
        update_salary_L = new javax.swing.JLabel();
        update_salary_TF = new javax.swing.JTextField();
        update_position_L = new javax.swing.JLabel();
        update_position_TF = new javax.swing.JTextField();
        update_seat_L = new javax.swing.JLabel();
        update_seat_TF = new javax.swing.JTextField();
        update_submission_L = new javax.swing.JLabel();
        update_submission_TF = new javax.swing.JTextField();
        update_job_id_CB = new javax.swing.JComboBox<>();
        update_job_id_L = new javax.swing.JLabel();
        create_subject_L = new javax.swing.JLabel();
        create_subject_CB = new javax.swing.JComboBox<>();
        update_subject_CB = new javax.swing.JComboBox<>();
        update_subject_L = new javax.swing.JLabel();
        add_new_subject_B = new javax.swing.JButton();
        evaluation_panel = new javax.swing.JPanel();
        title_panel3 = new javax.swing.JPanel();
        evaluation_L = new javax.swing.JLabel();
        evaluation_scroll_panel1 = new javax.swing.JScrollPane();
        evaluation_table1 = new javax.swing.JTable();
        add_evaluation_B = new javax.swing.JButton();
        info_B = new javax.swing.JButton();
        evaluation_scroll_panel2 = new javax.swing.JScrollPane();
        evaluation_table2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        logo_panel.setBackground(new java.awt.Color(102, 0, 204));

        logo_L.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        logo_L.setForeground(new java.awt.Color(255, 255, 255));
        logo_L.setText("EVaL");

        profile_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        profile_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        profile_subL.setForeground(new java.awt.Color(255, 255, 255));
        profile_subL.setText("                            Profile");
        profile_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                profile_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout profile_subpanelLayout = new javax.swing.GroupLayout(profile_subpanel);
        profile_subpanel.setLayout(profile_subpanelLayout);
        profile_subpanelLayout.setHorizontalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        profile_subpanelLayout.setVerticalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );

        all_jobs_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        all_jobs_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        all_jobs_subL.setForeground(new java.awt.Color(255, 255, 255));
        all_jobs_subL.setText("                          All Jobs");
        all_jobs_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                all_jobs_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout all_jobs_subpanelLayout = new javax.swing.GroupLayout(all_jobs_subpanel);
        all_jobs_subpanel.setLayout(all_jobs_subpanelLayout);
        all_jobs_subpanelLayout.setHorizontalGroup(
            all_jobs_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, all_jobs_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(all_jobs_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        all_jobs_subpanelLayout.setVerticalGroup(
            all_jobs_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, all_jobs_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(all_jobs_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        my_jobs_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        my_jobs_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        my_jobs_subL.setForeground(new java.awt.Color(255, 255, 255));
        my_jobs_subL.setText("                          My Jobs");
        my_jobs_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                my_jobs_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout my_jobs_subpanelLayout = new javax.swing.GroupLayout(my_jobs_subpanel);
        my_jobs_subpanel.setLayout(my_jobs_subpanelLayout);
        my_jobs_subpanelLayout.setHorizontalGroup(
            my_jobs_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_jobs_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_jobs_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        my_jobs_subpanelLayout.setVerticalGroup(
            my_jobs_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_jobs_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_jobs_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        evaluation_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        evaluation_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        evaluation_subL.setForeground(new java.awt.Color(255, 255, 255));
        evaluation_subL.setText("                        Evaluation");
        evaluation_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                evaluation_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout evaluation_subpanelLayout = new javax.swing.GroupLayout(evaluation_subpanel);
        evaluation_subpanel.setLayout(evaluation_subpanelLayout);
        evaluation_subpanelLayout.setHorizontalGroup(
            evaluation_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, evaluation_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(evaluation_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        evaluation_subpanelLayout.setVerticalGroup(
            evaluation_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, evaluation_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(evaluation_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                .addContainerGap())
        );

        exit_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        exit_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exit_subL.setForeground(new java.awt.Color(255, 255, 255));
        exit_subL.setText("                             Exit");
        exit_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exit_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout exit_subpanelLayout = new javax.swing.GroupLayout(exit_subpanel);
        exit_subpanel.setLayout(exit_subpanelLayout);
        exit_subpanelLayout.setHorizontalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        exit_subpanelLayout.setVerticalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout logo_panelLayout = new javax.swing.GroupLayout(logo_panel);
        logo_panel.setLayout(logo_panelLayout);
        logo_panelLayout.setHorizontalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(logo_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(my_jobs_subpanel, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profile_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(logo_panelLayout.createSequentialGroup()
                        .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(all_jobs_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(evaluation_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(exit_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        logo_panelLayout.setVerticalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logo_L)
                .addGap(52, 52, 52)
                .addComponent(profile_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(my_jobs_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(all_jobs_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(evaluation_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(exit_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        main_panel.setBackground(new java.awt.Color(255, 255, 255));
        main_panel.setLayout(new javax.swing.OverlayLayout(main_panel));

        profile_panel.setBackground(new java.awt.Color(255, 255, 255));

        username_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_L.setForeground(new java.awt.Color(77, 77, 77));
        username_L.setText("Username:");

        name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_L.setForeground(new java.awt.Color(77, 77, 77));
        name_L.setText("Name:");

        surname_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_L.setForeground(new java.awt.Color(77, 77, 77));
        surname_L.setText("Surname:");

        email_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_L.setForeground(new java.awt.Color(77, 77, 77));
        email_L.setText("Email:");

        password_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_L.setForeground(new java.awt.Color(77, 77, 77));
        password_L.setText("Password:");

        reg_date_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_L.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_L.setText("Date of Registration:");

        exp_years_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_L.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_L.setText("Years of Experience:");

        firm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_L.setForeground(new java.awt.Color(77, 77, 77));
        firm_L.setText("Firm:");

        update_B.setBackground(new java.awt.Color(102, 0, 204));
        update_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_B.setForeground(new java.awt.Color(255, 255, 255));
        update_B.setText("Update");
        update_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_BActionPerformed(evt);
            }
        });

        change_B.setBackground(new java.awt.Color(102, 0, 204));
        change_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        change_B.setForeground(new java.awt.Color(255, 255, 255));
        change_B.setText("Change");
        change_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                change_BActionPerformed(evt);
            }
        });

        username_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_field.setForeground(new java.awt.Color(77, 77, 77));
        username_field.setText("test");

        name_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_field.setForeground(new java.awt.Color(77, 77, 77));
        name_field.setText("test");

        surname_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_field.setForeground(new java.awt.Color(77, 77, 77));
        surname_field.setText("test");

        email_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_field.setForeground(new java.awt.Color(77, 77, 77));
        email_field.setText("test");

        reg_date_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_field.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_field.setText("test");

        password_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_field.setForeground(new java.awt.Color(77, 77, 77));
        password_field.setText("tset");

        exp_years_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_field.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_field.setText("test");

        firm_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_field.setForeground(new java.awt.Color(77, 77, 77));
        firm_field.setText("test");

        title_panel.setBackground(new java.awt.Color(166, 77, 255));

        profile_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        profile_L.setForeground(new java.awt.Color(255, 255, 255));
        profile_L.setText("Profile");

        javax.swing.GroupLayout title_panelLayout = new javax.swing.GroupLayout(title_panel);
        title_panel.setLayout(title_panelLayout);
        title_panelLayout.setHorizontalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(profile_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        title_panelLayout.setVerticalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(profile_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout profile_panelLayout = new javax.swing.GroupLayout(profile_panel);
        profile_panel.setLayout(profile_panelLayout);
        profile_panelLayout.setHorizontalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(reg_date_L)
                    .addComponent(exp_years_L)
                    .addComponent(firm_L)
                    .addComponent(username_L)
                    .addComponent(name_L)
                    .addComponent(surname_L)
                    .addComponent(password_L)
                    .addComponent(email_L))
                .addGap(18, 18, 18)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(surname_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reg_date_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exp_years_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(firm_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(336, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(change_B)
                .addGap(18, 18, 18)
                .addComponent(update_B)
                .addGap(25, 25, 25))
        );
        profile_panelLayout.setVerticalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addComponent(title_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_L)
                    .addComponent(name_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(surname_L)
                    .addComponent(surname_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_L)
                    .addComponent(email_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password_L)
                    .addComponent(password_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reg_date_L)
                    .addComponent(reg_date_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exp_years_L)
                    .addComponent(exp_years_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firm_L)
                    .addComponent(firm_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 359, Short.MAX_VALUE)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(update_B)
                    .addComponent(change_B))
                .addGap(24, 24, 24))
        );

        main_panel.add(profile_panel);

        all_jobs_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel1.setBackground(new java.awt.Color(166, 77, 255));

        all_jobs_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        all_jobs_L.setForeground(new java.awt.Color(255, 255, 255));
        all_jobs_L.setText("All Jobs");

        javax.swing.GroupLayout title_panel1Layout = new javax.swing.GroupLayout(title_panel1);
        title_panel1.setLayout(title_panel1Layout);
        title_panel1Layout.setHorizontalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(all_jobs_L)
                .addContainerGap(540, Short.MAX_VALUE))
        );
        title_panel1Layout.setVerticalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(all_jobs_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        all_jobs_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        all_jobs_table.setForeground(new java.awt.Color(77, 77, 77));
        all_jobs_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Start Date", "Salary", "Position", "Seat", "Evaluator", "Announced", "Submission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        all_jobs_table.setGridColor(new java.awt.Color(102, 0, 204));
        all_jobs_table.setRowSelectionAllowed(false);
        all_jobs_table.setShowGrid(false);
        all_jobs_table.getTableHeader().setReorderingAllowed(false);
        all_jobs_scroll_panel.setViewportView(all_jobs_table);
        if (all_jobs_table.getColumnModel().getColumnCount() > 0) {
            all_jobs_table.getColumnModel().getColumn(0).setResizable(false);
            all_jobs_table.getColumnModel().getColumn(1).setResizable(false);
            all_jobs_table.getColumnModel().getColumn(2).setResizable(false);
            all_jobs_table.getColumnModel().getColumn(3).setResizable(false);
            all_jobs_table.getColumnModel().getColumn(4).setResizable(false);
            all_jobs_table.getColumnModel().getColumn(5).setResizable(false);
            all_jobs_table.getColumnModel().getColumn(6).setResizable(false);
            all_jobs_table.getColumnModel().getColumn(7).setResizable(false);
        }

        javax.swing.GroupLayout all_jobs_panelLayout = new javax.swing.GroupLayout(all_jobs_panel);
        all_jobs_panel.setLayout(all_jobs_panelLayout);
        all_jobs_panelLayout.setHorizontalGroup(
            all_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(all_jobs_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(all_jobs_scroll_panel)
                .addContainerGap())
        );
        all_jobs_panelLayout.setVerticalGroup(
            all_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(all_jobs_panelLayout.createSequentialGroup()
                .addComponent(title_panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(all_jobs_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 616, Short.MAX_VALUE)
                .addContainerGap())
        );

        main_panel.add(all_jobs_panel);

        my_jobs_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel2.setBackground(new java.awt.Color(166, 77, 255));

        my_jobs_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        my_jobs_L.setForeground(new java.awt.Color(255, 255, 255));
        my_jobs_L.setText("My Jobs");

        javax.swing.GroupLayout title_panel2Layout = new javax.swing.GroupLayout(title_panel2);
        title_panel2.setLayout(title_panel2Layout);
        title_panel2Layout.setHorizontalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(my_jobs_L)
                .addContainerGap(532, Short.MAX_VALUE))
        );
        title_panel2Layout.setVerticalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(my_jobs_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        my_jobs_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        my_jobs_table.setForeground(new java.awt.Color(77, 77, 77));
        my_jobs_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Start Date", "Salary", "Position", "Seat", "Evaluator", "Announced", "Submission", "Subject"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        my_jobs_table.setRowSelectionAllowed(false);
        my_jobs_table.setShowHorizontalLines(false);
        my_jobs_table.setShowVerticalLines(false);
        my_jobs_table.getTableHeader().setReorderingAllowed(false);
        myl_jobs_scroll_panel.setViewportView(my_jobs_table);
        if (my_jobs_table.getColumnModel().getColumnCount() > 0) {
            my_jobs_table.getColumnModel().getColumn(0).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(1).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(2).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(3).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(4).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(5).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(6).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(7).setResizable(false);
            my_jobs_table.getColumnModel().getColumn(8).setResizable(false);
        }

        update_job_B.setBackground(new java.awt.Color(102, 0, 204));
        update_job_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_job_B.setForeground(new java.awt.Color(255, 255, 255));
        update_job_B.setText("Update Job");
        update_job_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_job_BActionPerformed(evt);
            }
        });

        create_new_job_B.setBackground(new java.awt.Color(102, 0, 204));
        create_new_job_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_new_job_B.setForeground(new java.awt.Color(255, 255, 255));
        create_new_job_B.setText("Create New Job");
        create_new_job_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_new_job_BActionPerformed(evt);
            }
        });

        create_start_date_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_start_date_L.setForeground(new java.awt.Color(77, 77, 77));
        create_start_date_L.setText("Start Date:");

        create_salary_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_salary_L.setForeground(new java.awt.Color(77, 77, 77));
        create_salary_L.setText("Salary:");

        create_position_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_position_L.setForeground(new java.awt.Color(77, 77, 77));
        create_position_L.setText("Position:");

        create_seat_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_seat_L.setForeground(new java.awt.Color(77, 77, 77));
        create_seat_L.setText("Seat:");

        create_submission_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_submission_L.setForeground(new java.awt.Color(77, 77, 77));
        create_submission_L.setText("Submission:");

        create_start_date_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_start_date_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_start_date_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_start_date_TFActionPerformed(evt);
            }
        });

        create_salary_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_salary_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_salary_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_salary_TFActionPerformed(evt);
            }
        });

        create_position_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_position_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_position_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_position_TFActionPerformed(evt);
            }
        });

        create_seat_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_seat_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_seat_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_seat_TFActionPerformed(evt);
            }
        });

        create_submission_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_submission_TF.setForeground(new java.awt.Color(77, 77, 77));
        create_submission_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_submission_TFActionPerformed(evt);
            }
        });

        update_start_date_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_start_date_L.setForeground(new java.awt.Color(77, 77, 77));
        update_start_date_L.setText("Start Date:");

        update_start_date_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_start_date_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_start_date_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_start_date_TFActionPerformed(evt);
            }
        });

        update_salary_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_salary_L.setForeground(new java.awt.Color(77, 77, 77));
        update_salary_L.setText("Salary:");

        update_salary_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_salary_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_salary_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_salary_TFActionPerformed(evt);
            }
        });

        update_position_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_position_L.setForeground(new java.awt.Color(77, 77, 77));
        update_position_L.setText("Position:");

        update_position_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_position_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_position_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_position_TFActionPerformed(evt);
            }
        });

        update_seat_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_seat_L.setForeground(new java.awt.Color(77, 77, 77));
        update_seat_L.setText("Seat:");

        update_seat_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_seat_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_seat_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_seat_TFActionPerformed(evt);
            }
        });

        update_submission_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_submission_L.setForeground(new java.awt.Color(77, 77, 77));
        update_submission_L.setText("Submission");

        update_submission_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_submission_TF.setForeground(new java.awt.Color(77, 77, 77));
        update_submission_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_submission_TFActionPerformed(evt);
            }
        });

        update_job_id_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_job_id_CB.setForeground(new java.awt.Color(77, 77, 77));
        update_job_id_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        update_job_id_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_job_id_CBActionPerformed(evt);
            }
        });

        update_job_id_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_job_id_L.setForeground(new java.awt.Color(77, 77, 77));
        update_job_id_L.setText("Job ID");

        create_subject_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_subject_L.setForeground(new java.awt.Color(77, 77, 77));
        create_subject_L.setText("Subject:");

        create_subject_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        create_subject_CB.setForeground(new java.awt.Color(77, 77, 77));
        create_subject_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        create_subject_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                create_subject_CBActionPerformed(evt);
            }
        });

        update_subject_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_subject_CB.setForeground(new java.awt.Color(77, 77, 77));
        update_subject_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        update_subject_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_subject_CBActionPerformed(evt);
            }
        });

        update_subject_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_subject_L.setForeground(new java.awt.Color(77, 77, 77));
        update_subject_L.setText("Subject:");

        add_new_subject_B.setBackground(new java.awt.Color(102, 0, 204));
        add_new_subject_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_new_subject_B.setForeground(new java.awt.Color(255, 255, 255));
        add_new_subject_B.setText("Add Subject");
        add_new_subject_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_new_subject_BActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout my_jobs_panelLayout = new javax.swing.GroupLayout(my_jobs_panel);
        my_jobs_panel.setLayout(my_jobs_panelLayout);
        my_jobs_panelLayout.setHorizontalGroup(
            my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(my_jobs_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(myl_jobs_scroll_panel)
                    .addGroup(my_jobs_panelLayout.createSequentialGroup()
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(create_start_date_L)
                            .addComponent(create_salary_L)
                            .addComponent(create_position_L)
                            .addComponent(create_seat_L)
                            .addComponent(create_submission_L)
                            .addComponent(create_subject_L))
                        .addGap(21, 21, 21)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(create_submission_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_seat_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_position_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_salary_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_start_date_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(create_new_job_B)
                            .addComponent(create_subject_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(my_jobs_panelLayout.createSequentialGroup()
                                .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(update_start_date_L)
                                    .addComponent(update_salary_L)
                                    .addComponent(update_position_L)
                                    .addComponent(update_seat_L)
                                    .addComponent(update_submission_L)
                                    .addComponent(update_subject_L))
                                .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(my_jobs_panelLayout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(update_submission_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(update_seat_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(update_position_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(update_salary_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(update_start_date_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_jobs_panelLayout.createSequentialGroup()
                                                .addComponent(update_job_B, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(46, 46, 46))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_jobs_panelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(update_subject_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(my_jobs_panelLayout.createSequentialGroup()
                                .addComponent(update_job_id_L)
                                .addGap(51, 51, 51)
                                .addComponent(update_job_id_CB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addComponent(add_new_subject_B, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        my_jobs_panelLayout.setVerticalGroup(
            my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_jobs_panelLayout.createSequentialGroup()
                .addComponent(title_panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(add_new_subject_B)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(myl_jobs_scroll_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(my_jobs_panelLayout.createSequentialGroup()
                        .addComponent(update_job_id_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(update_start_date_L)
                            .addComponent(update_start_date_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(update_salary_L)
                            .addComponent(update_salary_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(update_position_L)
                            .addComponent(update_position_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(update_seat_L)
                            .addComponent(update_seat_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(update_submission_L)
                            .addComponent(update_submission_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(my_jobs_panelLayout.createSequentialGroup()
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_start_date_L)
                            .addComponent(create_start_date_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(update_job_id_L))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_salary_L)
                            .addComponent(create_salary_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_position_L)
                            .addComponent(create_position_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_seat_L)
                            .addComponent(create_seat_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_submission_L)
                            .addComponent(create_submission_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(create_subject_L)
                            .addComponent(create_subject_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(my_jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(update_subject_L)
                        .addComponent(update_subject_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(create_new_job_B))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(update_job_B)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        main_panel.add(my_jobs_panel);

        evaluation_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel3.setBackground(new java.awt.Color(166, 77, 255));

        evaluation_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        evaluation_L.setForeground(new java.awt.Color(255, 255, 255));
        evaluation_L.setText("Evaluation");

        javax.swing.GroupLayout title_panel3Layout = new javax.swing.GroupLayout(title_panel3);
        title_panel3.setLayout(title_panel3Layout);
        title_panel3Layout.setHorizontalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(evaluation_L)
                .addContainerGap(499, Short.MAX_VALUE))
        );
        title_panel3Layout.setVerticalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(evaluation_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        evaluation_table1.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        evaluation_table1.setForeground(new java.awt.Color(77, 77, 77));
        evaluation_table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Evaluation ID", "Employee", "Job ID", "Ev. Grade", "Comments"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        evaluation_table1.setRowSelectionAllowed(false);
        evaluation_table1.setShowHorizontalLines(false);
        evaluation_table1.setShowVerticalLines(false);
        evaluation_table1.getTableHeader().setReorderingAllowed(false);
        evaluation_scroll_panel1.setViewportView(evaluation_table1);
        if (evaluation_table1.getColumnModel().getColumnCount() > 0) {
            evaluation_table1.getColumnModel().getColumn(0).setResizable(false);
            evaluation_table1.getColumnModel().getColumn(1).setResizable(false);
            evaluation_table1.getColumnModel().getColumn(2).setResizable(false);
            evaluation_table1.getColumnModel().getColumn(3).setResizable(false);
            evaluation_table1.getColumnModel().getColumn(4).setResizable(false);
        }

        add_evaluation_B.setBackground(new java.awt.Color(102, 0, 204));
        add_evaluation_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_evaluation_B.setForeground(new java.awt.Color(255, 255, 255));
        add_evaluation_B.setText("Add Evaluation");
        add_evaluation_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_evaluation_BActionPerformed(evt);
            }
        });

        info_B.setBackground(new java.awt.Color(102, 0, 204));
        info_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        info_B.setForeground(new java.awt.Color(255, 255, 255));
        info_B.setText("Info");

        evaluation_table2.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        evaluation_table2.setForeground(new java.awt.Color(77, 77, 77));
        evaluation_table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Job ID", "Position", "Submission", "Applications"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        evaluation_table2.getTableHeader().setReorderingAllowed(false);
        evaluation_scroll_panel2.setViewportView(evaluation_table2);
        if (evaluation_table2.getColumnModel().getColumnCount() > 0) {
            evaluation_table2.getColumnModel().getColumn(0).setResizable(false);
            evaluation_table2.getColumnModel().getColumn(1).setResizable(false);
            evaluation_table2.getColumnModel().getColumn(2).setResizable(false);
            evaluation_table2.getColumnModel().getColumn(3).setResizable(false);
        }

        javax.swing.GroupLayout evaluation_panelLayout = new javax.swing.GroupLayout(evaluation_panel);
        evaluation_panel.setLayout(evaluation_panelLayout);
        evaluation_panelLayout.setHorizontalGroup(
            evaluation_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, evaluation_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(info_B)
                .addGap(18, 18, 18)
                .addComponent(add_evaluation_B)
                .addGap(20, 20, 20))
            .addGroup(evaluation_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(evaluation_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(evaluation_scroll_panel1)
                    .addComponent(evaluation_scroll_panel2))
                .addContainerGap())
        );
        evaluation_panelLayout.setVerticalGroup(
            evaluation_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(evaluation_panelLayout.createSequentialGroup()
                .addComponent(title_panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(evaluation_scroll_panel1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(evaluation_scroll_panel2, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(evaluation_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(add_evaluation_B)
                    .addComponent(info_B))
                .addGap(20, 20, 20))
        );

        main_panel.add(evaluation_panel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logo_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logo_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(main_panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void all_jobs_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_all_jobs_subLMouseClicked
        profile_panel.setVisible(false);
        all_jobs_panel.setVisible(true);
        my_jobs_panel.setVisible(false);
        evaluation_panel.setVisible(false);  
        profile_subpanel.setBackground(new Color(102,0,204));
        all_jobs_subpanel.setBackground(new Color(166,77,255));
        my_jobs_subpanel.setBackground(new Color(102,0,204));
        evaluation_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_all_jobs_subLMouseClicked

    private void exit_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_subLMouseClicked
        this.dispose();
        new LoginFrame().setVisible(true);
    }//GEN-LAST:event_exit_subLMouseClicked

    private void update_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_BActionPerformed
        this.updateProfile();
    }//GEN-LAST:event_update_BActionPerformed

    private void update_job_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_job_BActionPerformed
        String subject;
        String start_date;
        int salary;
        String position;
        String seat;
        String submission;
        int job_id;
        
        start_date = update_start_date_TF.getText();
        salary = Integer.parseInt(update_salary_TF.getText());
        position = update_position_TF.getText();
        seat = update_seat_TF.getText();
        submission = update_submission_TF.getText();  

        job_id = Integer.parseInt((String)update_job_id_CB.getSelectedItem());
        
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);  
            
            this.sendUserInfo(con);
            
            PreparedStatement insertJob = con.prepareStatement("UPDATE job SET start_date=?, salary=?, position=?, seat=?, submission_date=? WHERE id=?");
            insertJob.setString(1,start_date);
            insertJob.setInt(2,salary);
            insertJob.setString(3,position);
            insertJob.setString(4,seat);
            insertJob.setString(5,submission);
            insertJob.setInt(6,job_id);
            int rowsAffected = insertJob.executeUpdate();    
            System.out.println(rowsAffected);

            subject = (String)update_subject_CB.getSelectedItem();

            PreparedStatement insertNeeds = con.prepareStatement("UPDATE needs SET subject_title=? WHERE job_id=?");               
            insertNeeds.setString(1, subject);
            insertNeeds.setInt(2, job_id);
            int affectedRows = insertNeeds.executeUpdate();
            System.out.println(affectedRows);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        
        this.updateMyJobsTable();
        this.updateAllJobsTable();
    }//GEN-LAST:event_update_job_BActionPerformed

    private void evaluation_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_evaluation_subLMouseClicked
        profile_panel.setVisible(false);
        all_jobs_panel.setVisible(false);
        my_jobs_panel.setVisible(false);
        evaluation_panel.setVisible(true);
        profile_subpanel.setBackground(new Color(102,0,204));
        all_jobs_subpanel.setBackground(new Color(102,0,204));
        my_jobs_subpanel.setBackground(new Color(102,0,204));
        evaluation_subpanel.setBackground(new Color(166,77,255));
    }//GEN-LAST:event_evaluation_subLMouseClicked

    private void add_evaluation_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_evaluation_BActionPerformed
        new AddEvaluationFrame(username).setVisible(true);
    }//GEN-LAST:event_add_evaluation_BActionPerformed

    private void my_jobs_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_my_jobs_subLMouseClicked
        profile_panel.setVisible(false);
        all_jobs_panel.setVisible(false);
        my_jobs_panel.setVisible(true);
        evaluation_panel.setVisible(false);      
        profile_subpanel.setBackground(new Color(102,0,204));
        all_jobs_subpanel.setBackground(new Color(102,0,204));
        my_jobs_subpanel.setBackground(new Color(166,77,255));
        evaluation_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_my_jobs_subLMouseClicked

    private void profile_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_profile_subLMouseClicked
        profile_panel.setVisible(true);
        all_jobs_panel.setVisible(false);
        my_jobs_panel.setVisible(false);
        evaluation_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        all_jobs_subpanel.setBackground(new Color(102,0,204));
        my_jobs_subpanel.setBackground(new Color(102,0,204));
        evaluation_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_profile_subLMouseClicked

    private void create_start_date_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_start_date_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_start_date_TFActionPerformed

    private void create_salary_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_salary_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_salary_TFActionPerformed

    private void create_position_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_position_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_position_TFActionPerformed

    private void create_seat_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_seat_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_seat_TFActionPerformed

    private void create_submission_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_submission_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_submission_TFActionPerformed

    private void update_start_date_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_start_date_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_start_date_TFActionPerformed

    private void update_salary_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_salary_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_salary_TFActionPerformed

    private void update_position_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_position_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_position_TFActionPerformed

    private void update_seat_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_seat_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_seat_TFActionPerformed

    private void update_submission_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_submission_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_submission_TFActionPerformed

    private void create_new_job_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_new_job_BActionPerformed
        String subject;
        String start_date;
        int salary;
        int current_job_id=0;
        String position;
        String seat;
        String submission;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime announced;
      
        try {
            start_date = create_start_date_TF.getText();
            salary = Integer.parseInt(create_salary_TF.getText());
            position = create_position_TF.getText();
            seat = create_seat_TF.getText();
            submission = create_submission_TF.getText();
            
            create_start_date_TF.setText(" ");
            create_salary_TF.setText(" ");
            create_position_TF.setText(" ");
            create_seat_TF.setText(" ");
            create_submission_TF.setText(" ");
            
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD); 
            
            this.sendUserInfo(con);
            
            announced = LocalDateTime.now();
            PreparedStatement insertJob = con.prepareStatement("INSERT INTO job VALUES (?,?,?,?,?,?,?,?,?)");
            insertJob.setNull(1, Types.NULL);
            insertJob.setString(2,start_date);
            insertJob.setInt(3,salary);
            insertJob.setString(4,position);
            insertJob.setString(5,seat);
            insertJob.setString(6,username);
            insertJob.setString(7,dtf.format(announced));
            insertJob.setString(8,submission);
            insertJob.setString(9,firm);
            int rowsAffected = insertJob.executeUpdate();    
            System.out.println(rowsAffected);
            
            
            subject = (String)create_subject_CB.getSelectedItem();
            PreparedStatement selectJobId = con.prepareStatement("SELECT MAX(id) FROM job");
            ResultSet resultJobId = selectJobId.executeQuery();
            while (resultJobId.next()) {
                current_job_id = resultJobId.getInt("MAX(id)");
            }
            System.out.println(current_job_id);
            PreparedStatement insertNeeds = con.prepareStatement("INSERT INTO needs VALUES (?,?)");
            insertNeeds.setInt(1, current_job_id);
            insertNeeds.setString(2, subject);
            int affectedRows = insertNeeds.executeUpdate();
            System.out.println(affectedRows);
            
            this.restoreUserInfo(con);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Input data for salary are invalid. Please try again...");
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        
        this.updateMyJobsTable();
        this.updateAllJobsTable();
        this.populateComboBoxUpdateJobId();
    }//GEN-LAST:event_create_new_job_BActionPerformed

    private void change_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_change_BActionPerformed
        new UpdateProfileFrame(username, 1).setVisible(true);
    }//GEN-LAST:event_change_BActionPerformed

    private void update_job_id_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_job_id_CBActionPerformed
        if (update_job_id_CB_populated == true) {
            String start_date;
            int salary;
            String position;
            String seat;
            String submission;
            int job_id;
        
            job_id = Integer.parseInt((String)update_job_id_CB.getSelectedItem());
            
            try {
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
                PreparedStatement selectJob = con.prepareStatement("SELECT start_date, salary, position, seat, submission_date FROM job WHERE id=?");
                selectJob.setInt(1, job_id);
                ResultSet resultJob = selectJob.executeQuery();

                while (resultJob.next()) {
                    start_date = resultJob.getString("start_date");    
                    salary = resultJob.getInt("salary");
                    position = resultJob.getString("position");
                    seat = resultJob.getString("seat");
                    submission = resultJob.getString("submission_date");
                    
                    update_start_date_TF.setText(start_date);
                    update_salary_TF.setText(String.valueOf(salary));
                    update_position_TF.setText(position);
                    update_seat_TF.setText(seat);
                    update_submission_TF.setText(submission);
                }
            }
            catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
                ex.printStackTrace();
            }
            finally {
                if (con != null)
                try { con.close();}
                catch (SQLException ex) { ex.printStackTrace();}
            }
        }
    }//GEN-LAST:event_update_job_id_CBActionPerformed

    private void create_subject_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_create_subject_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_create_subject_CBActionPerformed

    private void update_subject_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_subject_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_update_subject_CBActionPerformed

    private void add_new_subject_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_new_subject_BActionPerformed
        new AddSubjectFrame().setVisible(true);
    }//GEN-LAST:event_add_new_subject_BActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EvaluatorProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EvaluatorProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EvaluatorProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EvaluatorProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EvaluatorProfileFrame(username, firm).setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_evaluation_B;
    private javax.swing.JButton add_new_subject_B;
    private javax.swing.JLabel all_jobs_L;
    private javax.swing.JPanel all_jobs_panel;
    private javax.swing.JScrollPane all_jobs_scroll_panel;
    private javax.swing.JLabel all_jobs_subL;
    private javax.swing.JPanel all_jobs_subpanel;
    private javax.swing.JTable all_jobs_table;
    private javax.swing.JButton change_B;
    private javax.swing.JButton create_new_job_B;
    private javax.swing.JLabel create_position_L;
    private javax.swing.JTextField create_position_TF;
    private javax.swing.JLabel create_salary_L;
    private javax.swing.JTextField create_salary_TF;
    private javax.swing.JLabel create_seat_L;
    private javax.swing.JTextField create_seat_TF;
    private javax.swing.JLabel create_start_date_L;
    private javax.swing.JTextField create_start_date_TF;
    private javax.swing.JComboBox<String> create_subject_CB;
    private javax.swing.JLabel create_subject_L;
    private javax.swing.JLabel create_submission_L;
    private javax.swing.JTextField create_submission_TF;
    private javax.swing.JLabel email_L;
    private javax.swing.JLabel email_field;
    private javax.swing.JLabel evaluation_L;
    private javax.swing.JPanel evaluation_panel;
    private javax.swing.JScrollPane evaluation_scroll_panel1;
    private javax.swing.JScrollPane evaluation_scroll_panel2;
    private javax.swing.JLabel evaluation_subL;
    private javax.swing.JPanel evaluation_subpanel;
    private javax.swing.JTable evaluation_table1;
    private javax.swing.JTable evaluation_table2;
    private javax.swing.JLabel exit_subL;
    private javax.swing.JPanel exit_subpanel;
    private javax.swing.JLabel exp_years_L;
    private javax.swing.JLabel exp_years_field;
    private javax.swing.JLabel firm_L;
    private javax.swing.JLabel firm_field;
    private javax.swing.JButton info_B;
    private javax.swing.JLabel logo_L;
    private javax.swing.JPanel logo_panel;
    private javax.swing.JPanel main_panel;
    private javax.swing.JLabel my_jobs_L;
    private javax.swing.JPanel my_jobs_panel;
    private javax.swing.JLabel my_jobs_subL;
    private javax.swing.JPanel my_jobs_subpanel;
    private javax.swing.JTable my_jobs_table;
    private javax.swing.JScrollPane myl_jobs_scroll_panel;
    private javax.swing.JLabel name_L;
    private javax.swing.JLabel name_field;
    private javax.swing.JLabel password_L;
    private javax.swing.JLabel password_field;
    private javax.swing.JLabel profile_L;
    private javax.swing.JPanel profile_panel;
    private javax.swing.JLabel profile_subL;
    private javax.swing.JPanel profile_subpanel;
    private javax.swing.JLabel reg_date_L;
    private javax.swing.JLabel reg_date_field;
    private javax.swing.JLabel surname_L;
    private javax.swing.JLabel surname_field;
    private javax.swing.JPanel title_panel;
    private javax.swing.JPanel title_panel1;
    private javax.swing.JPanel title_panel2;
    private javax.swing.JPanel title_panel3;
    private javax.swing.JButton update_B;
    private javax.swing.JButton update_job_B;
    private javax.swing.JComboBox<String> update_job_id_CB;
    private javax.swing.JLabel update_job_id_L;
    private javax.swing.JLabel update_position_L;
    private javax.swing.JTextField update_position_TF;
    private javax.swing.JLabel update_salary_L;
    private javax.swing.JTextField update_salary_TF;
    private javax.swing.JLabel update_seat_L;
    private javax.swing.JTextField update_seat_TF;
    private javax.swing.JLabel update_start_date_L;
    private javax.swing.JTextField update_start_date_TF;
    private javax.swing.JComboBox<String> update_subject_CB;
    private javax.swing.JLabel update_subject_L;
    private javax.swing.JLabel update_submission_L;
    private javax.swing.JTextField update_submission_TF;
    private javax.swing.JLabel username_L;
    private javax.swing.JLabel username_field;
    // End of variables declaration//GEN-END:variables
}
