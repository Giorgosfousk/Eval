package EVaLgui;


public class GUImain {
    public static void main(String args[]) {
        new LoginFrame().setVisible(true);
    }
}
