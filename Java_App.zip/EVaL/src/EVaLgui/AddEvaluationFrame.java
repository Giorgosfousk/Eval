package EVaLgui;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class AddEvaluationFrame extends javax.swing.JFrame {
   
    private static String username;
    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static boolean job_id_CB_populated;
    private static boolean employee_CB_populated;
    
    public AddEvaluationFrame(String in_username) {
        initComponents();
        this.username = in_username;
        this.populateComboBoxJobId();
    }

    private void populateComboBoxJobId() {       
        job_id_CB_populated = false;
        job_id_CB.removeAllItems();
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime current_date =  LocalDateTime.now();
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectAvailableJobsId = con.prepareStatement("SELECT id FROM job WHERE evaluator=? AND submission_date>=? AND id NOT IN (SELECT job_id FROM evaluation_results)");
            selectAvailableJobsId.setString(1, username);
            selectAvailableJobsId.setString(2, dtf.format(current_date));
            ResultSet resultJobsId = selectAvailableJobsId.executeQuery();
                       
            while (resultJobsId.next()) {               
                job_id_CB.addItem(resultJobsId.getString("id"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        job_id_CB_populated = true;
    }
    
    private void populateComboBoxEmployees(int job_id) {       
        employee_CB_populated = false;
        employee_CB.removeAllItems();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectEmployees = con.prepareStatement("SELECT username, name, surname FROM requests_evaluation INNER JOIN user ON requests_evaluation.employee=user.username WHERE job_id=?");
            selectEmployees.setInt(1, job_id);
            ResultSet resultEmployees = selectEmployees.executeQuery();
                       
            while (resultEmployees.next()) {               
                employee_CB.addItem(resultEmployees.getString("username")+": "+resultEmployees.getString("name")+" "+resultEmployees.getString("surname"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        employee_CB_populated = true;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        main_panel = new javax.swing.JPanel();
        add_subject_L = new javax.swing.JLabel();
        grade1_L = new javax.swing.JLabel();
        descr_L = new javax.swing.JLabel();
        ev_id_L = new javax.swing.JLabel();
        grade1_TF = new javax.swing.JTextField();
        grade2_TF = new javax.swing.JTextField();
        add_evaluation_B = new javax.swing.JButton();
        job_id_CB = new javax.swing.JComboBox<>();
        employee_CB = new javax.swing.JComboBox<>();
        ev_id_L1 = new javax.swing.JLabel();
        grade1_L1 = new javax.swing.JLabel();
        grade1_L2 = new javax.swing.JLabel();
        grade3_TF = new javax.swing.JTextField();
        comments_SP = new javax.swing.JScrollPane();
        comments_TA = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        main_panel.setBackground(new java.awt.Color(166, 77, 255));

        add_subject_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        add_subject_L.setForeground(new java.awt.Color(255, 255, 255));
        add_subject_L.setText("Add New Subject");

        javax.swing.GroupLayout main_panelLayout = new javax.swing.GroupLayout(main_panel);
        main_panel.setLayout(main_panelLayout);
        main_panelLayout.setHorizontalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(add_subject_L)
                .addGap(162, 162, 162))
        );
        main_panelLayout.setVerticalGroup(
            main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(add_subject_L)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        grade1_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        grade1_L.setForeground(new java.awt.Color(77, 77, 77));
        grade1_L.setText("Grade 1:");

        descr_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        descr_L.setForeground(new java.awt.Color(77, 77, 77));
        descr_L.setText("Comments:");

        ev_id_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ev_id_L.setForeground(new java.awt.Color(77, 77, 77));
        ev_id_L.setText("Job Id:");

        grade1_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        grade1_TF.setForeground(new java.awt.Color(77, 77, 77));
        grade1_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grade1_TFActionPerformed(evt);
            }
        });

        grade2_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        grade2_TF.setForeground(new java.awt.Color(77, 77, 77));
        grade2_TF.setPreferredSize(new java.awt.Dimension(80, 26));
        grade2_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grade2_TFActionPerformed(evt);
            }
        });

        add_evaluation_B.setBackground(new java.awt.Color(102, 0, 204));
        add_evaluation_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        add_evaluation_B.setForeground(new java.awt.Color(255, 255, 255));
        add_evaluation_B.setText("Add");
        add_evaluation_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_evaluation_BActionPerformed(evt);
            }
        });

        job_id_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        job_id_CB.setForeground(new java.awt.Color(77, 77, 77));
        job_id_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        job_id_CB.setPreferredSize(new java.awt.Dimension(80, 26));
        job_id_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                job_id_CBActionPerformed(evt);
            }
        });

        employee_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        employee_CB.setForeground(new java.awt.Color(77, 77, 77));
        employee_CB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        employee_CB.setPreferredSize(new java.awt.Dimension(423, 26));
        employee_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employee_CBActionPerformed(evt);
            }
        });

        ev_id_L1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ev_id_L1.setForeground(new java.awt.Color(77, 77, 77));
        ev_id_L1.setText("Employee:");

        grade1_L1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        grade1_L1.setForeground(new java.awt.Color(77, 77, 77));
        grade1_L1.setText("Grade 2:");

        grade1_L2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        grade1_L2.setForeground(new java.awt.Color(77, 77, 77));
        grade1_L2.setText("Grade 3:");

        grade3_TF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        grade3_TF.setForeground(new java.awt.Color(77, 77, 77));
        grade3_TF.setPreferredSize(new java.awt.Dimension(80, 26));
        grade3_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grade3_TFActionPerformed(evt);
            }
        });

        comments_TA.setColumns(20);
        comments_TA.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        comments_TA.setForeground(new java.awt.Color(77, 77, 77));
        comments_TA.setLineWrap(true);
        comments_TA.setRows(5);
        comments_SP.setViewportView(comments_TA);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(add_evaluation_B))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ev_id_L)
                            .addComponent(grade1_L)
                            .addComponent(grade1_L2)
                            .addComponent(ev_id_L1)
                            .addComponent(descr_L)
                            .addComponent(grade1_L1))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comments_SP)
                            .addComponent(employee_CB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(job_id_CB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(grade2_TF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(grade3_TF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(grade1_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ev_id_L)
                    .addComponent(job_id_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ev_id_L1)
                    .addComponent(employee_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(grade1_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(grade1_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(grade1_L1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(grade2_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(grade3_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(grade1_L2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(descr_L)
                    .addComponent(comments_SP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addComponent(add_evaluation_B)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void grade1_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grade1_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_grade1_TFActionPerformed

    private void grade2_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grade2_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_grade2_TFActionPerformed

    private void add_evaluation_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_evaluation_BActionPerformed
        String employee;
        String employee_username;
        String comments;
        int job_id;
        int grade1;
        int grade2;
        int grade3;
        int grade;
        int ev_id = 0;
        
        job_id = Integer.parseInt((String)job_id_CB.getSelectedItem());
        employee = (String)employee_CB.getSelectedItem();
        employee_username = employee.substring(0, employee.indexOf(":"));
        comments = comments_TA.getText();
        grade1 = Integer.parseInt(grade1_TF.getText());
        grade2 = Integer.parseInt(grade2_TF.getText());
        grade3 = Integer.parseInt(grade3_TF.getText());
        grade = grade1 + grade2 + grade3;
        
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectEvId = con.prepareStatement("SELECT ev_id FROM evaluation_process WHERE job_id=? AND employee=?");
            selectEvId.setInt(1, job_id);
            selectEvId.setString(2, employee_username);
            ResultSet resultEvId = selectEvId.executeQuery();
                       
            while (resultEvId.next()) {               
                ev_id = resultEvId.getInt("ev_id");
            } 
            
            PreparedStatement updateEvaluation = con.prepareStatement("UPDATE evaluation_process SET eval1=?, eval2=?, eval3=?, evaluation_finalized=?, comments=? WHERE ev_id=?");
            updateEvaluation.setInt(1,grade1);
            updateEvaluation.setInt(2,grade2);
            updateEvaluation.setInt(3,grade3);
            updateEvaluation.setString(4,"yes");
            updateEvaluation.setString(5,comments);
            int rowsAffected = updateEvaluation.executeUpdate();
            System.out.println(rowsAffected);
            
            PreparedStatement insertEvaluation = con.prepareStatement("INSERT INTO evaluation_results VALUES (?,?,?,?,?)");
            insertEvaluation.setInt(1,ev_id);
            insertEvaluation.setString(2,employee_username);
            insertEvaluation.setInt(3,job_id);
            insertEvaluation.setInt(4,grade);
            insertEvaluation.setString(5,comments);
            rowsAffected = insertEvaluation.executeUpdate();
            System.out.println(rowsAffected);
        }
        catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Input data invalid. Please try again...");
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }//GEN-LAST:event_add_evaluation_BActionPerformed

    private void job_id_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_job_id_CBActionPerformed
        if (job_id_CB_populated == true) {
            this.populateComboBoxEmployees(Integer.parseInt((String)job_id_CB.getSelectedItem()));
        }
    }//GEN-LAST:event_job_id_CBActionPerformed

    private void employee_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employee_CBActionPerformed
        String employee;
        int job_id;
        
        if (employee_CB_populated == true) {
            employee = (String)employee_CB.getSelectedItem();
            job_id = Integer.parseInt((String)job_id_CB.getSelectedItem());
            
            try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectEvals = con.prepareStatement("SELECT eval1, eval2, eval3, comments FROM evaluation_process WHERE job_id=? AND employee=?");
            selectEvals.setInt(1, job_id);
            selectEvals.setString(2, employee);
            ResultSet resultEvals = selectEvals.executeQuery();
                       
            while (resultEvals.next()) {               
                grade1_TF.setText(resultEvals.getString("eval1"));
                grade2_TF.setText(resultEvals.getString("eval2"));
                grade3_TF.setText(resultEvals.getString("eval3"));
                comments_TA.setText(resultEvals.getString("comments"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        }
    }//GEN-LAST:event_employee_CBActionPerformed

    private void grade3_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grade3_TFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_grade3_TFActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddEvaluationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddEvaluationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddEvaluationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddEvaluationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddEvaluationFrame(username).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_evaluation_B;
    private javax.swing.JLabel add_subject_L;
    private javax.swing.JScrollPane comments_SP;
    private javax.swing.JTextArea comments_TA;
    private javax.swing.JLabel descr_L;
    private javax.swing.JComboBox<String> employee_CB;
    private javax.swing.JLabel ev_id_L;
    private javax.swing.JLabel ev_id_L1;
    private javax.swing.JLabel grade1_L;
    private javax.swing.JLabel grade1_L1;
    private javax.swing.JLabel grade1_L2;
    private javax.swing.JTextField grade1_TF;
    private javax.swing.JTextField grade2_TF;
    private javax.swing.JTextField grade3_TF;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> job_id_CB;
    private javax.swing.JPanel main_panel;
    // End of variables declaration//GEN-END:variables
}
