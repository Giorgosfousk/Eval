package EVaLgui;

import java.awt.Color;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableModel;


public class EmployeeProfileFrame extends javax.swing.JFrame {

    private static String username;
    private static String firm;
    private static final String DB_URL = "jdbc:mariadb://localhost:3306/evaluationdb";
    private static Connection con;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private DefaultTableModel model_my_applications;
    private DefaultTableModel model_jobs;
    private DefaultTableModel model_projects;
    private DefaultTableModel model_degrees;
    
    public EmployeeProfileFrame(String login_username, String login_firm) {
        initComponents();
        this.username = login_username;
        this.firm = login_firm;
        profile_panel.setVisible(true);
        my_applications_panel.setVisible(false);
        jobs_panel.setVisible(false);
        my_folder_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        username_field.setText(username);       
        this.updateProfile();
        this.updateMyApplicationsTable();
        this.populateComboBoxDeleteJobId();
        this.updateJobsTable();
        this.populateComboBoxApplyJobId();
        this.updateLanguages();
        this.updateProjectsTable();
        this.updateDegreesTable();
    }
    
    private void sendUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, username);  
        callSetCurrentUser.execute();
    }
   
    private void restoreUserInfo(Connection connection) throws SQLException{
        String stored = "{call setCurrentUser(?)}";
        CallableStatement callSetCurrentUser = connection.prepareCall(stored);
        callSetCurrentUser.setString(1, "local_admin");  
        callSetCurrentUser.execute();
    }
    
    private void updateProfile() {
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectUserInfo = con.prepareStatement("SELECT name, surname, email, password, reg_date, firm FROM user WHERE username LIKE ?");
            selectUserInfo.setString(1, username);
            ResultSet resultUserInfo = selectUserInfo.executeQuery();

            PreparedStatement selectEmployeeInfo = con.prepareStatement("SELECT bio, recommendations, certificates, awards, exp_years FROM employee WHERE username LIKE ?");
            selectEmployeeInfo.setString(1, username);
            ResultSet resultEmployeeInfo = selectEmployeeInfo.executeQuery();
            
            while (resultUserInfo.next()) {           
                name_field.setText(resultUserInfo.getString("name"));
                surname_field.setText(resultUserInfo.getString("surname"));
                email_field.setText(resultUserInfo.getString("email"));
                password_field.setText(resultUserInfo.getString("password").replaceAll(".", "*"));
                reg_date_field.setText(resultUserInfo.getString("reg_date"));
                firm_field.setText(resultUserInfo.getString("firm"));      
            }   
            while (resultEmployeeInfo.next()) {
                bio_TA.setText(resultEmployeeInfo.getString("bio"));
                recommendations_field.setText(resultEmployeeInfo.getString("recommendations"));
                certificates_field.setText(resultEmployeeInfo.getString("certificates"));
                awards_field.setText(resultEmployeeInfo.getString("awards"));
                exp_years_field.setText(resultEmployeeInfo.getString("exp_years"));
            }          
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }

    private void updateMyApplicationsTable() {
        model_my_applications = (DefaultTableModel) my_applications_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectJobs = con.prepareStatement("SELECT * FROM requests_evaluation INNER JOIN job ON job_id=id WHERE employee=?");
            selectJobs.setString(1, username);
            ResultSet resultJobs = selectJobs.executeQuery();
            model_my_applications.setRowCount(0);           
            while (resultJobs.next()) {
                model_my_applications.insertRow(model_my_applications.getRowCount(), new Object[]{resultJobs.getInt("id"),resultJobs.getString("start_date"),resultJobs.getFloat("salary"),resultJobs.getString("position"),resultJobs.getString("seat"),resultJobs.getString("evaluator"),resultJobs.getString("announce_date"),resultJobs.getString("submission_date")});

            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }       
    }
    
    private void updateJobsTable() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime current_date =  LocalDateTime.now();
        model_jobs = (DefaultTableModel) jobs_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectAvailableJobs = con.prepareStatement("SELECT * FROM job WHERE firm=? AND submission_date>=?");
            selectAvailableJobs.setString(1, firm);
            selectAvailableJobs.setString(2, dtf.format(current_date));
            ResultSet resultJobs = selectAvailableJobs.executeQuery();
            model_jobs.setRowCount(0);           
            while (resultJobs.next()) {
                model_jobs.insertRow(model_jobs.getRowCount(), new Object[]{resultJobs.getInt("id"),resultJobs.getString("start_date"),resultJobs.getFloat("salary"),resultJobs.getString("position"),resultJobs.getString("seat"),resultJobs.getString("evaluator"),resultJobs.getString("announce_date"),resultJobs.getString("submission_date")});
            }              
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateProjectsTable() {
        model_projects = (DefaultTableModel) projects_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectProjects = con.prepareStatement("SELECT num, descr, url FROM project WHERE employee=?");
            selectProjects.setString(1, username);           
            ResultSet resultProjects = selectProjects.executeQuery();
            model_projects.setRowCount(0);                         
            while (resultProjects.next()) {
                model_projects.insertRow(model_projects.getRowCount(), new Object[]{resultProjects.getInt("num"),resultProjects.getString("descr"),resultProjects.getString("url")});

            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateDegreesTable() {
        model_degrees = (DefaultTableModel) degrees_table.getModel();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectDegrees = con.prepareStatement("SELECT has_degree.degr_title, has_degree.degr_institute, has_degree.year, has_degree.grade, degree.grade FROM has_degree INNER JOIN degree ON degr_title=title WHERE employee=?");
            selectDegrees.setString(1, username);           
            ResultSet resultDegrees = selectDegrees.executeQuery();
            model_degrees.setRowCount(0);                         
            while (resultDegrees.next()) {
                model_degrees.insertRow(model_degrees.getRowCount(), new Object[]{resultDegrees.getString("has_degree.degr_title"),resultDegrees.getString("has_degree.degr_institute"),resultDegrees.getString("degree.grade"),resultDegrees.getFloat("has_degree.grade"),(resultDegrees.getString("has_degree.year")).substring(0, 4)});

            }
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void updateLanguages() {       
        String temp_string;
        int counter = 1;
        languages_field.setText("");
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            
            PreparedStatement selectLanguages = con.prepareStatement("SELECT lang FROM languages WHERE employee=?");
            selectLanguages.setString(1, username);
            ResultSet resultLanguages = selectLanguages.executeQuery();
            
            while (resultLanguages.next()) {           
                temp_string = resultLanguages.getString("lang");
                if (temp_string.equals("en")) {
                    temp_string = ", English";
                }
                else if (temp_string.equals("fr")) {
                    temp_string = ", French";
                }
                else if (temp_string.equals("sp")) {
                    temp_string = ", Spanish";
                }
                else if (temp_string.equals("gr")) {
                    temp_string = ", Greek";
                }
                if (counter == 1) {
                    temp_string = temp_string.substring(2);
                }
                languages_field.setText(languages_field.getText()+temp_string);
                counter++;
            }             
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void populateComboBoxDeleteJobId() { 
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime current_date =  LocalDateTime.now();
        delete_job_id_CB.removeAllItems();
        try {
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectJobsId = con.prepareStatement("SELECT job_id FROM requests_evaluation INNER JOIN job ON job_id=id WHERE employee=? AND submission_date>=?");
            selectJobsId.setString(1, username);
            selectJobsId.setString(2, dtf.format(current_date));
            ResultSet resultJobsId = selectJobsId.executeQuery();
                       
            while (resultJobsId.next()) { 
                delete_job_id_CB.addItem(resultJobsId.getString("job_id"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    private void populateComboBoxApplyJobId() {       
        apply_job_id_CB.removeAllItems();
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime current_date =  LocalDateTime.now();
            con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
            PreparedStatement selectAvailableJobsId = con.prepareStatement("SELECT id FROM job LEFT JOIN requests_evaluation ON id=job_id WHERE firm=? AND submission_date>=? AND (employee<>? OR employee IS NULL)");
            selectAvailableJobsId.setString(1, firm);
            selectAvailableJobsId.setString(2, dtf.format(current_date));
            selectAvailableJobsId.setString(3, username);
            ResultSet resultJobsId = selectAvailableJobsId.executeQuery();
                       
            while (resultJobsId.next()) {               
                apply_job_id_CB.addItem(resultJobsId.getString("id"));
            }     
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logo_panel = new javax.swing.JPanel();
        logo_L = new javax.swing.JLabel();
        profile_subpanel = new javax.swing.JPanel();
        profile_subL = new javax.swing.JLabel();
        jobs_subpanel = new javax.swing.JPanel();
        jobs_subL = new javax.swing.JLabel();
        my_applications_subpanel = new javax.swing.JPanel();
        my_applications_subL = new javax.swing.JLabel();
        my_folder_subpanel = new javax.swing.JPanel();
        my_folder_subL = new javax.swing.JLabel();
        exit_subpanel = new javax.swing.JPanel();
        exit_subL = new javax.swing.JLabel();
        main_panel = new javax.swing.JPanel();
        profile_panel = new javax.swing.JPanel();
        title_panel = new javax.swing.JPanel();
        profile_L = new javax.swing.JLabel();
        username_L = new javax.swing.JLabel();
        name_L = new javax.swing.JLabel();
        surname_L = new javax.swing.JLabel();
        email_L = new javax.swing.JLabel();
        password_L = new javax.swing.JLabel();
        reg_date_L = new javax.swing.JLabel();
        exp_years_L = new javax.swing.JLabel();
        firm_L = new javax.swing.JLabel();
        update_B = new javax.swing.JButton();
        change_B = new javax.swing.JButton();
        username_field = new javax.swing.JLabel();
        name_field = new javax.swing.JLabel();
        surname_field = new javax.swing.JLabel();
        email_field = new javax.swing.JLabel();
        reg_date_field = new javax.swing.JLabel();
        password_field = new javax.swing.JLabel();
        exp_years_field = new javax.swing.JLabel();
        firm_field = new javax.swing.JLabel();
        recommendations_L = new javax.swing.JLabel();
        certificates_L = new javax.swing.JLabel();
        award_L = new javax.swing.JLabel();
        bio_L = new javax.swing.JLabel();
        certificates_field = new javax.swing.JLabel();
        recommendations_field = new javax.swing.JLabel();
        awards_field = new javax.swing.JLabel();
        bio_SP = new javax.swing.JScrollPane();
        bio_TA = new javax.swing.JTextArea();
        my_applications_panel = new javax.swing.JPanel();
        title_panel1 = new javax.swing.JPanel();
        my_applications_L = new javax.swing.JLabel();
        delete_job_id_L = new javax.swing.JLabel();
        delete_job_id_CB = new javax.swing.JComboBox<>();
        delete_application_B1 = new javax.swing.JButton();
        my_applications_scroll_panel = new javax.swing.JScrollPane();
        my_applications_table = new javax.swing.JTable();
        jobs_panel = new javax.swing.JPanel();
        title_panel2 = new javax.swing.JPanel();
        available_jobs_L = new javax.swing.JLabel();
        apply_for_job_B = new javax.swing.JButton();
        apply_job_id_CB = new javax.swing.JComboBox<>();
        apply_job_id_L = new javax.swing.JLabel();
        jobs_scroll_panel = new javax.swing.JScrollPane();
        jobs_table = new javax.swing.JTable();
        my_folder_panel = new javax.swing.JPanel();
        title_panel3 = new javax.swing.JPanel();
        my_folder_L = new javax.swing.JLabel();
        languages_L = new javax.swing.JLabel();
        projects_scroll_panel = new javax.swing.JScrollPane();
        projects_table = new javax.swing.JTable();
        degrees_scroll_panel = new javax.swing.JScrollPane();
        degrees_table = new javax.swing.JTable();
        languages_field = new javax.swing.JLabel();
        projects_L = new javax.swing.JLabel();
        degrees_L = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        logo_panel.setBackground(new java.awt.Color(102, 0, 204));

        logo_L.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        logo_L.setForeground(new java.awt.Color(255, 255, 255));
        logo_L.setText("EVaL");

        profile_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        profile_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        profile_subL.setForeground(new java.awt.Color(255, 255, 255));
        profile_subL.setText("                           Profile");
        profile_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                profile_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout profile_subpanelLayout = new javax.swing.GroupLayout(profile_subpanel);
        profile_subpanel.setLayout(profile_subpanelLayout);
        profile_subpanelLayout.setHorizontalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        profile_subpanelLayout.setVerticalGroup(
            profile_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profile_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );

        jobs_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        jobs_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jobs_subL.setForeground(new java.awt.Color(255, 255, 255));
        jobs_subL.setText("                            Jobs");
        jobs_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jobs_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jobs_subpanelLayout = new javax.swing.GroupLayout(jobs_subpanel);
        jobs_subpanel.setLayout(jobs_subpanelLayout);
        jobs_subpanelLayout.setHorizontalGroup(
            jobs_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jobs_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jobs_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jobs_subpanelLayout.setVerticalGroup(
            jobs_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jobs_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jobs_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        my_applications_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        my_applications_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        my_applications_subL.setForeground(new java.awt.Color(255, 255, 255));
        my_applications_subL.setText("                    My Applications");
        my_applications_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                my_applications_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout my_applications_subpanelLayout = new javax.swing.GroupLayout(my_applications_subpanel);
        my_applications_subpanel.setLayout(my_applications_subpanelLayout);
        my_applications_subpanelLayout.setHorizontalGroup(
            my_applications_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_applications_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_applications_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        my_applications_subpanelLayout.setVerticalGroup(
            my_applications_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_applications_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_applications_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        my_folder_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        my_folder_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        my_folder_subL.setForeground(new java.awt.Color(255, 255, 255));
        my_folder_subL.setText("                        My Folder");
        my_folder_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                my_folder_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout my_folder_subpanelLayout = new javax.swing.GroupLayout(my_folder_subpanel);
        my_folder_subpanel.setLayout(my_folder_subpanelLayout);
        my_folder_subpanelLayout.setHorizontalGroup(
            my_folder_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_folder_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_folder_subL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        my_folder_subpanelLayout.setVerticalGroup(
            my_folder_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_folder_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(my_folder_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                .addContainerGap())
        );

        exit_subpanel.setBackground(new java.awt.Color(102, 0, 204));

        exit_subL.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exit_subL.setForeground(new java.awt.Color(255, 255, 255));
        exit_subL.setText("                            Exit");
        exit_subL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exit_subLMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout exit_subpanelLayout = new javax.swing.GroupLayout(exit_subpanel);
        exit_subpanel.setLayout(exit_subpanelLayout);
        exit_subpanelLayout.setHorizontalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );
        exit_subpanelLayout.setVerticalGroup(
            exit_subpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exit_subpanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exit_subL, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout logo_panelLayout = new javax.swing.GroupLayout(logo_panel);
        logo_panel.setLayout(logo_panelLayout);
        logo_panelLayout.setHorizontalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(logo_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addGroup(logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jobs_subpanel, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(my_applications_subpanel, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(profile_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(logo_panelLayout.createSequentialGroup()
                        .addComponent(exit_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(my_folder_subpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        logo_panelLayout.setVerticalGroup(
            logo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logo_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logo_L)
                .addGap(52, 52, 52)
                .addComponent(profile_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(my_applications_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jobs_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(my_folder_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(exit_subpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        main_panel.setBackground(new java.awt.Color(255, 255, 255));
        main_panel.setLayout(new javax.swing.OverlayLayout(main_panel));

        profile_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel.setBackground(new java.awt.Color(166, 77, 255));

        profile_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        profile_L.setForeground(new java.awt.Color(255, 255, 255));
        profile_L.setText("Profile");

        javax.swing.GroupLayout title_panelLayout = new javax.swing.GroupLayout(title_panel);
        title_panel.setLayout(title_panelLayout);
        title_panelLayout.setHorizontalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(profile_L)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        title_panelLayout.setVerticalGroup(
            title_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(profile_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        username_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_L.setForeground(new java.awt.Color(77, 77, 77));
        username_L.setText("Username:");

        name_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_L.setForeground(new java.awt.Color(77, 77, 77));
        name_L.setText("Name:");

        surname_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_L.setForeground(new java.awt.Color(77, 77, 77));
        surname_L.setText("Surname:");

        email_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_L.setForeground(new java.awt.Color(77, 77, 77));
        email_L.setText("Email:");

        password_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_L.setForeground(new java.awt.Color(77, 77, 77));
        password_L.setText("Password:");

        reg_date_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_L.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_L.setText("Date of Registration:");

        exp_years_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_L.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_L.setText("Years of Experience:");

        firm_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_L.setForeground(new java.awt.Color(77, 77, 77));
        firm_L.setText("Firm:");

        update_B.setBackground(new java.awt.Color(102, 0, 204));
        update_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        update_B.setForeground(new java.awt.Color(255, 255, 255));
        update_B.setText("Update");
        update_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_BActionPerformed(evt);
            }
        });

        change_B.setBackground(new java.awt.Color(102, 0, 204));
        change_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        change_B.setForeground(new java.awt.Color(255, 255, 255));
        change_B.setText("Change");
        change_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                change_BActionPerformed(evt);
            }
        });

        username_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        username_field.setForeground(new java.awt.Color(77, 77, 77));
        username_field.setText("test");

        name_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name_field.setForeground(new java.awt.Color(77, 77, 77));
        name_field.setText("test");

        surname_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        surname_field.setForeground(new java.awt.Color(77, 77, 77));
        surname_field.setText("test");

        email_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email_field.setForeground(new java.awt.Color(77, 77, 77));
        email_field.setText("test");

        reg_date_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        reg_date_field.setForeground(new java.awt.Color(77, 77, 77));
        reg_date_field.setText("test");

        password_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password_field.setForeground(new java.awt.Color(77, 77, 77));
        password_field.setText("tset");

        exp_years_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exp_years_field.setForeground(new java.awt.Color(77, 77, 77));
        exp_years_field.setText("test");

        firm_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        firm_field.setForeground(new java.awt.Color(77, 77, 77));
        firm_field.setText("test");

        recommendations_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        recommendations_L.setForeground(new java.awt.Color(77, 77, 77));
        recommendations_L.setText("Recommendations:");

        certificates_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        certificates_L.setForeground(new java.awt.Color(77, 77, 77));
        certificates_L.setText("Certificates:");

        award_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        award_L.setForeground(new java.awt.Color(77, 77, 77));
        award_L.setText("Awards:");

        bio_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        bio_L.setForeground(new java.awt.Color(77, 77, 77));
        bio_L.setText("Bio:");

        certificates_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        certificates_field.setForeground(new java.awt.Color(77, 77, 77));
        certificates_field.setText("test");

        recommendations_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        recommendations_field.setForeground(new java.awt.Color(77, 77, 77));
        recommendations_field.setText("test");

        awards_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        awards_field.setForeground(new java.awt.Color(77, 77, 77));
        awards_field.setText("test");

        bio_TA.setEditable(false);
        bio_TA.setColumns(20);
        bio_TA.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        bio_TA.setForeground(new java.awt.Color(77, 77, 77));
        bio_TA.setLineWrap(true);
        bio_TA.setRows(5);
        bio_SP.setViewportView(bio_TA);

        javax.swing.GroupLayout profile_panelLayout = new javax.swing.GroupLayout(profile_panel);
        profile_panel.setLayout(profile_panelLayout);
        profile_panelLayout.setHorizontalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(change_B)
                .addGap(18, 18, 18)
                .addComponent(update_B)
                .addGap(25, 25, 25))
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_panelLayout.createSequentialGroup()
                            .addComponent(certificates_L)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(certificates_field, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_panelLayout.createSequentialGroup()
                            .addComponent(recommendations_L)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(recommendations_field, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, profile_panelLayout.createSequentialGroup()
                            .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(reg_date_L)
                                .addComponent(exp_years_L)
                                .addComponent(firm_L)
                                .addComponent(username_L)
                                .addComponent(name_L)
                                .addComponent(surname_L)
                                .addComponent(password_L)
                                .addComponent(email_L))
                            .addGap(18, 18, 18)
                            .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(username_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(name_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(surname_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(password_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(email_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(reg_date_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(exp_years_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(firm_field, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, profile_panelLayout.createSequentialGroup()
                        .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(award_L)
                            .addComponent(bio_L))
                        .addGap(95, 95, 95)
                        .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(awards_field, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                            .addComponent(bio_SP))))
                .addContainerGap(273, Short.MAX_VALUE))
        );
        profile_panelLayout.setVerticalGroup(
            profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profile_panelLayout.createSequentialGroup()
                .addComponent(title_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username_L, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_L)
                    .addComponent(name_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(surname_L)
                    .addComponent(surname_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_L)
                    .addComponent(email_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password_L)
                    .addComponent(password_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reg_date_L)
                    .addComponent(reg_date_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exp_years_L)
                    .addComponent(exp_years_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firm_L)
                    .addComponent(firm_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(recommendations_L)
                    .addComponent(recommendations_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(certificates_L)
                    .addComponent(certificates_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(award_L)
                    .addComponent(awards_field))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(profile_panelLayout.createSequentialGroup()
                        .addComponent(bio_L)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(profile_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(update_B)
                            .addComponent(change_B))
                        .addGap(24, 24, 24))
                    .addGroup(profile_panelLayout.createSequentialGroup()
                        .addComponent(bio_SP, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(173, Short.MAX_VALUE))))
        );

        main_panel.add(profile_panel);

        my_applications_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel1.setBackground(new java.awt.Color(166, 77, 255));

        my_applications_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        my_applications_L.setForeground(new java.awt.Color(255, 255, 255));
        my_applications_L.setText("My Applications");

        javax.swing.GroupLayout title_panel1Layout = new javax.swing.GroupLayout(title_panel1);
        title_panel1.setLayout(title_panel1Layout);
        title_panel1Layout.setHorizontalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(my_applications_L)
                .addContainerGap(407, Short.MAX_VALUE))
        );
        title_panel1Layout.setVerticalGroup(
            title_panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(my_applications_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        delete_job_id_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        delete_job_id_L.setForeground(new java.awt.Color(77, 77, 77));
        delete_job_id_L.setText("Job ID:");

        delete_job_id_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        delete_job_id_CB.setForeground(new java.awt.Color(77, 77, 77));
        delete_job_id_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_job_id_CBActionPerformed(evt);
            }
        });

        delete_application_B1.setBackground(new java.awt.Color(102, 0, 204));
        delete_application_B1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        delete_application_B1.setForeground(new java.awt.Color(255, 255, 255));
        delete_application_B1.setText("Delete");
        delete_application_B1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_application_B1ActionPerformed(evt);
            }
        });

        my_applications_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        my_applications_table.setForeground(new java.awt.Color(77, 77, 77));
        my_applications_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Start Date", "Salary", "Position", "Seat", "Evaluator", "Announced", "Submission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        my_applications_table.setGridColor(new java.awt.Color(102, 0, 204));
        my_applications_table.setRowSelectionAllowed(false);
        my_applications_table.setShowGrid(false);
        my_applications_table.getTableHeader().setReorderingAllowed(false);
        my_applications_scroll_panel.setViewportView(my_applications_table);

        javax.swing.GroupLayout my_applications_panelLayout = new javax.swing.GroupLayout(my_applications_panel);
        my_applications_panel.setLayout(my_applications_panelLayout);
        my_applications_panelLayout.setHorizontalGroup(
            my_applications_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(my_applications_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(my_applications_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(my_applications_panelLayout.createSequentialGroup()
                        .addComponent(delete_job_id_L)
                        .addGap(18, 18, 18)
                        .addComponent(delete_job_id_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(delete_application_B1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(my_applications_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 663, Short.MAX_VALUE))
                .addContainerGap())
        );
        my_applications_panelLayout.setVerticalGroup(
            my_applications_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_applications_panelLayout.createSequentialGroup()
                .addComponent(title_panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(my_applications_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(delete_job_id_L)
                    .addComponent(delete_job_id_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(delete_application_B1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(my_applications_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 586, Short.MAX_VALUE)
                .addContainerGap())
        );

        main_panel.add(my_applications_panel);

        jobs_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel2.setBackground(new java.awt.Color(166, 77, 255));

        available_jobs_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        available_jobs_L.setForeground(new java.awt.Color(255, 255, 255));
        available_jobs_L.setText("Available Jobs");

        javax.swing.GroupLayout title_panel2Layout = new javax.swing.GroupLayout(title_panel2);
        title_panel2.setLayout(title_panel2Layout);
        title_panel2Layout.setHorizontalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(available_jobs_L)
                .addContainerGap(438, Short.MAX_VALUE))
        );
        title_panel2Layout.setVerticalGroup(
            title_panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(available_jobs_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        apply_for_job_B.setBackground(new java.awt.Color(102, 0, 204));
        apply_for_job_B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        apply_for_job_B.setForeground(new java.awt.Color(255, 255, 255));
        apply_for_job_B.setText("Apply for Job");
        apply_for_job_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apply_for_job_BActionPerformed(evt);
            }
        });

        apply_job_id_CB.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        apply_job_id_CB.setForeground(new java.awt.Color(77, 77, 77));
        apply_job_id_CB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apply_job_id_CBActionPerformed(evt);
            }
        });

        apply_job_id_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        apply_job_id_L.setForeground(new java.awt.Color(77, 77, 77));
        apply_job_id_L.setText("Job ID:");

        jobs_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jobs_table.setForeground(new java.awt.Color(77, 77, 77));
        jobs_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Start Date", "Salary", "Position", "Seat", "Evaluator", "Announced", "Submission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Float.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jobs_table.setRowSelectionAllowed(false);
        jobs_table.setShowHorizontalLines(false);
        jobs_table.setShowVerticalLines(false);
        jobs_table.getTableHeader().setReorderingAllowed(false);
        jobs_scroll_panel.setViewportView(jobs_table);

        javax.swing.GroupLayout jobs_panelLayout = new javax.swing.GroupLayout(jobs_panel);
        jobs_panel.setLayout(jobs_panelLayout);
        jobs_panelLayout.setHorizontalGroup(
            jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jobs_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jobs_panelLayout.createSequentialGroup()
                        .addComponent(apply_job_id_L)
                        .addGap(18, 18, 18)
                        .addComponent(apply_job_id_CB, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(apply_for_job_B)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jobs_scroll_panel))
                .addContainerGap())
        );
        jobs_panelLayout.setVerticalGroup(
            jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jobs_panelLayout.createSequentialGroup()
                .addComponent(title_panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jobs_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(apply_job_id_L)
                    .addComponent(apply_job_id_CB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(apply_for_job_B))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jobs_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 586, Short.MAX_VALUE)
                .addContainerGap())
        );

        main_panel.add(jobs_panel);

        my_folder_panel.setBackground(new java.awt.Color(255, 255, 255));

        title_panel3.setBackground(new java.awt.Color(166, 77, 255));

        my_folder_L.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        my_folder_L.setForeground(new java.awt.Color(255, 255, 255));
        my_folder_L.setText("My Folder");

        javax.swing.GroupLayout title_panel3Layout = new javax.swing.GroupLayout(title_panel3);
        title_panel3.setLayout(title_panel3Layout);
        title_panel3Layout.setHorizontalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(my_folder_L)
                .addContainerGap(501, Short.MAX_VALUE))
        );
        title_panel3Layout.setVerticalGroup(
            title_panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(title_panel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(my_folder_L)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        languages_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        languages_L.setForeground(new java.awt.Color(77, 77, 77));
        languages_L.setText("Languages:");

        projects_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        projects_table.setForeground(new java.awt.Color(77, 77, 77));
        projects_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Description", "Url"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        projects_table.setRowSelectionAllowed(false);
        projects_table.setShowHorizontalLines(false);
        projects_table.setShowVerticalLines(false);
        projects_table.getTableHeader().setReorderingAllowed(false);
        projects_scroll_panel.setViewportView(projects_table);
        if (projects_table.getColumnModel().getColumnCount() > 0) {
            projects_table.getColumnModel().getColumn(0).setResizable(false);
            projects_table.getColumnModel().getColumn(1).setResizable(false);
            projects_table.getColumnModel().getColumn(2).setResizable(false);
        }

        degrees_table.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        degrees_table.setForeground(new java.awt.Color(77, 77, 77));
        degrees_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title", "Institute", "Type- Grade", "Grade", "Year"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degrees_table.setRowSelectionAllowed(false);
        degrees_table.setShowHorizontalLines(false);
        degrees_table.setShowVerticalLines(false);
        degrees_table.getTableHeader().setReorderingAllowed(false);
        degrees_scroll_panel.setViewportView(degrees_table);
        if (degrees_table.getColumnModel().getColumnCount() > 0) {
            degrees_table.getColumnModel().getColumn(0).setResizable(false);
            degrees_table.getColumnModel().getColumn(1).setResizable(false);
            degrees_table.getColumnModel().getColumn(2).setResizable(false);
            degrees_table.getColumnModel().getColumn(3).setResizable(false);
            degrees_table.getColumnModel().getColumn(4).setResizable(false);
        }

        languages_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        languages_field.setForeground(new java.awt.Color(77, 77, 77));
        languages_field.setText("test");

        projects_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        projects_L.setForeground(new java.awt.Color(77, 77, 77));
        projects_L.setText("Projects:");

        degrees_L.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        degrees_L.setForeground(new java.awt.Color(77, 77, 77));
        degrees_L.setText("Degrees:");

        javax.swing.GroupLayout my_folder_panelLayout = new javax.swing.GroupLayout(my_folder_panel);
        my_folder_panel.setLayout(my_folder_panelLayout);
        my_folder_panelLayout.setHorizontalGroup(
            my_folder_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title_panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(my_folder_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(my_folder_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(my_folder_panelLayout.createSequentialGroup()
                        .addComponent(languages_L)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(languages_field, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE))
                    .addComponent(projects_scroll_panel)
                    .addComponent(degrees_scroll_panel)
                    .addGroup(my_folder_panelLayout.createSequentialGroup()
                        .addGroup(my_folder_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(degrees_L)
                            .addComponent(projects_L))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        my_folder_panelLayout.setVerticalGroup(
            my_folder_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(my_folder_panelLayout.createSequentialGroup()
                .addComponent(title_panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(my_folder_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(languages_L)
                    .addComponent(languages_field))
                .addGap(18, 18, 18)
                .addComponent(projects_L)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(projects_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 346, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(degrees_L)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(degrees_scroll_panel, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );

        main_panel.add(my_folder_panel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logo_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logo_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(main_panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void profile_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_profile_subLMouseClicked
        profile_panel.setVisible(true);
        my_applications_panel.setVisible(false);
        jobs_panel.setVisible(false);
        my_folder_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(166,77,255));
        jobs_subpanel.setBackground(new Color(102,0,204));
        my_applications_subpanel.setBackground(new Color(102,0,204));
        my_folder_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_profile_subLMouseClicked

    private void jobs_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jobs_subLMouseClicked
        profile_panel.setVisible(false);
        my_applications_panel.setVisible(false);
        jobs_panel.setVisible(true);
        my_folder_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(102,0,204));
        jobs_subpanel.setBackground(new Color(166,77,255));
        my_applications_subpanel.setBackground(new Color(102,0,204));
        my_folder_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_jobs_subLMouseClicked

    private void my_applications_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_my_applications_subLMouseClicked
        profile_panel.setVisible(false);
        my_applications_panel.setVisible(true);
        jobs_panel.setVisible(false);
        my_folder_panel.setVisible(false);
        profile_subpanel.setBackground(new Color(102,0,204));
        jobs_subpanel.setBackground(new Color(102,0,204));
        my_applications_subpanel.setBackground(new Color(166,77,255));
        my_folder_subpanel.setBackground(new Color(102,0,204));
    }//GEN-LAST:event_my_applications_subLMouseClicked

    private void exit_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_subLMouseClicked
        this.dispose();
        new LoginFrame().setVisible(true);
    }//GEN-LAST:event_exit_subLMouseClicked

    private void update_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_BActionPerformed
        this.updateProfile();
    }//GEN-LAST:event_update_BActionPerformed

    private void change_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_change_BActionPerformed
        new UpdateProfileFrame(username, 3).setVisible(true);
    }//GEN-LAST:event_change_BActionPerformed

    private void apply_for_job_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apply_for_job_BActionPerformed
        try {
            int job_id;
            
            if (apply_job_id_CB.getSelectedItem() != null) {
                job_id = Integer.valueOf((String)apply_job_id_CB.getSelectedItem());

                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
                
                this.sendUserInfo(con);

                PreparedStatement insertApplication = con.prepareStatement("INSERT INTO requests_evaluation VALUES(?,?)");
                insertApplication.setString(1, username);
                insertApplication.setInt(2, job_id);
                int affectedRows = insertApplication.executeUpdate();
                System.out.println(affectedRows);
                
                this.restoreUserInfo(con);
            }            
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        this.updateMyApplicationsTable();
        this.populateComboBoxApplyJobId();
        this.populateComboBoxDeleteJobId();
    }//GEN-LAST:event_apply_for_job_BActionPerformed

    private void delete_application_B1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_application_B1ActionPerformed
        try {
            int job_id;
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime current_date =  LocalDateTime.now();
            //String check_for_empty;
            //check_for_empty = (String)delete_job_id_CB.getSelectedItem();
            if (delete_job_id_CB.getSelectedItem() != null) {
                job_id = Integer.valueOf((String)delete_job_id_CB.getSelectedItem());
                 
                con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);           
            
                this.sendUserInfo(con);
                
                PreparedStatement deleteApplication = con.prepareStatement("DELETE FROM requests_evaluation WHERE employee=? AND job_id=?");
                deleteApplication.setString(1, username);
                deleteApplication.setInt(2, job_id);
                int affectedRows = deleteApplication.executeUpdate();
                System.out.println(affectedRows);
                
                this.restoreUserInfo(con);
            }            
        }
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        finally {
            if (con != null)
            try { con.close();}
            catch (SQLException ex) { ex.printStackTrace();}
        }
        this.updateMyApplicationsTable();
        this.populateComboBoxDeleteJobId();
        this.populateComboBoxApplyJobId();
    }//GEN-LAST:event_delete_application_B1ActionPerformed

    private void delete_job_id_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_job_id_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_delete_job_id_CBActionPerformed

    private void my_folder_subLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_my_folder_subLMouseClicked
        profile_panel.setVisible(false);
        my_applications_panel.setVisible(false);
        jobs_panel.setVisible(false);
        my_folder_panel.setVisible(true);
        profile_subpanel.setBackground(new Color(102,0,204));
        jobs_subpanel.setBackground(new Color(102,0,204));
        my_applications_subpanel.setBackground(new Color(102,0,204));
        my_folder_subpanel.setBackground(new Color(166,77,255));
    }//GEN-LAST:event_my_folder_subLMouseClicked

    private void apply_job_id_CBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apply_job_id_CBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apply_job_id_CBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeProfileFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeProfileFrame(username,firm).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton apply_for_job_B;
    private javax.swing.JComboBox<String> apply_job_id_CB;
    private javax.swing.JLabel apply_job_id_L;
    private javax.swing.JLabel available_jobs_L;
    private javax.swing.JLabel award_L;
    private javax.swing.JLabel awards_field;
    private javax.swing.JLabel bio_L;
    private javax.swing.JScrollPane bio_SP;
    private javax.swing.JTextArea bio_TA;
    private javax.swing.JLabel certificates_L;
    private javax.swing.JLabel certificates_field;
    private javax.swing.JButton change_B;
    private javax.swing.JLabel degrees_L;
    private javax.swing.JScrollPane degrees_scroll_panel;
    private javax.swing.JTable degrees_table;
    private javax.swing.JButton delete_application_B1;
    private javax.swing.JComboBox<String> delete_job_id_CB;
    private javax.swing.JLabel delete_job_id_L;
    private javax.swing.JLabel email_L;
    private javax.swing.JLabel email_field;
    private javax.swing.JLabel exit_subL;
    private javax.swing.JPanel exit_subpanel;
    private javax.swing.JLabel exp_years_L;
    private javax.swing.JLabel exp_years_field;
    private javax.swing.JLabel firm_L;
    private javax.swing.JLabel firm_field;
    private javax.swing.JPanel jobs_panel;
    private javax.swing.JScrollPane jobs_scroll_panel;
    private javax.swing.JLabel jobs_subL;
    private javax.swing.JPanel jobs_subpanel;
    private javax.swing.JTable jobs_table;
    private javax.swing.JLabel languages_L;
    private javax.swing.JLabel languages_field;
    private javax.swing.JLabel logo_L;
    private javax.swing.JPanel logo_panel;
    private javax.swing.JPanel main_panel;
    private javax.swing.JLabel my_applications_L;
    private javax.swing.JPanel my_applications_panel;
    private javax.swing.JScrollPane my_applications_scroll_panel;
    private javax.swing.JLabel my_applications_subL;
    private javax.swing.JPanel my_applications_subpanel;
    private javax.swing.JTable my_applications_table;
    private javax.swing.JLabel my_folder_L;
    private javax.swing.JPanel my_folder_panel;
    private javax.swing.JLabel my_folder_subL;
    private javax.swing.JPanel my_folder_subpanel;
    private javax.swing.JLabel name_L;
    private javax.swing.JLabel name_field;
    private javax.swing.JLabel password_L;
    private javax.swing.JLabel password_field;
    private javax.swing.JLabel profile_L;
    private javax.swing.JPanel profile_panel;
    private javax.swing.JLabel profile_subL;
    private javax.swing.JPanel profile_subpanel;
    private javax.swing.JLabel projects_L;
    private javax.swing.JScrollPane projects_scroll_panel;
    private javax.swing.JTable projects_table;
    private javax.swing.JLabel recommendations_L;
    private javax.swing.JLabel recommendations_field;
    private javax.swing.JLabel reg_date_L;
    private javax.swing.JLabel reg_date_field;
    private javax.swing.JLabel surname_L;
    private javax.swing.JLabel surname_field;
    private javax.swing.JPanel title_panel;
    private javax.swing.JPanel title_panel1;
    private javax.swing.JPanel title_panel2;
    private javax.swing.JPanel title_panel3;
    private javax.swing.JButton update_B;
    private javax.swing.JLabel username_L;
    private javax.swing.JLabel username_field;
    // End of variables declaration//GEN-END:variables
}
